<?php
declare(strict_types=1);

/* ============================================================
 * API JSON untuk kolom SKU (scan barcode/QR, ketik manual,
 * serta pembuatan produk cepat saat SKU belum terdaftar).
 *
 * Dipanggil dari assets/sku.js lewat fetch().
 *   GET  api_product.php?op=lookup&sku=XXXX
 *   POST api_product.php  (op=create, _csrf, sku, brand_id, category, unit, cost_price, sell_price, min_stock)
 *
 * Selalu membalas JSON: {"ok":bool, "error":"...", "product":{...}}
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function api_out(array $data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function api_product_payload(array $p): array
{
    return [
        'id' => (int)$p['id'],
        'sku' => (string)$p['sku'],
        'unit' => (string)($p['unit'] ?? 'pcs'),
        'category' => (string)($p['category'] ?? ''),
        'size' => (string)($p['size'] ?? ''),
        'brand_name' => (string)($p['brand_name'] ?? ''),
        /* cost_price = HPP Rata-rata (nilai lapisan stok sisa, dihitung FIFO)
           cost_price_initial = HPP Awal (harga penerimaan pertama) */
        'cost_price' => (float)($p['cost_price'] ?? 0),
        'cost_price_initial' => (float)($p['cost_price_initial'] ?? 0) > 0
            ? (float)$p['cost_price_initial']
            : (float)($p['cost_price'] ?? 0),
        'sell_price' => (float)($p['sell_price'] ?? 0),
        'min_stock' => (float)($p['min_stock'] ?? 0),
        'stock_qty' => (float)($p['stock_qty'] ?? 0),
        'active' => (int)($p['active'] ?? 1),
    ];
}

if (!current_user()) {
    api_out(['ok' => false, 'error' => 'unauthorized'], 401);
}

$op = (string)($_GET['op'] ?? $_POST['op'] ?? 'lookup');

/* ---------------- pencarian produk berdasarkan SKU ---------------- */
if ($op === 'lookup' || $op === 'lookup_many') {
    if (!can('tx.view') && !can('master.view')) {
        api_out(['ok' => false, 'error' => 'forbidden'], 403);
    }
    if ($op === 'lookup_many') {
        $raw = (string)($_GET['skus'] ?? $_POST['skus'] ?? '');
        $list = array_filter(array_map('trim', explode(',', $raw)), static fn($s) => $s !== '');
        if (count($list) > 200) $list = array_slice($list, 0, 200);
        $found = [];
        $missing = [];
        foreach ($list as $sku) {
            $p = product_by_sku($sku);
            if ($p && (int)$p['active'] === 1) {
                $found[strtoupper($sku)] = api_product_payload($p);
            } else {
                $missing[] = strtoupper($sku);
            }
        }
        api_out(['ok' => true, 'found' => $found, 'missing' => $missing]);
    }

    $sku = strtoupper(trim((string)($_GET['sku'] ?? $_POST['sku'] ?? '')));
    if ($sku === '') {
        api_out(['ok' => false, 'error' => 'empty', 'sku' => '']);
    }
    $p = product_by_sku($sku);
    if (!$p) {
        api_out(['ok' => false, 'error' => 'not_found', 'sku' => $sku], 404);
    }
    if ((int)$p['active'] !== 1) {
        api_out(['ok' => false, 'error' => 'inactive', 'sku' => $sku, 'product' => api_product_payload($p)], 409);
    }
    api_out(['ok' => true, 'product' => api_product_payload($p)]);
}

/* ---------------- buat produk cepat dari kolom scan ---------------- */
if ($op === 'create') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        api_out(['ok' => false, 'error' => 'method'], 405);
    }
    if (!can('master.edit')) {
        api_out(['ok' => false, 'error' => 'forbidden', 'message' => 'Role Anda tidak boleh menambah produk. Minta Admin mendaftarkan SKU ini.'], 403);
    }
    $token = (string)($_POST['_csrf'] ?? '');
    if ($token === '' || !hash_equals((string)($_SESSION['csrf'] ?? ''), $token)) {
        api_out(['ok' => false, 'error' => 'csrf', 'message' => 'Sesi kedaluwarsa. Muat ulang halaman lalu coba lagi.'], 419);
    }

    $sku = strtoupper(trim((string)($_POST['sku'] ?? '')));
    if ($sku === '') {
        api_out(['ok' => false, 'error' => 'empty', 'message' => 'SKU wajib diisi.'], 422);
    }
    if (mb_strlen($sku) > 60) {
        api_out(['ok' => false, 'error' => 'too_long', 'message' => 'SKU terlalu panjang (maksimal 60 karakter).'], 422);
    }
    $existing = product_by_sku($sku);
    if ($existing) {
        if ((int)$existing['active'] !== 1) {
            api_out(['ok' => false, 'error' => 'inactive', 'sku' => $sku, 'message' => 'Produk ' . $sku . ' ada tapi berstatus nonaktif. Aktifkan dulu di Produk Master.'], 409);
        }
        api_out(['ok' => true, 'product' => api_product_payload($existing), 'already' => true]);
    }

    $brandId = (int)($_POST['brand_id'] ?? 0) ?: null;
    $category = trim((string)($_POST['category'] ?? ''));
    $category = $category === '' ? 'Belum dikategorikan' : mb_substr($category, 0, 60);
    $size = normalize_size($_POST['size'] ?? '');
    $unit = trim((string)($_POST['unit'] ?? 'pcs'));
    $unit = $unit === '' ? 'pcs' : mb_substr($unit, 0, 20);
    $cost = parse_num($_POST['cost_price'] ?? 0);
    $sell = parse_num($_POST['sell_price'] ?? 0);
    $minStock = parse_qty($_POST['min_stock'] ?? 0);

    try {
        db_tx(function () use ($sku, $brandId, $category, $unit, $cost, $sell, $minStock, $size) {
            return product_create($sku, $brandId, null, $category, $unit, $cost, $sell, $minStock, 1, $size);
        });
    } catch (Throwable $ex) {
        api_out(['ok' => false, 'error' => 'db', 'message' => 'Gagal menyimpan produk: ' . $ex->getMessage()], 500);
    }

    log_activity('create', 'Daftar produk cepat dari scan: ' . $sku, 'product', $sku);
    $p = product_by_sku($sku);
    api_out(['ok' => true, 'created' => true, 'product' => $p ? api_product_payload($p) : null]);
}

/* ---------------- bantuan: daftar brand untuk panel buat cepat ---------------- */
if ($op === 'brands') {
    api_out(['ok' => true, 'brands' => array_map(static fn($b) => [
        'id' => (int)$b['id'],
        'code' => (string)$b['code'],
        'name' => (string)$b['name'],
    ], db_all('SELECT id, code, name FROM brands WHERE active = 1 ORDER BY name'))]);
}

api_out(['ok' => false, 'error' => 'unknown_op'], 400);
