/* Inventori — kolom SKU untuk scanner barcode/QR & scan kamera.
   Dipakai oleh form Barang Masuk, Barang Keluar, Retur, Adjustment, dan Opname.

   Alur kerja scanner:
   - Kursor selalu berada di kolom scan, jadi scan berikutnya langsung terbaca.
   - Scan / ketik SKU + Enter  ->  baris ditambahkan (mode items) atau kolom
     hitung fisik difokuskan (mode count).
   - Kalau SKU belum terdaftar, muncul panel "Buat & Tambahkan" tanpa keluar halaman.
*/
(function () {
  'use strict';

  var API = 'api_product.php';
  function fmt(n) { return (window.fmtNum || String)(n); }
  var cache = {};                 // sku -> product
  var lastCamCode = '';           // kode yang sedang terlihat di kamera (anti-hitung ganda)
  var autoTimer = null;           // timer autofokus kolom scan

  function el(sel, root) { return (root || document).querySelector(sel); }
  function els(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function norm(s) { return String(s || '').trim().toUpperCase(); }

  function num(v) {
    var n = parseFloat(String(v === undefined || v === null ? '' : v).replace(/[^\d,.-]/g, '').replace(/\.(?=\d{3}\b)/g, '').replace(',', '.'));
    return isNaN(n) ? 0 : n;
  }

  /* Penjaga scan ganda: scanner murah kadang mengirim kode yang sama dua kali
     dalam hitungan milidetik. Scan secepat itu diabaikan agar jumlah tidak dobel. */
  var BOUNCE_MS = 700;
  var lastSameSku = {};

  function isBounce(sku) {
    var now = Date.now();
    var prev = lastSameSku[sku];
    lastSameSku[sku] = now;
    return prev !== undefined && (now - prev) < BOUNCE_MS;
  }

  function listSummary(cfg) {
    if (cfg.mode !== 'items') return '';
    var rows = els('tr', document.getElementById(cfg.bodyId));
    var unit = 0;
    rows.forEach(function (tr) {
      var q = el('[name="item_qty[]"]', tr);
      unit += num(q ? q.value : 0);
    });
    return ' <span class="muted">(' + rows.length + ' baris · ' + fmt(unit) + " unit)</span>";
  }

  function tools() { return els('[data-scan-tools]'); }

  function setStatus(box, text, kind) {
    if (!box) return;
    box.className = 'scan-status' + (kind ? ' ' + kind : '');
    box.innerHTML = text || '';
  }

  function esc(s) {
    return String(s || '').replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  /* ---------------- panggilan API ---------------- */

  function apiLookup(sku) {
    var key = norm(sku);
    if (cache[key] && cache[key].__miss === undefined) return Promise.resolve(cache[key]);
    return fetch(API + '?op=lookup&sku=' + encodeURIComponent(key), { credentials: 'same-origin' })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'bad_json' }; }); })
      .then(function (j) {
        if (j && j.ok && j.product) { cache[key] = j.product; return j.product; }
        return null;
      })
      .catch(function () { return null; });
  }

  function apiCreate(payload) {
    var body = new FormData();
    body.append('op', 'create');
    body.append('_csrf', payload.csrf);
    Object.keys(payload.data).forEach(function (k) { body.append(k, payload.data[k]); });
    return fetch(API, { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'bad_json' }; }); })
      .catch(function () { return { ok: false, error: 'network' }; });
  }

  /* ---------------- baris item (mode items) ---------------- */

  function rowSku(row) {
    var inp = el('[data-sku-input]', row);
    return inp ? norm(inp.value) : '';
  }

  function markRow(row, kind, text) {
    var hint = el('.sku-hint', row);
    row.classList.remove('row-ok', 'row-unknown');
    if (kind === 'ok') row.classList.add('row-ok');
    if (kind === 'unknown') row.classList.add('row-unknown');
    if (hint) {
      if (kind === 'unknown') hint.innerHTML = '<span class="err-text">SKU belum terdaftar</span>';
      else if (text) hint.textContent = text;
      else hint.textContent = '';
    }
  }

  /**
   * Nilai awal kolom harga. Kalau harga produk belum ada (0), kolom DIBIARKAN KOSONG
   * — bukan diisi angka 0 — supaya petugas mengisi sendiri harga belinya
   * (permintaan pemilik toko: "jangan default 0, dikosongkan saja").
   */
  function priceText(product, priceKey) {
    var v = num(product ? product[priceKey] : 0);
    return v > 0 ? fmt(v) : '';
  }

  function fillPrice(row, product, priceKey) {
    var priceInput = el('[name="item_price[]"]', row);
    if (!priceInput) return;
    if (num(priceInput.value) === 0) priceInput.value = priceText(product, priceKey);
  }

  function recalcTable(table) {
    if (!table) return;
    var opts = {
      tableId: table.id,
      stockMap: window.PRODUCT_STOCK || {},
      totalQtyId: table.getAttribute('data-total-qty') || '',
      totalAmountId: table.getAttribute('data-total-amount') || ''
    };
    if (window.itemRows && window.itemRows.recalc) window.itemRows.recalc(opts);
  }

  /* Uang rupiah untuk keterangan di baris ("Rp 45.000"). */
  function money(n) {
    if (typeof window.fmtMoney === 'function') return window.fmtMoney(n);
    var dec = Math.abs((n || 0) - Math.round(n || 0)) > 0.004 ? 2 : 0;
    return 'Rp ' + new Intl.NumberFormat('id-ID', { minimumFractionDigits: dec, maximumFractionDigits: dec }).format(n || 0);
  }

  /**
   * Keterangan harga pada baris. Khusus barang masuk, kolom harga diisi dari HPP AWAL
   * (harga penerimaan pertama) — dan HPP rata-rata ikut ditampilkan sebagai pembanding
   * supaya terlihat jelas harga mana yang dipakai.
   */
  function hppInfo(product, cfg) {
    if (cfg.priceKey !== 'cost_price_initial') return '';
    var awal = product.cost_price_initial;
    var rata = product.cost_price;
    if (!(num(awal) > 0) && !(num(rata) > 0)) {
      /* belum ada harga sama sekali: kolom harga dibiarkan kosong untuk diisi manual */
      return ' · HPP belum diisi — isi harga belinya di kolom Harga Beli';
    }
    var txt = ' · HPP Awal: ' + money(awal);
    if (rata !== undefined && rata !== null && Math.abs((rata || 0) - (awal || 0)) > 0.004) {
      txt += ' (rata-rata ' + money(rata) + ')';
    }
    return txt;
  }

  function paintRow(tr, product, cfg) {
    var skuInp = el('[data-sku-input]', tr);
    if (skuInp) skuInp.value = product.sku;
    tr.setAttribute('data-sku', product.sku);
    tr.dataset.stock = String(product.stock_qty);
    tr.dataset.unit = product.unit || 'pcs';
    var sysCell = el('.sys-stock', tr);
    if (sysCell) sysCell.textContent = fmt(product.stock_qty) + ' ' + (product.unit || 'pcs');
    var priceInput = el('[name="item_price[]"]', tr);
    if (priceInput) priceInput.value = priceText(product, cfg.priceKey);
    markRow(tr, 'ok', 'brand: ' + (product.brand_name || '-')
      + (product.size ? ' · ukuran ' + product.size : '')
      + ' · stok: ' + fmt(product.stock_qty)
      + ' ' + (product.unit || 'pcs') + hppInfo(product, cfg));
  }

  function addItemRow(cfg, product, qty) {
    var body = document.getElementById(cfg.bodyId);
    var tpl = document.getElementById(cfg.tplId);
    if (!body || !tpl) return null;
    var tr = document.createElement('tr');
    tr.innerHTML = tpl.innerHTML;
    body.appendChild(tr);
    paintRow(tr, product, cfg);

    if (cfg.mode === 'items') {
      /* Fokus sengaja TIDAK dipindah: kursor harus tetap di kolom scan supaya
         scanner bisa langsung membaca barang berikutnya tanpa salah tempat. */
      var qtyInput = el('[name="item_qty[]"]', tr);
      if (qtyInput) qtyInput.value = qty === undefined ? '1' : String(qty);
    } else {
      /* mode hitung fisik: fokus kolom jumlah hasil hitung */
      var field = el(cfg.focusField, tr) || el('.count-field', tr) || el('[name="item_after[]"]', tr);
      if (field) { field.focus(); if (field.select) field.select(); }
      if (window.adjRecalc) { try { window.adjRecalc(); } catch (e) {} }
    }
    recalcTable(document.getElementById(cfg.tableId));
    return tr;
  }

  /**
   * Sisipkan baris baru ke daftar hitung statis (opname) supaya produk yang baru
   * didaftarkan/di luar filter bisa langsung dihitung tanpa memuat ulang halaman
   * (memuat ulang akan menghapus angka yang sudah diketik operator).
   */
  function injectCountRow(cfg, product) {
    var root = cfg.listRoot;
    if (!root) return null;
    var tbody = root.querySelector('tbody') || (root.querySelector('table') || {}).querySelector('tbody');
    if (!tbody) return null;
    var tr = document.createElement('tr');
    tr.setAttribute('data-sku', product.sku);
    tr.setAttribute('data-name', (product.sku + ' ' + (product.brand_name || '')).toLowerCase());
    tr.innerHTML = '<td class="mono">' + esc(product.sku) + '</td>'
      + '<td>' + esc(product.brand_name || '-') + '</td>'
      + '<td>' + esc(product.unit || 'pcs') + '</td>'
      + '<td class="num sys">' + fmt(product.stock_qty) + '</td>'
      + '<td>'
      + '<input type="hidden" name="counted_sku[]" value="' + esc(product.sku) + '">'
      + '<input class="qty-input op-count count-field" type="text" name="counted_qty[]" value="" '
      + 'data-stock="' + product.stock_qty + '" oninput="opRecalc()">'
      + '</td>'
      + '<td class="num diff">-</td>';
    tbody.appendChild(tr);
    return tr;
  }

  function focusCountField(root, sku, focusField) {
    var target = null;
    els('tr[data-sku]', root).some(function (tr) {
      if (norm(tr.getAttribute('data-sku')) === sku) { target = tr; return true; }
      return false;
    });
    if (!target) return false;
    if (target.style.display === 'none') {
      target.style.display = '';
      var search = document.getElementById('opSearch');
      if (search) search.value = '';
      var only = document.getElementById('opOnlyFilled');
      if (only) only.checked = false;
    }
    var field = el(focusField, target) || el('.op-count', target) || el('[name="counted_qty[]"]', target);
    target.classList.add('row-flash');
    setTimeout(function () { target.classList.remove('row-flash'); }, 1200);
    if (field) {
      field.focus();
      if (field.select) field.select();
      if (field.scrollIntoView) field.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
    return true;
  }

  /* ---------------- panel SKU belum terdaftar ---------------- */

  function showNotFound(cfg, sku) {
    var panel = el('[data-scan-notfound]', cfg.root);
    if (!panel) return;
    panel.hidden = false;
    el('[data-scan-notfound-sku]', panel).textContent = sku;
    var skuField = el('[data-qc="sku"]', panel);
    if (skuField) skuField.value = sku;
    setStatus(el('[data-scan-status]', cfg.root),
      'SKU <strong>' + esc(sku) + '</strong> belum terdaftar. ' +
      (cfg.canCreate ? 'Klik <strong>Buat &amp; Tambahkan</strong> untuk mendaftarkannya sekarang.'
        : 'Minta Admin mendaftarkannya di menu Produk Master.'), 'err');
    var first = el('[data-qc="brand_id"]', panel) || el('[data-qc-submit]', panel);
    if (first && first.focus) first.focus();
  }

  function hideNotFound(cfg) {
    var panel = el('[data-scan-notfound]', cfg.root);
    if (panel) panel.hidden = true;
  }

  /* ---------------- proses satu hasil scan ---------------- */

  function processScan(cfg, rawSku, opts) {
    opts = opts || {};
    var sku = norm(rawSku);
    hideNotFound(cfg);
    if (sku === '') return;
    var statusBox = el('[data-scan-status]', cfg.root);
    setStatus(statusBox, 'Mencari <strong>' + esc(sku) + '</strong>…', '');

    /* Promise dikembalikan supaya pemanggil (kamera) tahu hasilnya berhasil atau tidak. */
    return apiLookup(sku).then(function (product) {
      /* mode field (form produk) ditangani lebih dulu: kolom SKU harus terisi
         baik SKU-nya sudah terdaftar maupun belum. */
      /* mode pencarian (stok total): isi kolom cari lalu jalankan pencarian */
      if (cfg.mode === 'search') {
        var searchTarget = cfg.targetSel ? document.querySelector(cfg.targetSel) : null;
        if (searchTarget) {
          searchTarget.value = product.sku;     // pakai SKU resmi dari master
          searchTarget.dispatchEvent(new Event('input', { bubbles: true }));
          var form = searchTarget.form;
          setStatus(statusBox, '<strong>' + esc(product.sku) + '</strong> ditemukan — menampilkan stoknya…', 'ok');
          if (form) { form.submit(); return true; }
        }
        return false;
      }

      if (cfg.mode === 'field') {
        var target = cfg.targetSel ? document.querySelector(cfg.targetSel) : null;
        if (target) {
          target.value = sku;
          target.dispatchEvent(new Event('input', { bubbles: true }));
        }
        var ctx = cfg.context;
        var curId = String(cfg.currentId);
        if (product) {
          if (ctx === 'edit' && String(product.id) === curId) {
            setStatus(statusBox, 'SKU <strong>' + esc(sku) + '</strong> cocok dengan produk yang sedang dibuka.', 'ok');
          } else {
            setStatus(statusBox,
              'SKU <strong>' + esc(sku) + '</strong> <strong>sudah terdaftar</strong>'
              + (product.brand_name ? ' (' + esc(product.brand_name) + ')' : '')
              + ' — jangan disimpan sebagai produk baru supaya tidak dobel. '
              + '<a href="products.php?id=' + product.id + '">Buka produk ' + esc(sku) + '</a>.', 'err');
          }
        } else {
          setStatus(statusBox,
            'SKU <strong>' + esc(sku) + '</strong> belum terdaftar — aman untuk disimpan sebagai produk baru.', 'ok');
        }
        if (target) {
          target.focus();
          if (target.select) target.select();   // teks terpilih: ketikan tak sengaja tidak menempel
        }
        return !!target;
      }

      if (!product) {
        if (cfg.mode === 'search') {
          setStatus(statusBox, 'SKU <strong>' + esc(sku) + '</strong> tidak ditemukan di master produk.', 'err');
          var t2 = cfg.targetSel ? document.querySelector(cfg.targetSel) : null;
          if (t2) { t2.focus(); if (t2.select) t2.select(); }
          return false;
        }
        showNotFound(cfg, sku);
        return false;
      }

      if (cfg.mode === 'count') {
        var ok = focusCountField(cfg.listRoot || document, sku, cfg.focusField);
        if (ok) {
          setStatus(statusBox, '<strong>' + esc(sku) + '</strong> siap dihitung — ketik jumlah fisik lalu Enter.', 'ok');
          return true;
        }
        /* belum ada di daftar (mis. di luar filter brand): sisipkan barisnya */
        var injected = injectCountRow(cfg, product);
        if (injected) {
          focusCountField(cfg.listRoot || document, sku, cfg.focusField);
          setStatus(statusBox, '<strong>' + esc(sku) + '</strong> ditambahkan ke daftar hitung — ketik jumlah fisik lalu Enter.', 'ok');
        } else {
          setStatus(statusBox, 'Baris untuk <strong>' + esc(sku) + '</strong> tidak bisa ditambahkan otomatis. Muat ulang halaman lalu hitung ulang.', 'err');
          return false;
        }
        return true;
      }

      var existing = null;
      els('tr', document.getElementById(cfg.bodyId)).some(function (tr) {
        if (rowSku(tr) === sku) { existing = tr; return true; }
        return false;
      });
      if (existing) {
        if (cfg.mode === 'items') {
          /* scan ulang barang yang sama = tambah 1 unit (kecuali terdeteksi scan ganda) */
          if (isBounce(sku)) {
            setStatus(statusBox, 'Kode <strong>' + esc(sku) + '</strong> terbaca dua kali dalam sekejap — yang kedua diabaikan supaya jumlah tidak dobel.', 'warn');
            return false;
          }
          var q = el('[name="item_qty[]"]', existing);
          var next = num(q ? q.value : 0) + 1;
          if (q) q.value = fmt(next);
          existing.classList.add('row-flash');
          setTimeout(function () { existing.classList.remove('row-flash'); }, 1200);
          recalcTable(document.getElementById(cfg.tableId));
          setStatus(statusBox, '<strong>' + esc(sku) + '</strong> sudah di daftar — jumlah menjadi <strong>' + fmt(next) + '</strong>.'
            + listSummary(cfg), 'warn');
          return true;
        }
        var f = el(cfg.focusField, existing);
        existing.classList.add('row-flash');
        setTimeout(function () { existing.classList.remove('row-flash'); }, 1200);
        if (f) { f.focus(); if (f.select) f.select(); }
        setStatus(statusBox, '<strong>' + esc(sku) + '</strong> sudah ada di daftar — ubah jumlahnya bila perlu.', 'warn');
        return true;
      }
      var tr = addItemRow(cfg, product, opts.qty);
      if (tr) {
        lastSameSku[sku] = Date.now();
        setStatus(statusBox, '<strong>' + esc(product.sku) + '</strong> ditambahkan' +
          (product.brand_name ? ' · ' + esc(product.brand_name) : '') +
          ' · stok ' + fmt(product.stock_qty) + ' ' + esc(product.unit || 'pcs') + listSummary(cfg), 'ok');
        return true;
      }
      return false;
    }).catch(function () { return false; });
  }

  /* ---------------- inisialisasi satu blok tools ---------------- */

  function initTools(root) {
    var cfg = cfgFromRoot(root);
    var input = el('[data-scan-input]', root);
    if (!input) return;

    function submitScan() {
      var v = input.value;
      input.value = '';
      if (norm(v) !== '') processScan(cfg, v);
      input.focus();
    }

    input.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' || ev.keyCode === 13) {
        ev.preventDefault();
        submitScan();
      }
    });
    input.addEventListener('change', function () {
      /* sebagian scanner mengirim Tab, bukan Enter */
      if (norm(input.value) !== '') submitScan();
    });

    if (cfg.mode === 'field') {
      /* Enter di kolom SKU form = periksa SKU itu (sama seperti hasil scan).
         Berguna kalau scanner menulis ke kolom SKU langsung, atau saat mengetik manual. */
      var targetField = cfg.targetSel ? document.querySelector(cfg.targetSel) : null;
      if (targetField) {
        targetField.addEventListener('keydown', function (ev) {
          if (ev.key === 'Enter' || ev.keyCode === 13) {
            ev.preventDefault();
            var v = targetField.value;
            input.value = '';
            if (norm(v) !== '') processScan(cfg, v);
          }
        });
      }
    }

    var btn = el('[data-scan-add]', root);
    if (btn) btn.addEventListener('click', function () {
      var body = document.getElementById(cfg.bodyId);
      var tpl = document.getElementById(cfg.tplId);
      if (!body || !tpl) return;
      var tr = document.createElement('tr');
      tr.innerHTML = tpl.innerHTML;
      body.appendChild(tr);
      var skuInp = el('[data-sku-input]', tr);
      if (skuInp) skuInp.focus();
      input.focus();
    });

    /* tombol "Cari" pada mode pencarian (stok total) */
    var submitBtn = el('[data-scan-submit]', root);
    if (submitBtn) submitBtn.addEventListener('click', function () {
      var v = input.value;
      input.value = '';
      if (norm(v) !== '') processScan(cfg, v);
      input.focus();
    });

    var closeQc = el('[data-scan-notfound-close]', root);
    if (closeQc) closeQc.addEventListener('click', function () {
      hideNotFound(cfg);
      input.focus();
    });

    var qcSubmit = el('[data-qc-submit]', root);
    if (qcSubmit) qcSubmit.addEventListener('click', function () {
      var panel = el('[data-scan-notfound]', root);
      var data = {};
      els('[data-qc]', panel).forEach(function (f) {
        data[f.getAttribute('data-qc')] = f.value;
      });
      var sku = norm(data.sku);
      if (sku === '') return;
      qcSubmit.disabled = true;
      setStatus(el('[data-scan-status]', root), 'Menyimpan <strong>' + esc(sku) + '</strong>…', '');
      apiCreate({ csrf: cfg.csrf, data: data }).then(function (res) {
        qcSubmit.disabled = false;
        if (res && res.ok && res.product) {
          cache[sku] = res.product;
          hideNotFound(cfg);
          if (cfg.mode === 'count') {
            if (!focusCountField(cfg.listRoot, sku, cfg.focusField)) {
              injectCountRow(cfg, res.product);
              focusCountField(cfg.listRoot, sku, cfg.focusField);
            }
          } else {
            var tr = addItemRow(cfg, res.product, 1);
            if (!tr) return;
          }
          setStatus(el('[data-scan-status]', root),
            'Produk <strong>' + esc(sku) + '</strong> berhasil dibuat' +
            (res.already ? ' (sudah ada sebelumnya)' : '') + ' dan ditambahkan.', 'ok');
        } else {
          setStatus(el('[data-scan-status]', root),
            esc((res && res.message) || 'Gagal membuat produk baru.'), 'err');
        }
        /* hanya kembalikan fokus ke kolom scan bila tidak ada kolom lain yang difokuskan */
        var a = document.activeElement;
        if (!a || a === document.body || a.tagName === 'BODY' || a === input) {
          if (cfg.mode === 'items') input.focus();
        }
      });
    });

    /* scan ulang dari baris tabel: Enter di kolom SKU baris = proses baris itu */
    root.addEventListener('keydown', function (ev) {
      var rowInput = ev.target.closest ? ev.target.closest('[data-sku-input]') : null;
      if (!rowInput) return;
      if (ev.key === 'Enter' || ev.keyCode === 13) {
        ev.preventDefault();
        var val = rowInput.value;
        var row = rowInput.closest('tr');
        var sku = norm(val);
        if (sku === '') return;
        apiLookup(sku).then(function (product) {
          if (!product) {
            markRow(row, 'unknown');
            showNotFound(cfg, sku);
            return;
          }
          rowInput.value = product.sku;
          markRow(row, 'ok', 'brand: ' + (product.brand_name || '-')
            + (product.size ? ' · ukuran ' + product.size : '')
            + ' · stok: ' + fmt(product.stock_qty) + hppInfo(product, cfg));
          fillPrice(row, product, cfg.priceKey);
          recalcTable(document.getElementById(cfg.tableId));
          var q = el('[name="item_qty[]"]', row);
          if (q) { q.focus(); q.select(); }
        });
      }
    });

    input.addEventListener('focus', function () { hideNotFound(cfg); });
  }

  /* ---------------- kamera (Android/Chrome) ---------------- */

  var camStream = null;
  var camTimer = null;
  var camBusy = false;      // mencegah dua kode diproses bersamaan saat kamera menutup

  function camStatus(text) {
    var s = el('[data-cam-status]', document);
    if (s) s.textContent = text;
  }

  function camStop() {
    if (camTimer) { clearInterval(camTimer); camTimer = null; }
    if (camStream) {
      camStream.getTracks().forEach(function (t) { t.stop(); });
      camStream = null;
    }
    var ov = el('[data-cam-overlay]', document);
    if (ov) ov.hidden = true;
    var v = el('[data-cam-video]', document);
    if (v) v.srcObject = null;
    camBusy = false;
  }

  /** Susun konfigurasi dari atribut blok alat scan (dipakai kamera & tombol Cari). */
  function cfgFromRoot(root) {
    return {
      root: root,
      mode: root.getAttribute('data-mode') || 'items',
      canCreate: root.getAttribute('data-can-create') === '1',
      focusField: root.getAttribute('data-focus-field') || '.count-field',
      priceKey: root.getAttribute('data-price-key') || 'cost_price',
      bodyId: root.getAttribute('data-body') || 'itemBody',
      tplId: root.getAttribute('data-tpl') || 'itemTpl',
      tableId: root.getAttribute('data-table') || 'itemTable',
      listRoot: document.getElementById(root.getAttribute('data-list') || '') || document,
      /* WAJIB ikut: tanpa ini, scan lewat KAMERA tidak bisa mengisi kolom tujuan
         (mis. kolom pencarian di Stok Total atau kolom SKU di form produk). */
      targetSel: root.getAttribute('data-target') || '',
      context: root.getAttribute('data-context') || 'new',
      currentId: root.getAttribute('data-current-id') || '0',
      csrf: root.getAttribute('data-csrf') || ''
    };
  }

  function camStart(root) {
    var cfg = cfgFromRoot(root);
    var ov = el('[data-cam-overlay]', document);
    var video = el('[data-cam-video]', document);
    if (!ov || !video) return;
    ov.hidden = false;

    if (!('BarcodeDetector' in window)) {
      camStatus('Browser ini belum mendukung scan lewat kamera (iPhone/Safari dan sebagian desktop). '
        + 'Pakai scanner barcode/QR Bluetooth atau USB, atau ketik SKU-nya langsung di kolom scan.');
      return;
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      camStatus('Kamera tidak bisa diakses. Buka halaman ini lewat HTTPS (alamat yang benar) lalu coba lagi.');
      return;
    }

    var formats = ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'itf', 'codabar', 'qr_code'];
    camStatus('Menyalakan kamera…');
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 } }, audio: false })
      .then(function (stream) {
        camStream = stream;
        video.srcObject = stream;
        return video.play();
      })
      .then(function () {
        var detector = new window.BarcodeDetector({ formats: formats });
        camStatus('Arahkan kamera ke barcode / QR produk.');
        camTimer = setInterval(function () {
          if (video.readyState < 2) return;
          detector.detect(video).then(function (codes) {
            if (!codes || !codes.length) {
              /* tidak ada kode di frame = barang sudah dijauhkan,
                 jadi kode yang sama boleh terbaca lagi (mis. 3 pcs barang identik) */
              lastCamCode = '';
              return;
            }
            var value = norm(codes[0].rawValue);
            if (value === '' || value === lastCamCode) return;   // masih barang yang sama: jangan dihitung dua kali
            lastCamCode = value;

            /* Praktis: begitu satu kode terbaca, kamera langsung ditutup.
               Pengguna tidak perlu menekan "Tutup" lagi. Kalau hasilnya tidak dikenali
               (SKU tidak ada), kamera dibuka kembali dan pesan errornya tetap terlihat. */
            if (camBusy) return;
            camBusy = true;
            camStop();
            /* kembalikan fokus ke kolom scan supaya barang berikutnya bisa langsung dipindai */
            var scanInput = el('[data-scan-input]', root);
            if (scanInput) { try { scanInput.focus(); } catch (e) { } }
            processScan(cfg, value).then(function (handled) {
              camBusy = false;
              lastCamCode = '';
              if (handled) {
                var s = el('[data-scan-status]', root);
                if (s) setStatus(s, 'Terbaca dari kamera: <strong>' + esc(value) + '</strong>.', 'ok');
              } else {
                /* gagal dikenali: buka kamera lagi supaya bisa langsung coba scan ulang */
                camStart(root);
                camStatus('Kode ' + esc(value) + ' belum dikenali. Arahkan kamera ke barcode/QR lain.');
              }
            });
          }).catch(function () { /* frame gagal dibaca, coba lagi di frame berikutnya */ });
        }, 350);
      })
      .catch(function (err) {
        var msg = 'Kamera tidak bisa dipakai.';
        if (err && (err.name === 'NotAllowedError' || err.name === 'SecurityError')) {
          msg = 'Izin kamera ditolak. Buka pengaturan browser → izinkan kamera untuk situs ini, lalu coba lagi.';
        } else if (err && err.name === 'NotFoundError') {
          msg = 'Tidak ada kamera yang terdeteksi di perangkat ini.';
        }
        camStatus(msg + ' Sebagai pengganti, gunakan scanner Bluetooth/USB atau ketik SKU manual.');
      });
  }

  document.addEventListener('click', function (ev) {
    var openBtn = ev.target.closest('[data-scan-camera]');
    if (openBtn) {
      var root = openBtn.closest('[data-scan-tools]');
      if (root) camStart(root);
      return;
    }
    if (ev.target.closest('[data-cam-close]') || ev.target === el('[data-cam-overlay]', document)) {
      camStop();
      var inp = el('[data-scan-input]', document);
      if (inp) inp.focus();
    }
  });

  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape') camStop();
  });

  /* ---------------- fokus otomatis untuk scanner keyboard ---------------- */

  function isTypingTarget(t) {
    if (!t || !t.tagName) return false;
    var tag = t.tagName.toLowerCase();
    return tag === 'input' || tag === 'textarea' || tag === 'select' || t.isContentEditable;
  }

  document.addEventListener('keydown', function (ev) {
    if (ev.ctrlKey || ev.metaKey || ev.altKey) return;
    if (ev.key === 'Escape') return;
    var overlay = el('[data-cam-overlay]', document);
    if (overlay && !overlay.hidden) return;
    var scanInputs = els('[data-scan-input]');
    if (!scanInputs.length) return;
    var target = scanInputs[0];
    if (isTypingTarget(ev.target)) return;
    /* spasi di atas tombol yang sedang difokus = menekan tombol itu (jangan dirampas) */
    if (ev.key === ' ' && ev.target && ev.target.tagName === 'BUTTON') return;
    if (!ev.key || ev.key.length !== 1) return;
    /* huruf/angka pertama yang "nyasar" di luar kolom input diarahkan ke kolom scan */
    ev.preventDefault();
    target.focus();
    target.value += ev.key;
  });

  function init() {
    tools().forEach(initTools);
    var inputs = els('[data-scan-input]');
    if (inputs.length) {
      /* Autofokus supaya scanner siap pakai begitu halaman terbuka.
         Jangan pernah merebut fokus yang sudah dipegang operator/field lain:
         timer dibatalkan begitu ada fokus atau tombol yang ditekan lebih dulu. */
      var cancelAuto = function () {
        if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; }
      };
      var firstTools = inputs[0].closest('[data-scan-tools]');
      var isFieldMode = firstTools && firstTools.getAttribute('data-mode') === 'field';
      /* data-autofocus="0": jangan buka keyboard otomatis. Dipakai di halaman yang punya
         kolom pencarian sendiri (mis. Stok Total) supaya keyboard tidak "muncul sendiri"
         dan merebut tempat mengetik. Scanner tetap jalan lewat penangkap karakter nyasar. */
      var noAutofocus = firstTools && firstTools.getAttribute('data-autofocus') === '0';
      autoTimer = setTimeout(function () {
        autoTimer = null;
        var a = document.activeElement;
        var idle = !a || a === document.body || a.tagName === 'BODY';
        if (!idle) return;
        if (isFieldMode || noAutofocus) {
          /* mode field: biarkan autofocus form menuju kolom SKU, jangan direbut */
          return;
        }
        try { inputs[0].focus(); } catch (e) { /* diabaikan */ }
      }, 60);
      document.addEventListener('focusin', function (ev) {
        if (ev.target !== inputs[0]) cancelAuto();
      }, true);
      document.addEventListener('keydown', function () { cancelAuto(); }, true);
    }

    /* Enter di kolom hitung fisik (mode count) pindah ke baris pencarian berikutnya */
    document.addEventListener('keydown', function (ev) {
      if (ev.key !== 'Enter' || !ev.target.classList) return;
      if (!ev.target.classList.contains('op-count') && !ev.target.classList.contains('count-field')) return;
      ev.preventDefault();
      var inp = el('[data-scan-input]', document);
      if (inp) inp.focus();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  /* pemantauan internal (dipakai uji otomatis & untuk menelusuri masalah kamera) */
  window.skuScan = {
    processScan: processScan, camStart: camStart, camStop: camStop, cache: cache,
    camState: function () { return { busy: camBusy, lastCode: lastCamCode }; }
  };
})();
