/* Inventori — helper UI (vanilla JS, tanpa dependensi eksternal) */
(function () {
  'use strict';

  /* ---- konfirmasi aksi berbahaya ---- */
  document.addEventListener('click', function (ev) {
    var el = ev.target.closest('[data-confirm]');
    if (!el) return;
    if (!window.confirm(el.getAttribute('data-confirm'))) {
      ev.preventDefault();
      ev.stopPropagation();
    }
  });

  /* ---- tombol cetak ---- */
  document.addEventListener('click', function (ev) {
    var el = ev.target.closest('[data-print]');
    if (!el) return;
    ev.preventDefault();
    window.print();
  });

  /* ---- void: isi alasan lewat prompt lalu submit form ---- */
  document.addEventListener('submit', function (ev) {
    var form = ev.target;
    if (!form.matches('[data-need-reason]')) return;
    var field = form.querySelector('[name=void_reason]');
    if (field && field.value.trim() === '') {
      var r = window.prompt('Alasan void / pembatalan dokumen:');
      if (r === null || r.trim() === '') {
        ev.preventDefault();
        return;
      }
      field.value = r.trim();
    }
  });

  /* ---- baris item dinamis (inbound / outbound / retur) ---- */
  window.itemRows = {
    add: function (opts) {
      var body = document.getElementById(opts.bodyId);
      if (!body) return;
      var tpl = document.getElementById(opts.tplId);
      if (!tpl) return;
      var html = tpl.innerHTML;
      var idx = Date.now() + Math.floor(Math.random() * 1000);
      html = html.replace(/__i__/g, idx);
      var tr = document.createElement('tr');
      tr.innerHTML = html;
      body.appendChild(tr);
      var skuInp = tr.querySelector('[data-sku-input]');
      if (skuInp) skuInp.focus();
      window.itemRows.recalc(opts);
    },
    remove: function (btn) {
      var tr = btn.closest('tr');
      if (!tr) return;
      var body = tr.parentNode;
      tr.remove();
      window.itemRows.recalc({ tableId: body.closest('table').id, stockMap: window.PRODUCT_STOCK || {} });
    },
    recalc: function (opts) {
      var table = document.getElementById(opts.tableId);
      if (!table) return;
      var rows = table.querySelectorAll('tbody tr');

      /* format uang: tabel dengan data-money="1" menampilkan Rp, bukan angka polos */
      var money = table.getAttribute('data-money') === '1';
      var show = money ? fmtMoney : fmt;

      /* pengaturan diskon dokumen (dipakai form barang masuk; tabel lain tidak punya) */
      var discTypeEl = document.getElementById(table.getAttribute('data-discount-type') || '');
      var discValueEl = document.getElementById(table.getAttribute('data-discount-value') || '');
      var subCell = document.getElementById(table.getAttribute('data-subtotal-id') || '');
      var discCell = document.getElementById(table.getAttribute('data-discount-amount-id') || '');
      var finalCell = document.getElementById(table.getAttribute('data-final-id') || '');
      var gross = 0;
      var perRow = [];

      Array.prototype.forEach.call(rows, function (tr) {
        /* qty selalu bulat: baris dihitung dengan angka yang sama seperti saat disimpan */
        var q = Math.round(num(tr.querySelector('[name="item_qty[]"]')));
        var p = num(tr.querySelector('[name="item_price[]"]'));
        var sub = q * p;
        var cell = tr.querySelector('.row-subtotal');
        if (cell) cell.textContent = show(sub);
        gross += sub;
        perRow.push({ tr: tr, qty: q, sub: sub });
      });

      /* diskon dokumen dibagi proporsional ke setiap baris */
      var discType = discTypeEl ? discTypeEl.value : 'amount';
      var discValue = discValueEl ? num(discValueEl.value) : 0;
      var disc = 0;
      if (discValue > 0 && gross > 0) {
        disc = discType === 'percent' ? gross * Math.min(100, discValue) / 100 : Math.min(gross, discValue);
      }
      disc = round2(disc);

      var allocated = 0;
      perRow.forEach(function (row, idx) {
        var share = 0;
        if (disc > 0 && gross > 0) {
          if (idx === perRow.length - 1) {
            share = round2(disc - allocated);
          } else {
            share = round2(disc * row.sub / gross);
            allocated += share;
          }
        }
        var net = round2(row.sub - share);
        var unitNet = row.qty > 0 ? round2(net / row.qty) : 0;
        var netCell = row.tr.querySelector('.row-net');
        if (netCell) netCell.textContent = show(net);
        var unitNetCell = row.tr.querySelector('.row-unit-net');
        if (unitNetCell) unitNetCell.textContent = show(unitNet);
        var unitDiscCell = row.tr.querySelector('.row-unit-disc');
        if (unitDiscCell) {
          unitDiscCell.textContent = (share > 0 && row.qty > 0) ? ('diskon ' + show(round2(share / row.qty)) + ' / satuan') : '';
        }
        var shareCell = row.tr.querySelector('.row-disc-share');
        if (shareCell) shareCell.textContent = share > 0 ? show(share) : '-';
      });

      if (subCell) subCell.textContent = show(gross);
      if (discCell) discCell.textContent = show(disc);
      if (finalCell) finalCell.textContent = show(round2(gross - disc));

      var totQty = 0;
      perRow.forEach(function (r) { totQty += r.qty; });
      var tq = document.getElementById(opts.totalQtyId);
      var ta = document.getElementById(opts.totalAmountId);
      if (tq) tq.textContent = fmtQty(totQty);
      if (ta) ta.textContent = show(round2(gross - disc));

      /* kabarkan ke halaman (mis. ringkasan diskon di form barang masuk) */
      try {
        document.dispatchEvent(new CustomEvent('items:recalc', { detail: { tableId: table.id, gross: gross, discount: disc, total: round2(gross - disc) } }));
      } catch (e) { /* browser lama tanpa CustomEvent: abaikan */ }
    }
  };

  function fmt(n) {
    var dec = Math.abs(n - Math.round(n)) > 0.0001 ? 2 : 0;
    return new Intl.NumberFormat('id-ID', { minimumFractionDigits: dec, maximumFractionDigits: dec }).format(n || 0);
  }
  window.fmtNum = fmt;

  /* Qty selalu bilangan bulat (tanpa koma desimal) — sama dengan fmt_qty() di PHP.
     Nilai dibulatkan, bukan sekadar dipotong, supaya angka di layar = nilai yang disimpan. */
  function fmtQty(n) {
    n = Math.round(Number(n) || 0);
    return new Intl.NumberFormat('id-ID', { minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(n);
  }
  window.fmtQty = fmtQty;

  /* angka rupiah: selalu "Rp 1.234.567" (tanpa desimal bila bulat) */
  function fmtMoney(n) {
    n = n || 0;
    var dec = Math.abs(n - Math.round(n)) > 0.004 ? 2 : 0;
    return 'Rp ' + new Intl.NumberFormat('id-ID', { minimumFractionDigits: dec, maximumFractionDigits: dec }).format(n);
  }
  window.fmtMoney = fmtMoney;

  /* Baca angka dari input apa pun.
     Aturannya SAMA PERSIS dengan parse_num() di includes/helpers.php
     (diuji oleh tests/parse_check.sh) supaya angka tampil & tersimpan konsisten:
       - ada "." dan ","  -> pemisah paling belakang = tanda desimal
       - hanya "." atau "," dengan tepat 3 angka di belakang dan angka depan 1-3 digit
         -> pemisah ribuan ("50.000" -> 50000, "1,000" -> 1000)
       - selain itu desimal ("12.3" -> 12.3, "1,5" -> 1.5) */
  function num(v) {
    if (v && v.value !== undefined) v = v.value;
    var raw = String(v === null || v === undefined ? '' : v).trim();
    if (raw === '') return 0;
    var neg = raw.charAt(0) === '-';
    var s = raw.replace(/[^\d.,]/g, '');
    if (s === '' || s === '.' || s === ',') return 0;
    var hasDot = s.indexOf('.') !== -1;
    var hasComma = s.indexOf(',') !== -1;
    var value;
    if (hasDot && hasComma) {
      if (s.lastIndexOf(',') > s.lastIndexOf('.')) {
        s = s.replace(/\./g, '').replace(',', '.');
      } else {
        s = s.replace(/,/g, '');
      }
      value = parseFloat(s);
    } else if (!hasDot && !hasComma) {
      value = parseFloat(s);
    } else {
      var sep = hasDot ? '.' : ',';
      var parts = s.split(sep);
      var last = parts[parts.length - 1];
      var first = parts[0].replace(/^0+/, '');
      var isThousands = last !== '' && last.length === 3 && first !== '' && first.length <= 3;
      value = isThousands ? parseFloat(parts.join('')) : parseFloat(s.replace(sep, '.'));
    }
    if (isNaN(value)) value = 0;
    return neg ? -value : value;
  }
  window.numID = num;

  function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }

  /* ---- tombol kurang/tambah jumlah (qty) ---- */
  document.addEventListener('click', function (ev) {
    var btn = ev.target.closest ? ev.target.closest('[data-qty-step]') : null;
    if (!btn) return;
    var row = btn.closest('tr');
    if (!row) return;
    var input = row.querySelector('[name="item_qty[]"]');
    if (!input || input.readOnly || input.disabled) return;
    var step = parseFloat(btn.getAttribute('data-qty-step')) || 0;
    var current = input.value.trim() === '' ? 0 : num(input.value);
    var next = current + step;
    if (next < 0) next = 0;
    if (next > 999999) next = 999999;
    input.value = fmtQty(next);
    input.dispatchEvent(new Event('input', { bubbles: true }));

    /* Fokus sengaja TIDAK dipindahkan ke kolom scan: pengguna harus bisa menekan
       tombol −/+ berkali-kali untuk menyesuaikan jumlah pada baris itu.
       Alur scanner tetap aman karena fokus berada di tombol (bukan kolom input),
       sehingga kode scanner yang "nyasar" tetap diarahkan ke kolom scan oleh
       penangkap karakter di assets/sku.js. */
  });

  /* ---- kolom qty hanya menerima angka (huruf tidak boleh membuat baris jadi nol) ---- */
  function sanitizeQty(input) {
    var v = input.value;
    var cleaned = v.replace(/[^0-9.,]/g, '');
    /* hanya boleh satu tanda desimal */
    var firstSep = cleaned.search(/[.,]/);
    if (firstSep !== -1) {
      cleaned = cleaned.slice(0, firstSep + 1) + cleaned.slice(firstSep + 1).replace(/[.,]/g, '');
    }
    if (cleaned !== v) {
      input.value = cleaned;
    }
  }

  /* ---- qty selalu dibulatkan jadi bilangan bulat saat kolom ditinggalkan ---- */
  var QTY_FIELDS = ['item_qty[]', 'item_after[]', 'counted_qty[]'];
  document.addEventListener('change', function (ev) {
    var t = ev.target;
    if (!t || !t.name || QTY_FIELDS.indexOf(t.name) === -1) return;
    var raw = String(t.value === undefined || t.value === null ? '' : t.value).trim();
    if (raw === '') return;                  // kosong = belum dihitung, biarkan kosong
    var v = Math.round(num(raw));
    if (v < 0) v = 0;
    var out = String(v);
    if (t.value === out) return;
    t.value = out;                           // mis. "0,75" -> "1"
    t.dispatchEvent(new Event('input', { bubbles: true }));
  });

  /* perubahan pada kolom diskon dokumen juga memicu hitung ulang */
  function tableForDiscount(ev) {
    var t = ev.target.closest ? ev.target.closest('table[data-items]') : null;
    if (!t && ev.target.hasAttribute && ev.target.hasAttribute('data-discount-input')) {
      t = document.querySelector('table[data-items][data-discount-type]');
    }
    return t;
  }

  document.addEventListener('change', function (ev) {
    var table = tableForDiscount(ev);
    if (!table) return;
    window.itemRows.recalc({
      tableId: table.id,
      stockMap: window.PRODUCT_STOCK || {},
      totalQtyId: table.getAttribute('data-total-qty') || '',
      totalAmountId: table.getAttribute('data-total-amount') || ''
    });
  });

  document.addEventListener('input', function (ev) {
    if (ev.target && ev.target.name === 'item_qty[]') sanitizeQty(ev.target);
    var table = tableForDiscount(ev);
    if (!table) return;
    window.itemRows.recalc({
      tableId: table.id,
      stockMap: window.PRODUCT_STOCK || {},
      totalQtyId: table.getAttribute('data-total-qty') || '',
      totalAmountId: table.getAttribute('data-total-amount') || ''
    });
  });

  /* catatan: pengisian harga & info stok saat SKU di-scan/ketik ditangani assets/sku.js */
})();
