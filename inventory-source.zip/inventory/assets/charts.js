/* Render grafik SVG sederhana tanpa library eksternal.
   Dipakai oleh:
     renderLineChart(el, {labels, series:[{name,color,values}], format:'number'|'money', unit:'unit'})
     renderBarChart(el, {rows:[{label,value,display,href,color,meta}], format, unit})
     renderPieChart(el, {rows:[{label,value,display,href,color,meta}], centerLabel, centerValue, unit})

   Semua grafik menampilkan angkanya saat kursor diarahkan (tooltip), dan
   diagram lingkaran bisa diklik untuk membuka data terkait (href). */
(function () {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';
  var PALETTE = ['#4F46E5', '#8B5CF6', '#38BDF8', '#F472B6', '#F59E0B', '#10B981', '#6366F1', '#EC4899', '#14B8A6', '#F97316'];

  /**
   * Gaya yang dibutuhkan grafik ditanam sendiri oleh berkas ini.
   *
   * Kenapa: dulu gaya tooltip/legenda hanya ada di assets/app.css. Kalau browser
   * (terutama WebView aplikasi Android) masih memakai app.css lama, tooltip tampil
   * sebagai teks polos di pojok grafik — terlihat seperti "fitur tidak jalan".
   * Dengan menanam gaya di sini, grafik tetap benar walau CSS halaman tertinggal.
   */
  function ensureStyles() {
    if (document.getElementById('charts-core-style')) return;
    var css = ''
      + '.chart-tip{position:absolute;z-index:8;pointer-events:none;transform:translate(-50%,-132%);'
      + 'min-width:130px;max-width:240px;padding:9px 11px;border-radius:11px;background:rgba(31,27,58,.95);'
      + 'color:#fff;font:400 12px/1.5 Inter,system-ui,-apple-system,"Segoe UI",sans-serif;text-align:left;'
      + 'box-shadow:0 10px 24px rgba(31,27,58,.28)}\n'
      + '.chart-tip[hidden]{display:none !important}\n'
      + '.chart-tip .tip-head{display:block;font-weight:650;margin-bottom:4px;color:#fff}\n'
      + '.chart-tip .tip-row{display:flex;align-items:center;gap:6px;flex-wrap:wrap;color:rgba(255,255,255,.86)}\n'
      + '.chart-tip .tip-row strong{color:#fff}\n'
      + '.chart-tip .tip-hint{color:rgba(255,255,255,.6);font-size:11px;display:block;margin-top:4px;padding-left:14px}\n'
      + '.chart-tip .dot{width:9px;height:9px;border-radius:3px;display:inline-block;background:#fff}\n'
      + '.bar-row{display:grid;grid-template-columns:128px 1fr 92px;align-items:center;gap:12px;padding:6px;border-radius:9px}\n'
      + '.bar-row .bar-label{color:#635F82;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n'
      + '.bar-row .bar-value{text-align:right;font-weight:650}\n'
      + '.bar-row.bar-link{cursor:pointer}\n'
      + '.bar-row.bar-link:hover{background:rgba(79,70,229,.08);text-decoration:none}\n'
      + '.pie-slice{transition:filter .12s ease}\n'
      + '.pie-slice.on{filter:brightness(1.09)}\n'
      + 'svg [role="link"]{cursor:pointer}\n'
      + '.pie-legend{display:grid;grid-template-columns:1fr;gap:2px;padding-top:14px;margin-top:6px;'
      + 'border-top:1px solid rgba(99,95,130,.18);font:400 12.5px/1.4 Inter,system-ui,-apple-system,"Segoe UI",sans-serif}\n'
      + '.pie-legend-item{display:grid;grid-template-columns:auto 1fr auto 52px;align-items:center;gap:8px;'
      + 'padding:5px 7px;border-radius:8px;color:#1F1B3A;text-decoration:none}\n'
      + '.pie-legend-item.has-link{cursor:pointer}\n'
      + '.pie-legend-item.has-link:hover{background:rgba(79,70,229,.08)}\n'
      + '.pie-legend-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;color:#635F82}\n'
      + '.pie-legend-val{font-variant-numeric:tabular-nums;font-weight:650;white-space:nowrap}\n'
      + '.pie-legend-pct{text-align:right;color:#8B87A6;font-variant-numeric:tabular-nums}\n';
    var st = document.createElement('style');
    st.id = 'charts-core-style';
    st.textContent = css;
    (document.head || document.documentElement).appendChild(st);
  }

  function svgEl(w, h) {
    var s = document.createElementNS(NS, 'svg');
    s.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
    s.setAttribute('preserveAspectRatio', 'none');
    s.style.width = '100%';
    s.style.height = h + 'px';
    s.style.display = 'block';
    return s;
  }

  function el(name, attrs) {
    var n = document.createElementNS(NS, name);
    for (var k in attrs) n.setAttribute(k, attrs[k]);
    return n;
  }

  function niceMax(v) {
    if (v <= 0) return 10;
    var p = Math.pow(10, Math.floor(Math.log10(v)));
    var n = Math.ceil(v / p);
    if (n <= 1) n = 1;
    return n * p;
  }

  function shortNum(n) {
    if (Math.abs(n) >= 1000000) return (n / 1000000).toFixed(1).replace('.0', '') + 'jt';
    if (Math.abs(n) >= 1000) return (n / 1000).toFixed(1).replace('.0', '') + 'rb';
    return Math.round(n * 100) / 100 + '';
  }

  /* angka penuh (bukan dipendekkan) untuk tooltip: 1.234.567 */
  function fullNum(n) {
    if (window.fmtQty) return window.fmtQty(n);
    return new Intl.NumberFormat('id-ID', { maximumFractionDigits: 0 }).format(Math.round(n || 0));
  }

  function money(n) {
    if (window.fmtMoney) return window.fmtMoney(n);
    return 'Rp ' + fullNum(n);
  }

  function valueFmt(cfg) {
    return cfg && cfg.format === 'money' ? money : fullNum;
  }

  function pct(part, total) {
    if (!total) return '0%';
    return (part / total * 100).toFixed(1).replace('.', ',') + '%';
  }

  function esc(s) {
    return String(s === undefined || s === null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /* ---------------- tooltip bersama ---------------- */

  /**
   * Kotak keterangan yang mengikuti kursor. Host dibuat position:relative
   * supaya posisi tooltip dihitung dari kotak grafiknya, bukan dari halaman.
   */
  function makeTip(host) {
    host.style.position = 'relative';
    var tip = document.createElement('div');
    tip.className = 'chart-tip';
    tip.setAttribute('aria-hidden', 'true');
    tip.hidden = true;
    host.appendChild(tip);
    return {
      show: function (html, ev) {
        tip.innerHTML = html;
        tip.hidden = false;
        var r = host.getBoundingClientRect();
        var x = ev.clientX - r.left;
        var y = ev.clientY - r.top;
        /* jaga tooltip tetap di dalam kotak grafik */
        var w = tip.offsetWidth || 160;
        var half = w / 2;
        if (x - half < 4) x = half + 4;
        if (x + half > r.width - 4) x = r.width - half - 4;
        if (y < 60) y = 60;
        tip.style.left = x + 'px';
        tip.style.top = y + 'px';
      },
      hide: function () { tip.hidden = true; }
    };
  }

  function tipRows(rows) {
    return rows.map(function (r) {
      return '<span class="tip-row"><i class="dot" style="background:' + r.color + '"></i>'
        + esc(r.name) + ': <strong>' + r.value + '</strong></span>';
    }).join('');
  }

  /* ---------------- grafik garis (tren) ---------------- */

  window.renderLineChart = function (elOrId, cfg) {
    var host = typeof elOrId === 'string' ? document.getElementById(elOrId) : elOrId;
    if (!host) return;
    ensureStyles();
    host.innerHTML = '';
    var labels = cfg.labels || [];
    var series = cfg.series || [];
    if (!labels.length) {
      host.innerHTML = '<div class="empty">Belum ada data untuk ditampilkan.</div>';
      return;
    }
    var fv = valueFmt(cfg);
    var W = Math.max(560, labels.length * 58);
    var H = 240, PL = 52, PR = 14, PT = 14, PB = 30;
    var maxVal = 0;
    series.forEach(function (s) {
      s.values.forEach(function (v) { if (v > maxVal) maxVal = v; });
    });
    var top = niceMax(maxVal);
    var iw = W - PL - PR, ih = H - PT - PB;
    var svg = svgEl(W, H);

    for (var g = 0; g <= 4; g++) {
      var y = PT + ih - (ih * g / 4);
      svg.appendChild(el('line', { x1: PL, y1: y, x2: W - PR, y2: y, stroke: 'rgba(99,95,130,.16)', 'stroke-width': 1 }));
      var t = el('text', { x: PL - 8, y: y + 4, 'text-anchor': 'end', 'font-size': 10.5, fill: '#8B87A6' });
      t.textContent = shortNum(top * g / 4);
      svg.appendChild(t);
    }

    var step = labels.length > 1 ? iw / (labels.length - 1) : 0;
    var every = Math.ceil(labels.length / 14);

    labels.forEach(function (lb, i) {
      if (i % every !== 0) return;
      var x = PL + step * i;
      var t = el('text', { x: x, y: H - 10, 'text-anchor': 'middle', 'font-size': 10.5, fill: '#8B87A6' });
      t.textContent = lb;
      svg.appendChild(t);
    });

    series.forEach(function (s) {
      var color = s.color || '#4F46E5';
      var pts = s.values.map(function (v, i) {
        var x = PL + step * i;
        var y = PT + ih - (ih * (v / top));
        return [x, y];
      });
      var d = pts.map(function (p, i) { return (i ? 'L' : 'M') + p[0].toFixed(1) + ',' + p[1].toFixed(1); }).join(' ');
      if (series.length === 1) {
        var area = d + ' L' + (PL + step * (pts.length - 1)).toFixed(1) + ',' + (PT + ih) + ' L' + PL + ',' + (PT + ih) + ' Z';
        var grad = el('linearGradient', { id: 'lg' + Math.random().toString(36).slice(2, 7), x1: 0, y1: 0, x2: 0, y2: 1 });
        grad.appendChild(el('stop', { offset: '0%', 'stop-color': color, 'stop-opacity': '.28' }));
        grad.appendChild(el('stop', { offset: '100%', 'stop-color': color, 'stop-opacity': '0' }));
        var defs = el('defs', {});
        defs.appendChild(grad);
        svg.appendChild(defs);
        svg.appendChild(el('path', { d: area, fill: 'url(#' + grad.getAttribute('id') + ')' }));
      }
      svg.appendChild(el('path', { d: d, fill: 'none', stroke: color, 'stroke-width': 2.2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }));
      pts.forEach(function (p, i) {
        var c = el('circle', { cx: p[0], cy: p[1], r: 3.2, fill: '#fff', stroke: color, 'stroke-width': 2 });
        var title = el('title', {});
        title.textContent = labels[i] + ': ' + fv(s.values[i]);
        c.appendChild(title);
        svg.appendChild(c);
      });
    });

    /* garis bantu + titik aktif yang mengikuti kursor (data tren tampil di tooltip) */
    var guide = el('line', {
      x1: PL, y1: PT, x2: PL, y2: PT + ih,
      stroke: 'rgba(79,70,229,.5)', 'stroke-width': 1, 'stroke-dasharray': '3 3', opacity: 0
    });
    svg.appendChild(guide);
    var actives = series.map(function (s) {
      var c = el('circle', {
        cx: PL, cy: PT, r: 5, fill: '#fff',
        stroke: s.color || '#4F46E5', 'stroke-width': 2.5, opacity: 0
      });
      c.style.pointerEvents = 'none';
      svg.appendChild(c);
      return c;
    });

    var box = document.createElement('div');
    box.className = 'chart-box';
    box.style.overflowX = 'auto';
    box.appendChild(svg);
    host.appendChild(box);

    var tip = makeTip(host);
    var unit = cfg.unit ? ' ' + cfg.unit : '';

    function clear() {
      guide.setAttribute('opacity', 0);
      actives.forEach(function (c) { c.setAttribute('opacity', 0); });
      tip.hide();
    }

    function move(ev) {
      var r = svg.getBoundingClientRect();
      if (!r.width) return;
      var xInSvg = (ev.clientX - r.left) * (W / r.width);
      var i = step > 0 ? Math.round((xInSvg - PL) / step) : 0;
      if (i < 0) i = 0;
      if (i > labels.length - 1) i = labels.length - 1;
      var px = PL + step * i;
      guide.setAttribute('x1', px);
      guide.setAttribute('x2', px);
      guide.setAttribute('opacity', 1);
      var rows = series.map(function (s, si) {
        var v = s.values[i] || 0;
        var y = PT + ih - (ih * (v / top));
        actives[si].setAttribute('cx', px);
        actives[si].setAttribute('cy', y);
        actives[si].setAttribute('opacity', 1);
        return { name: s.name || 'Nilai', color: s.color || '#4F46E5', value: fv(v) + unit };
      });
      tip.show('<span class="tip-head">' + esc(labels[i]) + '</span>' + tipRows(rows), ev);
    }

    svg.addEventListener('pointermove', move);
    svg.addEventListener('pointerdown', move);
    svg.addEventListener('pointerleave', clear);

    if (series.length > 1 || (series[0] && series[0].name)) {
      var lg = document.createElement('div');
      lg.className = 'chart-legend';
      series.forEach(function (s) {
        var sp = document.createElement('span');
        sp.innerHTML = '<i class="dot" style="background:' + (s.color || '#4F46E5') + '"></i>' + (s.name || '');
        lg.appendChild(sp);
      });
      host.appendChild(lg);
    }
  };

  /* ---------------- grafik batang ---------------- */

  window.renderBarChart = function (elOrId, cfg) {
    var host = typeof elOrId === 'string' ? document.getElementById(elOrId) : elOrId;
    if (!host) return;
    ensureStyles();
    host.innerHTML = '';
    var rows = cfg.rows || [];
    if (!rows.length) {
      host.innerHTML = '<div class="empty">Belum ada data untuk ditampilkan.</div>';
      return;
    }
    var fv = valueFmt(cfg);
    var total = 0;
    rows.forEach(function (r) { total += Math.max(0, r.value); });
    var maxVal = Math.max.apply(null, rows.map(function (r) { return Math.abs(r.value); }));
    var top = niceMax(maxVal);
    var tip = makeTip(host);

    rows.forEach(function (r, i) {
      var color = r.color || PALETTE[i % PALETTE.length];
      var wrap = document.createElement(r.href ? 'a' : 'div');
      wrap.className = 'bar-row' + (r.href ? ' bar-link' : '');
      if (r.href) { wrap.setAttribute('href', r.href); wrap.title = 'Buka data terkait: ' + r.label; }
      var label = document.createElement('div');
      label.className = 'small bar-label';
      label.textContent = r.label;
      var track = document.createElement('div');
      track.className = 'progress';
      track.style.height = '12px';
      var bar = document.createElement('i');
      var pctWidth = top > 0 ? Math.max(1.5, (Math.abs(r.value) / top) * 100) : 0;
      bar.style.width = pctWidth + '%';
      bar.style.background = color;
      track.appendChild(bar);
      var val = document.createElement('div');
      val.className = 'small mono bar-value';
      val.textContent = r.display !== undefined ? r.display : fv(r.value);
      wrap.appendChild(label);
      wrap.appendChild(track);
      wrap.appendChild(val);

      var shown = r.display !== undefined ? r.display : fv(r.value);
      var html = '<span class="tip-head">' + esc(r.label) + '</span>'
        + '<span class="tip-row"><i class="dot" style="background:' + color + '"></i>Jumlah: <strong>' + esc(shown) + '</strong></span>'
        + (total > 0 ? '<span class="tip-row">Porsi: <strong>' + pct(Math.max(0, r.value), total) + '</strong> dari total</span>' : '')
        + (r.meta ? '<span class="tip-row">' + esc(r.meta) + '</span>' : '')
        + (r.href ? '<span class="tip-row tip-hint">klik untuk melihat datanya</span>' : '');
      wrap.addEventListener('pointerenter', function (ev) { tip.show(html, ev); });
      wrap.addEventListener('pointermove', function (ev) { tip.show(html, ev); });
      wrap.addEventListener('pointerleave', function () { tip.hide(); });

      host.appendChild(wrap);
    });
  };

  /* ---------------- diagram lingkaran (donut) ---------------- */

  /**
   * Diagram lingkaran yang setiap potongannya bisa diklik (cfg.rows[i].href).
   * Angka tiap potongan tampil saat kursor diarahkan, dan legenda di bawahnya
   * juga bisa diklik supaya brand kecil (potongan tipis) tetap mudah dibuka.
   */
  window.renderPieChart = function (elOrId, cfg) {
    var host = typeof elOrId === 'string' ? document.getElementById(elOrId) : elOrId;
    if (!host) return;
    ensureStyles();
    host.innerHTML = '';
    var rows = (cfg.rows || []).filter(function (r) { return isFinite(r.value) && r.value > 0; });
    if (!rows.length) {
      host.innerHTML = '<div class="empty">Belum ada data untuk ditampilkan.</div>';
      return;
    }
    var fv = valueFmt(cfg);
    var unit = cfg.unit ? ' ' + cfg.unit : '';
    var total = 0;
    rows.forEach(function (r) { total += r.value; });

    var W = 300, H = 300, CX = 150, CY = 150, R = 124, RI = 76;
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', cfg.title || 'Diagram lingkaran');
    svg.style.display = 'block';
    svg.style.width = '100%';
    svg.style.maxWidth = '300px';
    svg.style.height = 'auto';
    svg.style.margin = '0 auto';
    svg.style.overflow = 'visible';

    function arcPath(a0, a1) {
      var large = (a1 - a0) > Math.PI ? 1 : 0;
      var x0 = CX + R * Math.cos(a0), y0 = CY + R * Math.sin(a0);
      var x1 = CX + R * Math.cos(a1), y1 = CY + R * Math.sin(a1);
      var x2 = CX + RI * Math.cos(a1), y2 = CY + RI * Math.sin(a1);
      var x3 = CX + RI * Math.cos(a0), y3 = CY + RI * Math.sin(a0);
      return ['M', x0.toFixed(2), y0.toFixed(2),
        'A', R, R, 0, large, 1, x1.toFixed(2), y1.toFixed(2),
        'L', x2.toFixed(2), y2.toFixed(2),
        'A', RI, RI, 0, large, 0, x3.toFixed(2), y3.toFixed(2), 'Z'].join(' ');
    }

    var tip = makeTip(host);
    var slices = [];

    /* cincin latar supaya bentuk donut tetap terlihat di bagian kosong */
    svg.appendChild(el('circle', {
      cx: CX, cy: CY, r: (R + RI) / 2, fill: 'none',
      stroke: 'rgba(99,95,130,.12)', 'stroke-width': R - RI
    }));

    var start = -Math.PI / 2;
    var gap = rows.length > 1 ? 0.014 : 0;
    rows.forEach(function (r, i) {
      var frac = r.value / total;
      var end = start + frac * Math.PI * 2;
      var color = r.color || PALETTE[i % PALETTE.length];
      var common = { fill: color, stroke: '#fff', 'stroke-width': 1.2 };
      var shape;
      if (frac >= 0.9999) {
        shape = el('circle', {
          cx: CX, cy: CY, r: (R + RI) / 2, fill: 'none',
          stroke: color, 'stroke-width': R - RI
        });
      } else {
        shape = el('path', Object.assign({ d: arcPath(start + gap / 2, end - gap / 2) }, common));
      }
      shape.setAttribute('class', 'pie-slice');
      if (r.href) {
        shape.setAttribute('tabindex', '0');
        shape.setAttribute('role', 'link');
      }
      var title = el('title', {});
      title.textContent = r.label + ': ' + (r.display !== undefined ? r.display : fv(r.value)) + ' (' + pct(r.value, total) + ')';
      shape.appendChild(title);

      var html = '<span class="tip-head">' + esc(r.label) + '</span>'
        + '<span class="tip-row"><i class="dot" style="background:' + color + '"></i>'
        + (cfg.format === 'money' ? 'Nilai: <strong>' : 'Jumlah: <strong>')
        + esc(r.display !== undefined ? r.display : fv(r.value) + unit) + '</strong></span>'
        + '<span class="tip-row">Porsi: <strong>' + pct(r.value, total) + '</strong> dari total</span>'
        + (r.meta ? '<span class="tip-row">' + esc(r.meta) + '</span>' : '')
        + (r.href ? '<span class="tip-row tip-hint">klik untuk melihat produk brand ini</span>' : '');

      shape.addEventListener('pointerenter', function (ev) {
        shape.classList.add('on');
        tip.show(html, ev);
      });
      shape.addEventListener('pointermove', function (ev) { tip.show(html, ev); });
      shape.addEventListener('pointerleave', function () {
        shape.classList.remove('on');
        tip.hide();
      });
      if (r.href) {
        shape.addEventListener('click', function () { window.location.href = r.href; });
        shape.addEventListener('keydown', function (ev) {
          if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); window.location.href = r.href; }
        });
      }
      svg.appendChild(shape);
      slices.push({ row: r, color: color });
      start = end;
    });

    /* angka total di tengah donut */
    var cl = el('text', { x: CX, y: CY - 4, 'text-anchor': 'middle', 'font-size': 13, fill: '#635F82' });
    cl.textContent = cfg.centerLabel || 'Total';
    svg.appendChild(cl);
    var cv = el('text', { x: CX, y: CY + 20, 'text-anchor': 'middle', 'font-size': 19, 'font-weight': 700, fill: '#1F1B3A' });
    cv.textContent = cfg.centerValue !== undefined ? cfg.centerValue : fv(total);
    svg.appendChild(cv);

    host.appendChild(svg);

    /* legenda: nama brand + jumlah + porsi, bisa diklik */
    var lg = document.createElement('div');
    lg.className = 'pie-legend';
    slices.forEach(function (s) {
      var item = document.createElement(s.row.href ? 'a' : 'div');
      item.className = 'pie-legend-item' + (s.row.href ? ' has-link' : '');
      if (s.row.href) item.setAttribute('href', s.row.href);
      var shown = s.row.display !== undefined ? s.row.display : fv(s.row.value) + unit;
      item.innerHTML = '<i class="dot" style="background:' + s.color + '"></i>'
        + '<span class="pie-legend-name">' + esc(s.row.label) + '</span>'
        + '<span class="pie-legend-val">' + esc(shown) + '</span>'
        + '<span class="pie-legend-pct">' + pct(s.row.value, total) + '</span>';
      if (!s.row.href) item.title = 'Gabungan beberapa brand — rincian per brand ada di tabel di bawah.';
      lg.appendChild(item);
    });
    host.appendChild(lg);
  };
})();
