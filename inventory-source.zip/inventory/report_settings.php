<?php
require_once __DIR__ . '/includes/init.php';

if (!is_admin()) {
    flash('Hanya Admin yang boleh mengatur laporan email.', 'error');
    redirect('index.php');
}

$days = [1 => 'Senin', 2 => 'Selasa', 3 => 'Rabu', 4 => 'Kamis', 5 => 'Jumat', 6 => 'Sabtu', 7 => 'Minggu'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $op = (string)post('op');

    if ($op === 'save') {
        $sender = trim((string)post('report_sender_email'));
        if ($sender !== '' && !filter_var($sender, FILTER_VALIDATE_EMAIL)) {
            flash('Email pengirim formatnya salah. Contoh yang benar: <code>nama@email.com</code>', 'error');
            redirect('report_settings.php');
        }
        setting_save('report_sender_email', $sender);
        setting_save('report_sender_name', trim((string)post('report_sender_name')));
        setting_save('report_brevo_key', trim((string)post('report_brevo_key')));
        setting_save('report_recipients', trim((string)post('report_recipients')));
        setting_save('report_top_n', (string)max(1, min(50, (int)post('report_top_n', 10))));
        setting_save('report_low_stock_n', (string)max(1, min(100, (int)post('report_low_stock_n', 15))));

        foreach (['daily', 'weekly', 'monthly'] as $t) {
            setting_save('report_' . $t . '_on', post('report_' . $t . '_on') === '1' ? '1' : '0');
            $time = (string)post('report_' . $t . '_time', '21:00');
            setting_save('report_' . $t . '_time', preg_match('/^\d{2}:\d{2}$/', $time) ? $time : '21:00');
        }
        setting_save('report_weekly_day', (string)max(1, min(7, (int)post('report_weekly_day', 6))));
        setting_save('report_monthly_day', (string)max(1, min(28, (int)post('report_monthly_day', 1))));
        setting_save('report_daily_period', post('report_daily_period') === 'last7' ? 'last7' : 'today');
        setting_save('report_weekly_period', post('report_weekly_period') === 'last7' ? 'last7' : 'week');
        setting_save('report_monthly_period', post('report_monthly_period') === 'current' ? 'current' : 'last');

        log_activity('settings', 'Menyimpan pengaturan laporan email', 'report', '');
        flash('Pengaturan laporan disimpan.');
        redirect('report_settings.php');
    }

    if ($op === 'token') {
        report_cron_token(true);
        flash('Token cron baru dibuat. Perbarui tautan di layanan cron Anda.');
        redirect('report_settings.php');
    }

    if ($op === 'test') {
        $res = report_send('daily', true);
        flash($res['ok'] ? ('Berhasil: ' . e($res['message']) . ' Periode: ' . e($res['period']) . '.') : ('Gagal: ' . e($res['message'])), $res['ok'] ? 'success' : 'error');
        redirect('report_settings.php');
    }

    if ($op === 'send_now') {
        $type = (string)post('type');
        $res = report_send(in_array($type, ['daily', 'weekly', 'monthly'], true) ? $type : 'daily');
        flash(($res['ok'] ? 'Berhasil: ' : 'Tidak dikirim: ') . e($res['message']), $res['ok'] ? 'success' : 'warn');
        redirect('report_settings.php');
    }

    if ($op === 'clear_log') {
        db_run('DELETE FROM report_log');
        flash('Riwayat pengiriman dikosongkan.');
        redirect('report_settings.php');
    }
}

$token = report_cron_token();
$cronUrl = app_base_url() . '/cron_report.php?token=' . $token;
$problems = report_readiness_problems();
$due = report_due_types();
$history = report_history(12);

[$from, $to, $label] = report_period('daily');
$preview = report_data($from, $to);

page_start('Laporan Email', 'report_settings');
?>
<?php $warnings = report_warnings(); ?>
<?php if ($warnings): ?>
<div class="alert alert-warn">
  <ul style="margin:0;padding-left:18px">
    <?php foreach ($warnings as $w): ?><li><?= e($w) ?></li><?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<?php if ($problems): ?>
<div class="alert alert-error">
  <strong>Laporan belum bisa dikirim.</strong>
  <ul style="margin:8px 0 0;padding-left:18px">
    <?php foreach ($problems as $p): ?><li><?= e($p) ?></li><?php endforeach; ?>
  </ul>
</div>
<?php else: ?>
<div class="alert alert-success">
  Laporan siap dikirim. Laporan akan terkirim otomatis sesuai jadwal di bawah — saat aplikasi dibuka, dan/atau
  tepat waktu bila tautan cron dipasang.
</div>
<?php endif; ?>

<?php if ((string)setting('report_last_error') !== ''): ?>
<div class="alert alert-error">
  <strong>Kegagalan terakhir:</strong> <?= e((string)setting('report_last_error')) ?>
</div>
<?php endif; ?>

<section class="card">
  <?php card_start('Cara Mendapatkan Kunci API Brevo (gratis)',
      'Ikuti langkah ini sekali saja. Kunci API hanya disimpan di dalam aplikasi dan tidak pernah ditampilkan kembali.'); ?>
    <ol class="small" style="margin:0;padding-left:20px;line-height:2">
      <li>Buka <a href="https://www.brevo.com" target="_blank" rel="noopener">brevo.com</a> &rarr; daftar gratis dengan email Anda.</li>
      <li>Verifikasi email pendaftaran (cek kotak masuk, termasuk folder spam).</li>
      <li>Masuk ke Brevo &rarr; menu kanan atas <strong>profil</strong> &rarr; <strong>SMTP &amp; API</strong> &rarr; tab <strong>API Keys</strong>.</li>
      <li>Klik <strong>Generate a new API key</strong>, beri nama mis. <em>Inventori</em>, lalu salin kuncinya
        (bentuknya <span class="mono">xkeysib-...</span>). Kunci hanya tampil sekali.</li>
      <li>Kembali ke halaman ini, tempel kuncinya di kolom <strong>Kunci API Brevo</strong> di bawah, lalu Simpan.</li>
      <li>Di Brevo &rarr; <strong>Senders, Domains &amp; Dedicated IPs</strong> &rarr; <strong>Senders</strong>, tambahkan email yang
        akan dipakai sebagai <strong>pengirim</strong> (biasanya email Anda sendiri), lalu klik tautan verifikasi yang dikirim Brevo.
        Isi email itu di kolom <strong>Email Pengirim</strong> di bawah.</li>
      <li>Klik tombol <strong>Kirim Laporan Uji Sekarang</strong> untuk memastikan semuanya jalan.</li>
    </ol>
    <p class="help">Penting: <strong>Email Pengirim</strong> harus sama dengan alamat yang sudah diverifikasi di Brevo, kalau tidak
      Brevo akan menolak pengirimannya. Alamat <strong>penerima</strong> boleh email apa saja (tidak perlu diverifikasi).</p>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Pengaturan Pengiriman'); ?>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="op" value="save">
      <div class="form-grid">
        <div class="field-full">
          <label>Kunci API Brevo</label>
          <input type="text" name="report_brevo_key" value="<?= e((string)setting('report_brevo_key')) ?>"
                 placeholder="xkeysib-..." autocomplete="off" spellcheck="false">
          <p class="help">Ditempel sekali di sini. Kosongkan hanya bila ingin menonaktifkan pengiriman.</p>
        </div>
        <div>
          <label>Email Pengirim</label>
          <input type="email" name="report_sender_email" value="<?= e((string)setting('report_sender_email')) ?>" placeholder="nama@email.com">
        </div>
        <div>
          <label>Nama Pengirim</label>
          <input type="text" name="report_sender_name" value="<?= e((string)setting('report_sender_name')) ?>">
        </div>
        <div class="field-full">
          <label>Alamat Penerima</label>
          <textarea name="report_recipients" rows="3" placeholder="satu alamat per baris, mis:&#10;pemilik@email.com&#10;staf@email.com"><?= e((string)setting('report_recipients')) ?></textarea>
          <p class="help">Boleh beberapa alamat sekaligus (satu per baris atau dipisah koma). Alamat yang formatnya salah otomatis diabaikan.</p>
        </div>
        <div>
          <label>Jumlah Barang Terlaris</label>
          <input type="number" name="report_top_n" min="1" max="50" value="<?= (int)setting('report_top_n', 10) ?>">
        </div>
        <div>
          <label>Jumlah Stok Menipis Ditampilkan</label>
          <input type="number" name="report_low_stock_n" min="1" max="100" value="<?= (int)setting('report_low_stock_n', 15) ?>">
        </div>
      </div>

      <div class="divider"></div>
      <h3 style="font-size:14px;margin-bottom:12px">Jadwal &amp; Isi Laporan</h3>
      <div class="table-wrap">
        <table>
          <thead><tr><th style="width:120px">Jenis</th><th>Aktif</th><th>Jadwal Kirim</th><th>Periode yang Dilaporkan</th><th>Pratinjau Periode</th></tr></thead>
          <tbody>
          <tr>
            <td><strong>Harian</strong></td>
            <td><label style="font-weight:500;display:flex;gap:8px;align-items:center">
              <input type="checkbox" name="report_daily_on" value="1" style="width:auto" <?= setting_bool('report_daily_on') ? 'checked' : '' ?>> kirim</label></td>
            <td><input type="time" name="report_daily_time" value="<?= e((string)setting('report_daily_time')) ?>" style="max-width:130px"></td>
            <td>
              <select name="report_daily_period">
                <option value="today" <?= setting('report_daily_period') === 'today' ? 'selected' : '' ?>>Hari itu saja</option>
                <option value="last7" <?= setting('report_daily_period') === 'last7' ? 'selected' : '' ?>>7 hari terakhir</option>
              </select>
            </td>
            <td class="small muted"><?php [$f, $t, $l] = report_period('daily'); echo e(fmt_date($f) . ' – ' . fmt_date($t)); ?></td>
          </tr>
          <tr>
            <td><strong>Mingguan</strong></td>
            <td><label style="font-weight:500;display:flex;gap:8px;align-items:center">
              <input type="checkbox" name="report_weekly_on" value="1" style="width:auto" <?= setting_bool('report_weekly_on') ? 'checked' : '' ?>> kirim</label></td>
            <td style="display:flex;gap:8px;align-items:center">
              <select name="report_weekly_day" style="max-width:130px">
                <?php foreach ($days as $num => $name): ?>
                  <option value="<?= $num ?>" <?= setting_int('report_weekly_day', 6) === $num ? 'selected' : '' ?>><?= e($name) ?></option>
                <?php endforeach; ?>
              </select>
              <input type="time" name="report_weekly_time" value="<?= e((string)setting('report_weekly_time')) ?>" style="max-width:130px">
            </td>
            <td>
              <select name="report_weekly_period">
                <option value="week" <?= setting('report_weekly_period') === 'week' ? 'selected' : '' ?>>Minggu berjalan (Senin–hari ini)</option>
                <option value="last7" <?= setting('report_weekly_period') === 'last7' ? 'selected' : '' ?>>7 hari terakhir</option>
              </select>
            </td>
            <td class="small muted"><?php [$f, $t, $l] = report_period('weekly'); echo e(fmt_date($f) . ' – ' . fmt_date($t)); ?></td>
          </tr>
          <tr>
            <td><strong>Bulanan</strong></td>
            <td><label style="font-weight:500;display:flex;gap:8px;align-items:center">
              <input type="checkbox" name="report_monthly_on" value="1" style="width:auto" <?= setting_bool('report_monthly_on') ? 'checked' : '' ?>> kirim</label></td>
            <td style="display:flex;gap:8px;align-items:center">
              tanggal
              <input type="number" name="report_monthly_day" min="1" max="28" value="<?= (int)setting('report_monthly_day', 1) ?>" style="max-width:80px">
              <input type="time" name="report_monthly_time" value="<?= e((string)setting('report_monthly_time')) ?>" style="max-width:130px">
            </td>
            <td>
              <select name="report_monthly_period">
                <option value="last" <?= setting('report_monthly_period') === 'last' ? 'selected' : '' ?>>Bulan lalu (bulan penuh)</option>
                <option value="current" <?= setting('report_monthly_period') === 'current' ? 'selected' : '' ?>>Bulan berjalan sampai hari ini</option>
              </select>
            </td>
            <td class="small muted"><?php [$f, $t, $l] = report_period('monthly'); echo e(fmt_date($f) . ' – ' . fmt_date($t)); ?></td>
          </tr>
          </tbody>
        </table>
      </div>

      <div class="form-actions">
        <button class="btn btn-primary" type="submit">Simpan Pengaturan</button>
        <a class="btn" href="report_preview.php?type=daily" target="_blank">Lihat Pratinjau Laporan</a>
      </div>
    </form>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Uji &amp; Kirim Manual',
      'Pratinjau lebih dulu supaya tahu isi emailnya, baru kirim.'); ?>
    <div class="btn-row">
      <form class="inline-form" method="post">
        <?= csrf_field() ?><input type="hidden" name="op" value="test">
        <button class="btn btn-primary" type="submit" data-confirm="Kirim laporan uji sekarang ke semua penerima?"><?= icon('upload') ?> Kirim Laporan Uji Sekarang</button>
      </form>
      <?php foreach (['daily' => 'Kirim laporan harian', 'weekly' => 'Kirim laporan mingguan', 'monthly' => 'Kirim laporan bulanan'] as $t => $labelBtn): ?>
        <form class="inline-form" method="post">
          <?= csrf_field() ?><input type="hidden" name="op" value="send_now"><input type="hidden" name="type" value="<?= e($t) ?>">
          <button class="btn" type="submit" data-confirm="<?= e($labelBtn) ?> sekarang?"><?= e($labelBtn) ?></button>
        </form>
      <?php endforeach; ?>
    </div>
    <?php if ($due): ?>
      <p class="help">Menunggu terkirim (sudah jatuh tempo): <strong><?= e(implode(', ', array_map('report_type_label', $due))) ?></strong>.</p>
    <?php else: ?>
      <p class="help">Tidak ada laporan yang menunggu — semuanya sudah terkirim untuk periode berjalan.</p>
    <?php endif; ?>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Kirim Tepat Waktu (opsional)',
      'Server ini tidak punya penjadwal sendiri, jadi laporan otomatis terkirim saat aplikasi dibuka. Kalau ingin jam kirimnya tepat, tempel tautan ini ke layanan cron gratis seperti cron-job.org (jadwal harian sekali sehari).'); ?>
    <label>Tautan cron rahasia</label>
    <div class="scan-row">
      <input type="text" value="<?= e($cronUrl) ?>" readonly onclick="this.select()" spellcheck="false">
      <form class="inline-form" method="post">
        <?= csrf_field() ?><input type="hidden" name="op" value="token">
        <button class="btn" type="submit" data-confirm="Buat token baru? Tautan lama langsung tidak berlaku.">Token Baru</button>
      </form>
    </div>
    <p class="help">Jangan bagikan tautan ini — siapa pun yang punya tautan bisa memicu pengiriman laporan.
      Tautan ini aman dipakai layanan luar karena hanya mengirim laporan yang sudah jatuh tempo (tidak bisa dipakai membaca data lain).</p>
    <p class="help">Tautan juga menerima <span class="mono">&amp;type=daily|weekly|monthly</span> untuk memaksa jenis tertentu,
      dan <span class="mono">&amp;force=1</span> bila ingin tetap dikirim walau periode itu sudah terkirim.</p>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Riwayat Pengiriman', '', '<form class="inline-form" method="post">' . csrf_field() . '<input type="hidden" name="op" value="clear_log"><button class="btn btn-sm" type="submit" data-confirm="Kosongkan riwayat pengiriman?">Kosongkan Riwayat</button></form>'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Waktu</th><th>Jenis</th><th>Periode</th><th class="num">Penerima</th><th>Status</th><th>Keterangan</th></tr></thead>
        <tbody>
        <?php if (!$history): ?><tr><td colspan="6"><?= empty_state('Belum ada laporan yang dikirim.') ?></td></tr><?php endif; ?>
        <?php foreach ($history as $h): ?>
          <tr>
            <td class="nowrap"><?= e(fmt_dt($h['created_at'])) ?></td>
            <td><?= e(report_type_label((string)$h['type'])) ?></td>
            <td class="small"><?= e($h['period_label'] ?: (fmt_date($h['period_from']) . ' – ' . fmt_date($h['period_to']))) ?></td>
            <td class="num"><?= fmt_num($h['recipients']) ?></td>
            <td><?= $h['status'] === 'sent' ? '<span class="badge badge-ok">Terkirim</span>' : '<span class="badge badge-danger">Gagal</span>' ?></td>
            <td class="small"><?= e($h['detail']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Contoh Isi Laporan', 'Data nyata untuk periode laporan harian — beginilah isi email yang akan diterima.'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Bagian</th><th>Isi</th></tr></thead>
        <tbody>
          <tr><td><strong>Ringkasan</strong></td><td class="small">
            <?= fmt_qty($preview['summary']['qty'] ?? 0) ?> unit terjual &middot;
            <?= fmt_money($preview['summary']['revenue'] ?? 0) ?> nilai penjualan &middot;
            HPP <?= fmt_money($preview['summary']['cogs'] ?? 0) ?> &middot;
            laba kotor <?= fmt_money((float)($preview['summary']['revenue'] ?? 0) - (float)($preview['summary']['cogs'] ?? 0)) ?>
          </td></tr>
          <tr><td><strong>Barang terlaris</strong></td><td class="small">
            <?= $preview['top'] ? e(implode(', ', array_map(static fn($t) => $t['sku'] . ' (' . fmt_qty($t['qty']) . ')', array_slice($preview['top'], 0, 5)))) : 'belum ada penjualan' ?>
          </td></tr>
          <tr><td><strong>Stok menipis</strong></td><td class="small">
            <?= fmt_num($preview['low_count']) ?> SKU (habis: <?= fmt_num($preview['out_of_stock']) ?>)
          </td></tr>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>
<?php page_end(); ?>
