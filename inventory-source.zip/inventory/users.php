<?php
require_once __DIR__ . '/includes/init.php';
require_perm('master.view');

$id = (int)get('id');
$edit = null;
$me = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (!is_admin()) {
        flash('Hanya Admin yang bisa mengelola pengguna.', 'error');
        redirect('users.php');
    }
    $op = (string)post('op');
    $uid = (int)post('id');

    if ($op === 'save') {
        $username = strtolower(trim((string)post('username')));
        $name = (string)post('name');
        $role = (string)post('role');
        $active = (int)post('active') === 1 ? 1 : 0;
        $pass = (string)post('password');
        if (!isset(ROLES[$role])) $role = 'viewer';
        if ($username === '' || $name === '' || !preg_match('/^[a-z0-9._-]{3,}$/', $username)) {
            flash('Username minimal 3 karakter (huruf kecil/angka/._-) dan nama wajib diisi.', 'error');
            redirect('users.php?id=' . $uid);
        }
        $dupe = db_one('SELECT id FROM users WHERE username = ? AND id <> ?', [$username, $uid]);
        if ($dupe) {
            flash('Username sudah dipakai.', 'error');
            redirect('users.php?id=' . $uid);
        }
        if ($uid > 0) {
            if ($uid === (int)$me['id'] && $active === 0) {
                flash('Anda tidak bisa menonaktifkan akun sendiri.', 'error');
                redirect('users.php?id=' . $uid);
            }
            db_run('UPDATE users SET username=?, name=?, role=?, active=? WHERE id=?', [$username, $name, $role, $active, $uid]);
            if ($pass !== '') {
                db_run('UPDATE users SET password_hash=? WHERE id=?', [password_hash($pass, PASSWORD_DEFAULT), $uid]);
            }
            log_activity('update', 'Ubah pengguna ' . $username . ' (role ' . $role . ')', 'user', $username);
            flash('Pengguna <strong>' . e($name) . '</strong> berhasil diperbarui' . ($pass !== '' ? ' beserta password barunya.' : '.'));
        } else {
            if (strlen($pass) < 5) {
                flash('Password minimal 5 karakter.', 'error');
                redirect('users.php');
            }
            db_run('INSERT INTO users (username, name, password_hash, role, active, created_at) VALUES (?,?,?,?,?,?)',
                [$username, $name, password_hash($pass, PASSWORD_DEFAULT), $role, $active, now()]);
            log_activity('create', 'Tambah pengguna ' . $username . ' (role ' . $role . ')', 'user', $username);
            flash('Pengguna <strong>' . e($name) . '</strong> berhasil ditambahkan.');
        }
        redirect('users.php');
    }

    if ($op === 'toggle') {
        if ($uid === (int)$me['id']) {
            flash('Anda tidak bisa menonaktifkan akun sendiri.', 'error');
            redirect('users.php');
        }
        db_run('UPDATE users SET active = CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id = ?', [$uid]);
        log_activity('toggle', 'Ubah status aktif pengguna #' . $uid, 'user', (string)$uid);
        flash('Status pengguna berhasil diubah.');
        redirect('users.php');
    }
}

if ($id > 0) $edit = db_one('SELECT * FROM users WHERE id = ?', [$id]);

$users = db_all('SELECT * FROM users ORDER BY role, name');
$permDesc = [
    'admin' => 'Akses penuh termasuk pengguna, void dokumen, dan semua laporan.',
    'staff' => 'Input transaksi & master data, adjustment, opname, import. Tidak bisa void dokumen.',
    'viewer' => 'Hanya melihat data & export CSV. Tidak bisa mengubah apa pun.',
];

page_start('Pengguna Aplikasi', 'users');
?>
<div class="grid grid-3">
  <div class="card stat"><span class="label">Total Pengguna</span><span class="value"><?= fmt_num(count($users)) ?></span></div>
  <div class="card stat"><span class="label">Aktif</span><span class="value"><?= fmt_num((int)db_scalar('SELECT COUNT(*) FROM users WHERE active = 1')) ?></span></div>
  <div class="card stat"><span class="label">Admin</span><span class="value"><?= fmt_num((int)db_scalar("SELECT COUNT(*) FROM users WHERE role = 'admin' AND active = 1")) ?></span></div>
</div>

<section class="card">
  <?php card_start('Hak Akses per Role', 'Setiap aksi pada aplikasi tercatat di Log Aktivitas beserta nama penggunanya.'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Role</th><th>Kewenangan</th></tr></thead>
        <tbody>
        <?php foreach (ROLES as $k => $label): ?>
          <tr><td><span class="pill"><?= e($label) ?></span></td><td><?= e($permDesc[$k] ?? '') ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Daftar Pengguna', '', '<a class="btn btn-sm" href="export.php?type=users">' . icon('export') . ' Export Excel</a>'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Username</th><th>Nama</th><th>Role</th><th>Status</th><th>Dibuat</th><?php if (is_admin()): ?><th></th><?php endif; ?></tr></thead>
        <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td class="mono"><?= e($u['username']) ?></td>
            <td><?= is_admin() ? '<a href="users.php?id=' . (int)$u['id'] . '">' . e($u['name']) . '</a>' : e($u['name']) ?></td>
            <td><span class="pill"><?= e(ROLES[$u['role']] ?? $u['role']) ?></span></td>
            <td><?= (int)$u['active'] === 1 ? '<span class="badge badge-ok">Aktif</span>' : '<span class="badge badge-muted">Nonaktif</span>' ?></td>
            <td><?= e(fmt_dt($u['created_at'])) ?></td>
            <?php if (is_admin()): ?>
            <td><form class="inline-form" method="post" data-confirm="Ubah status aktif pengguna ini?">
              <?= csrf_field() ?><input type="hidden" name="op" value="toggle"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
              <button class="btn btn-sm" type="submit"><?= (int)$u['active'] === 1 ? 'Nonaktifkan' : 'Aktifkan' ?></button>
            </form></td>
            <?php endif; ?>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<?php if (is_admin()): ?>
<section class="card">
  <?php card_start($edit ? ('Ubah Pengguna: ' . $edit['name']) : 'Tambah Pengguna'); ?>
    <form method="post" autocomplete="off">
      <?= csrf_field() ?>
      <input type="hidden" name="op" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
      <div class="form-grid">
        <div><label>Username *</label><input type="text" name="username" value="<?= e($edit['username'] ?? '') ?>" required></div>
        <div><label>Nama Lengkap *</label><input type="text" name="name" value="<?= e($edit['name'] ?? '') ?>" required></div>
        <div><label>Role *</label>
          <select name="role">
            <?php foreach (ROLES as $k => $label): ?>
              <option value="<?= e($k) ?>" <?= ($edit['role'] ?? 'staff') === $k ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div><label>Status</label>
          <select name="active">
            <option value="1" <?= (int)($edit['active'] ?? 1) === 1 ? 'selected' : '' ?>>Aktif</option>
            <option value="0" <?= isset($edit['active']) && (int)$edit['active'] === 0 ? 'selected' : '' ?>>Nonaktif</option>
          </select>
        </div>
        <div><label><?= $edit ? 'Password Baru (opsional)' : 'Password *' ?></label><input type="password" name="password" <?= $edit ? '' : 'required' ?>></div>
      </div>
      <div class="form-actions">
        <button class="btn btn-primary" type="submit"><?= $edit ? 'Simpan Perubahan' : 'Simpan Pengguna' ?></button>
        <?php if ($edit): ?><a class="btn" href="users.php">Batal</a><?php endif; ?>
      </div>
    </form>
  <?php card_end(); ?>
</section>
<?php endif; ?>
<?php page_end(); ?>
