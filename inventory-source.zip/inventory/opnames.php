<?php
require_once __DIR__ . '/includes/init.php';
require_perm('inv.view');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $op = (string)post('op');
    $did = (int)post('id');
    if ($op === 'void') {
        if (!is_admin()) {
            flash('Hanya Admin yang boleh melakukan void dokumen.', 'error');
        } else {
            $reason = (string)post('void_reason');
            $res = void_document('opname', $did, $reason !== '' ? $reason : 'tanpa alasan');
            if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil di-void dan stok dikembalikan.');
            if (!empty($res['warning'])) flash($res['warning'], 'warn');
            else flash('Gagal void: ' . e(implode(' ', $res['errors'])), 'error');
        }
    }
    if ($op === 'post_id') {
        if (!can('inv.opname')) {
            flash('Role Anda tidak boleh memposting stok opname.', 'error');
        } else {
            $res = post_document('opname', $did);
            if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil diposting; stok disesuaikan dengan hasil hitung fisik.');
            else flash('Gagal posting: ' . e(implode(' ', $res['errors'])), 'error');
        }
    }
    redirect('opnames.php');
}

$from = input_date('from', date('Y-m-d', strtotime('-90 days')));
$to = input_date('to', today());
$statusF = (string)get('status');
$q = (string)get('q');

$where = ['date(o.doc_date) BETWEEN ? AND ?'];
$params = [$from, $to];
if ($statusF !== '') { $where[] = 'o.status = ?'; $params[] = $statusF; }
if ($q !== '') { $where[] = '(o.doc_no LIKE ? OR o.note LIKE ?)'; $params[] = "%$q%"; $params[] = "%$q%"; }
$wsql = 'WHERE ' . implode(' AND ', $where);

$total = (int)db_scalar("SELECT COUNT(*) FROM opnames o $wsql", $params);
$pg = pager($total, 25);
$rows = db_all(
    "SELECT o.*, u.name AS created_name FROM opnames o LEFT JOIN users u ON u.id = o.created_by
     $wsql ORDER BY o.doc_date DESC, o.id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}",
    $params
);

/* Dampak void dihitung sekaligus (satu query per jenis dokumen) supaya tombol Void
   bisa memperingatkan lebih dulu bila stok akan menjadi minus. */
$voidRefs = [];
foreach ($rows as $r) {
    if ((string)$r['status'] === 'posted') $voidRefs[] = ['opname', (int)$r['id']];
}
$voidImpact = void_impacts($voidRefs);
$voidConfirm = [];
foreach ($rows as $r) {
    $key = 'opname:' . (int)$r['id'];
    $voidConfirm[(int)$r['id']] = void_confirm_text('opname', (int)$r['id'], (string)$r['doc_no'], $voidImpact[$key] ?? []);
}

page_start('Stok Opname', 'opnames');
?>
<div class="grid grid-4">
  <div class="card stat"><span class="label">Dokumen Periode Ini</span><span class="value"><?= fmt_num($total) ?></span></div>
  <div class="card stat"><span class="label">Draft</span><span class="value"><?= fmt_num((int)db_scalar("SELECT COUNT(*) FROM opnames WHERE status='draft'")) ?></span><span class="hint">hasil hitung belum diterapkan</span></div>
  <div class="card stat"><span class="label">Posted</span><span class="value"><?= fmt_num((int)db_scalar("SELECT COUNT(*) FROM opnames WHERE status='posted'")) ?></span></div>
  <div class="card stat"><span class="label">Akurasi Stok Terakhir</span>
    <?php
      $lastPosted = db_one("SELECT * FROM opnames WHERE status='posted' ORDER BY id DESC LIMIT 1");
      $acc = null;
      if ($lastPosted && (int)$lastPosted['total_items'] > 0) {
          $match = (int)db_scalar('SELECT COUNT(*) FROM opname_items WHERE opname_id = ? AND diff = 0', [(int)$lastPosted['id']]);
          $acc = $match / (int)$lastPosted['total_items'] * 100;
      }
    ?>
    <span class="value"><?= $acc === null ? '-' : fmt_num($acc, 1) . '%' ?></span>
    <span class="hint"><?= $lastPosted ? e($lastPosted['doc_no']) : 'belum ada opname posted' ?></span>
  </div>
</div>

<section class="card">
  <?php card_start('Daftar Stok Opname', 'Hitung fisik barang di gudang, bandingkan dengan catatan sistem, lalu posting selisihnya.',
      '<a class="btn btn-sm" href="export.php?type=opnames&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Export Excel</a>'
      . '<a class="btn btn-sm" href="export.php?type=opname_items&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Detail Item</a>'
      . (can('inv.opname') ? '<a class="btn btn-sm btn-primary" href="opname_form.php">' . icon('plus') . ' Opname Baru</a>' : '')); ?>
    <form class="filters" method="get" style="margin-bottom:18px">
      <div class="f-item"><label>Dari</label><input type="date" name="from" value="<?= e($from) ?>"></div>
      <div class="f-item"><label>Sampai</label><input type="date" name="to" value="<?= e($to) ?>"></div>
      <div class="f-item"><label>Status</label>
        <select name="status">
          <?php foreach (['' => 'Semua status', 'draft' => 'Draft', 'posted' => 'Posted', 'void' => 'Void'] as $k => $v): ?>
            <option value="<?= e($k) ?>" <?= $statusF === $k ? 'selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="f-item"><label>Cari</label><input type="text" name="q" value="<?= e($q) ?>" placeholder="no dokumen / catatan"></div>
      <button class="btn btn-primary" type="submit">Terapkan</button>
      <a class="btn" href="opnames.php">Reset</a>
    </form>
    <div class="table-wrap">
      <table>
        <thead><tr><th>No. Dokumen</th><th>Tanggal</th><th class="num">Item Dihitung</th><th class="num">Total Selisih</th><th>Status</th><th>Petugas &amp; Waktu</th><th>Catatan</th><th></th></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="8"><?= empty_state('Belum ada dokumen stok opname.') ?></td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td class="mono"><a href="opname_form.php?id=<?= (int)$r['id'] ?>"><?= e($r['doc_no']) ?></a></td>
            <td class="nowrap"><?= e(fmt_date($r['doc_date'])) ?></td>
            <td class="num"><?= fmt_num($r['total_items']) ?></td>
            <td class="num" style="color:<?= (float)$r['total_diff'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ((float)$r['total_diff'] >= 0 ? '+' : '') . fmt_qty($r['total_diff']) ?></td>
            <td><?= status_badge((string)$r['status']) ?></td>
            <td class="nowrap"><?= e($r['created_name'] ?? '-') ?><div class="muted small"><?= e(fmt_dt($r['created_at'])) ?></div></td>
            <td class="small"><?= e($r['note'] ?: ($r['status'] === 'void' ? ('Void: ' . $r['void_reason']) : '-')) ?></td>
            <td class="nowrap">
              <div class="row-actions">
                <a class="btn btn-sm" href="opname_form.php?id=<?= (int)$r['id'] ?>"><?= $r['status'] === 'draft' ? 'Lanjutkan' : 'Lihat' ?></a>
                <?php if ($r['status'] === 'draft' && can('inv.opname')): ?>
                  <form class="inline-form" method="post" data-confirm="Posting hasil opname ini? Stok sistem akan disesuaikan dengan hasil hitung fisik.">
                    <?= csrf_field() ?><input type="hidden" name="op" value="post_id"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-sm btn-primary" type="submit">Posting</button>
                  </form>
                <?php endif; ?>
                <?php if ($r['status'] === 'posted' && is_admin()): ?>
                  <form class="inline-form" method="post" data-need-reason data-confirm="<?= e($voidConfirm[(int)$r['id']] ?? void_confirm_text('opname', (int)$r['id'], (string)$r['doc_no'])) ?>">
                    <?= csrf_field() ?><input type="hidden" name="op" value="void"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <input type="hidden" name="void_reason" value="">
                    <button class="btn btn-sm btn-danger" type="submit">Void</button>
                  </form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?= render_pager($pg) ?>
  <?php card_end(); ?>
</section>
<?php page_end(); ?>
