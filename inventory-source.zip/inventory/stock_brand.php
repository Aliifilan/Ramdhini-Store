<?php
require_once __DIR__ . '/includes/init.php';
require_perm('inv.view');

$rows = db_all(
    "SELECT b.id, b.code, b.name, b.active,
            COUNT(p.id) AS sku_count,
            COALESCE(SUM(p.stock_qty),0) AS stock_qty,
            COALESCE(SUM(p.stock_qty * p.cost_price),0) AS stock_value,
            COALESCE(SUM(p.stock_qty * p.sell_price),0) AS sell_value,
            COALESCE(SUM(CASE WHEN p.stock_qty <= p.min_stock THEN 1 ELSE 0 END),0) AS low_count
       FROM brands b LEFT JOIN products p ON p.brand_id = b.id AND p.active = 1
      GROUP BY b.id ORDER BY b.name"
);
$noBrand = db_one(
    "SELECT COUNT(*) c, COALESCE(SUM(stock_qty),0) q, COALESCE(SUM(stock_qty*cost_price),0) v
       FROM products WHERE brand_id IS NULL AND active = 1"
);
$grandQty = 0.0;
$grandVal = 0.0;
$grandSku = 0;
foreach ($rows as $r) { $grandQty += (float)$r['stock_qty']; $grandVal += (float)$r['stock_value']; $grandSku += (int)$r['sku_count']; }

$pieUnit = brand_pie_rows($rows, $noBrand, 'stock_qty', static fn(float $v): string => fmt_qty($v) . ' unit');
$pieValue = brand_pie_rows($rows, $noBrand, 'stock_value', static fn(float $v): string => fmt_money($v), 6);

page_start('Stok per Brand', 'stock_brand');
?>
<div class="grid grid-3">
  <div class="card stat"><span class="label">Total Brand</span><span class="value"><?= fmt_num(count($rows)) ?></span></div>
  <div class="card stat"><span class="label">Total Stok Semua Brand</span><span class="value"><?= fmt_qty($grandQty) ?></span><span class="hint"><?= fmt_num($grandSku) ?> SKU aktif</span></div>
  <div class="card stat"><span class="label">Nilai Stok (HPP)</span><span class="value" style="font-size:20px"><?= fmt_money($grandVal) ?></span></div>
</div>

<div class="grid grid-2">
  <section class="card">
    <?php card_start('Komposisi Stok per Brand', 'Porsi jumlah unit stok tiap brand. Arahkan kursor ke potongan untuk melihat angkanya, klik untuk membuka produk brand tersebut.'); ?>
      <div id="chart-brand"></div>
    <?php card_end(); ?>
  </section>
  <section class="card">
    <?php card_start('Nilai Stok per Brand (HPP)', 'Porsi nilai modal yang tersimpan pada stok tiap brand. Klik potongan atau legenda untuk membuka produknya.'); ?>
      <div id="chart-brand-value"></div>
    <?php card_end(); ?>
  </section>
</div>

<section class="card">
  <?php card_start('Rekap Stok per Brand',
      'Klik nama brand untuk melihat daftar produknya di menu Produk Master.',
      '<a class="btn btn-sm" href="export.php?type=stock_brand">' . icon('export') . ' Export Excel</a>'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Kode</th><th>Brand</th><th class="num">SKU Aktif</th><th class="num">Total Stok</th><th class="num">Nilai Stok (HPP)</th><th class="num">Potensi Jual</th><th class="num">SKU Menipis</th><th>Kontribusi</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r): $pct = $grandQty > 0 ? ((float)$r['stock_qty'] / $grandQty) * 100 : 0; ?>
          <tr>
            <td class="mono"><?= e($r['code']) ?></td>
            <td>
              <a href="products.php?brand_id=<?= (int)$r['id'] ?>"><?= e($r['name']) ?></a>
              <?= (int)$r['active'] === 0 ? ' <span class="badge badge-muted">nonaktif</span>' : '' ?>
            </td>
            <td class="num"><?= fmt_num($r['sku_count']) ?></td>
            <td class="num"><strong><?= fmt_qty($r['stock_qty']) ?></strong></td>
            <td class="num"><?= fmt_money($r['stock_value']) ?></td>
            <td class="num"><?= fmt_money($r['sell_value']) ?></td>
            <td class="num"><?= (int)$r['low_count'] > 0 ? '<span class="badge badge-warn">' . fmt_num($r['low_count']) . ' SKU</span>' : '0' ?></td>
            <td class="nowrap"><?= fmt_num($pct, 1) ?>%</td>
            <td class="nowrap"><a class="btn btn-sm" href="products.php?brand_id=<?= (int)$r['id'] ?>">Lihat produk</a></td>
          </tr>
        <?php endforeach; ?>
        <?php if ($noBrand && (int)$noBrand['c'] > 0): ?>
          <tr>
            <td class="mono">-</td>
            <td><a href="products.php?brand_id=0&status=aktif"><em>Tanpa brand</em></a></td>
            <td class="num"><?= fmt_num($noBrand['c']) ?></td>
            <td class="num"><strong><?= fmt_qty($noBrand['q']) ?></strong></td>
            <td class="num"><?= fmt_money($noBrand['v']) ?></td>
            <td class="num">-</td>
            <td class="num">-</td>
            <td class="nowrap"><?= $grandQty > 0 ? fmt_num(((float)$noBrand['q'] / $grandQty) * 100, 1) : '0' ?>%</td>
            <td class="nowrap"><a class="btn btn-sm" href="products.php?brand_id=0&status=aktif">Lihat produk</a></td>
          </tr>
        <?php endif; ?>
        <tr class="totals-row">
          <td colspan="2">TOTAL</td>
          <td class="num"><?= fmt_num($grandSku) ?></td>
          <td class="num"><?= fmt_qty($grandQty) ?></td>
          <td class="num"><?= fmt_money($grandVal) ?></td>
          <td class="num"><?= fmt_money((float)(db_scalar('SELECT COALESCE(SUM(stock_qty*sell_price),0) FROM products WHERE active=1') ?? 0)) ?></td>
          <td class="num"><?= fmt_num((int)db_scalar('SELECT COUNT(*) FROM products WHERE active=1 AND stock_qty <= min_stock')) ?></td>
          <td colspan="2"></td>
        </tr>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<script src="<?= e(asset_url('assets/charts.js')) ?>"></script>
<script>
renderPieChart('chart-brand', {
  rows: <?= json_encode($pieUnit, JSON_UNESCAPED_UNICODE) ?>,
  centerLabel: 'Total stok',
  centerValue: <?= json_encode(fmt_qty($grandQty) . ' unit') ?>,
  title: 'Komposisi stok per brand'
});
renderPieChart('chart-brand-value', {
  rows: <?= json_encode($pieValue, JSON_UNESCAPED_UNICODE) ?>,
  format: 'money',
  centerLabel: 'Nilai stok (HPP)',
  centerValue: <?= json_encode(fmt_money($grandVal)) ?>,
  title: 'Nilai stok per brand'
});
</script>
<?php page_end(); ?>
