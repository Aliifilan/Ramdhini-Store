<?php
require_once __DIR__ . '/includes/init.php';
require_perm('tx.view');

$id = (int)get('id');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $op = (string)post('op');
    $did = (int)post('id');

    if ($op === 'void') {
        if (!is_admin()) {
            flash('Hanya Admin yang boleh melakukan void dokumen.', 'error');
        } else {
            $reason = (string)post('void_reason');
            $res = void_document('return', $did, $reason !== '' ? $reason : 'tanpa alasan');
            if ($res['ok']) flash('Dokumen retur <strong>' . e($res['doc_no']) . '</strong> berhasil di-void.');
            if (!empty($res['warning'])) flash($res['warning'], 'warn');
            if (!empty($res['warning'])) flash($res['warning'], 'warn');
            else flash('Gagal void: ' . e(implode(' ', $res['errors'])), 'error');
        }
        redirect('return_form.php?id=' . $did);
    }

    if ($op === 'post_id') {
        $res = post_document('return', $did);
        if ($res['ok']) flash('Dokumen retur <strong>' . e($res['doc_no']) . '</strong> berhasil diposting.');
        else flash('Gagal posting: ' . e(implode(' ', $res['errors'])), 'error');
        redirect('return_form.php?id=' . $did);
    }

    if ($op === 'save' || $op === 'save_post') {
        if (!can('tx.create')) {
            flash('Role Anda tidak boleh membuat transaksi.', 'error');
            redirect('returns.php');
        }
        $docDate = (string)post('doc_date');
        $type = (string)post('type') === 'customer' ? 'customer' : 'supplier';
        $party = (string)post('party');
        $refNo = (string)post('ref_doc_no');
        $note = (string)post('note');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $docDate)) $docDate = today();

        $skus = (array)post('item_sku', []);
        $qtys = (array)post('item_qty', []);
        $prices = (array)post('item_price', []);
        $resolved = resolve_skus($skus);
        $pids = $resolved['ids'];
        $rowsOk = 0;
        foreach ($skus as $i => $sku) {
            if (!empty($pids[$i]) && parse_qty($qtys[$i] ?? 0) > 0) $rowsOk++;
        }
        if ($resolved['unknown']) {
            flash(unknown_sku_message($resolved['unknown']), 'warn');
        }
        if ($rowsOk === 0) {
            flash('Scan atau ketik minimal satu SKU yang terdaftar dengan jumlah lebih dari 0.', 'error');
            redirect('return_form.php' . ($did ? '?id=' . $did : ''));
        }

        $me = current_user();
        try {
            $did = db_tx(function () use ($did, $docDate, $type, $party, $refNo, $note, $pids, $qtys, $prices, $me) {
                if ($did > 0) {
                    $doc = db_one('SELECT * FROM returns WHERE id = ?', [$did]);
                    if (!$doc) throw new RuntimeException('Dokumen tidak ditemukan.');
                    if ($doc['status'] !== 'draft') throw new RuntimeException('Dokumen yang sudah diposting/void tidak bisa diubah.');
                    db_run('UPDATE returns SET doc_date=?, type=?, party=?, ref_doc_no=?, note=? WHERE id=?', [$docDate, $type, $party, $refNo, $note, $did]);
                } else {
                    $docNo = next_doc_no('return', 'RTB', $docDate);
                    db_run('INSERT INTO returns (doc_no, doc_date, type, party, ref_doc_no, note, status, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
                        [$docNo, $docDate, $type, $party, $refNo, $note, 'draft', (int)$me['id'], now()]);
                    $did = (int)db()->lastInsertId();
                }
                save_return_items($did, $pids, $qtys, $prices);
                recalc_doc_totals('return', $did);
                return $did;
            });
        } catch (Throwable $ex) {
            flash('Gagal menyimpan: ' . e($ex->getMessage()), 'error');
            redirect('return_form.php' . ($did ? '?id=' . $did : ''));
        }

        $docNo = (string)db_scalar('SELECT doc_no FROM returns WHERE id = ?', [$did]);
        log_activity('save', 'Simpan retur ' . $docNo . ' (' . $type . ')', 'return', $docNo);
        if ($op === 'save_post') {
            $res = post_document('return', $did);
            if ($res['ok']) {
                flash('Retur <strong>' . e($docNo) . '</strong> berhasil diposting.');
                redirect('return_form.php?id=' . $did);
            }
            flash('Tersimpan sebagai draft, gagal posting: ' . e(implode(' ', $res['errors'])), 'warn');
            redirect('return_form.php?id=' . $did);
        }
        flash('Retur <strong>' . e($docNo) . '</strong> disimpan sebagai draft.');
        redirect('returns.php');
    }
}

$doc = null;
$items = [];
if ($id > 0) {
    $doc = db_one('SELECT r.*, u.name AS created_name FROM returns r LEFT JOIN users u ON u.id = r.created_by WHERE r.id = ?', [$id]);
    if (!$doc) {
        flash('Dokumen tidak ditemukan.', 'error');
        redirect('returns.php');
    }
    $items = doc_items('return', $id);
}
$canEdit = can('tx.create') && (!$doc || $doc['status'] === 'draft');
$products = db_all("SELECT p.id, p.sku, p.unit, p.stock_qty, p.cost_price, p.sell_price FROM products p WHERE p.active = 1 ORDER BY p.sku");
$brands = db_all('SELECT id, name FROM brands WHERE active = 1 ORDER BY name');
$backUrl = $doc ? ('returns.php?q=' . urlencode((string)$doc['doc_no'])) : 'returns.php';

page_start($doc ? ('Retur ' . $doc['doc_no']) : 'Retur Baru', 'returns');
?>
<div class="grid" style="gap:16px">
  <div class="stepline">
    <a class="btn btn-sm" href="<?= e($backUrl) ?>"><?= icon('arrow-left') ?> Kembali ke daftar</a>
    <?php if ($doc): ?>
      <?= status_badge((string)$doc['status']) ?>
      <span class="muted">Dibuat oleh <?= e($doc['created_name'] ?? '-') ?> &middot; <?= e(fmt_dt($doc['created_at'])) ?></span>
      <?php if (!empty($doc['posted_at'])): ?>
        <span class="badge badge-info">Diposting <?= e(fmt_dt($doc['posted_at'])) ?></span>
      <?php endif; ?>
      <?php if (!empty($doc['voided_at'])): ?>
        <span class="badge badge-danger">Di-void <?= e(fmt_dt($doc['voided_at'])) ?></span>
      <?php endif; ?>
      <?php if ($doc['status'] === 'void'): ?><span class="badge badge-danger">Void: <?= e($doc['void_reason']) ?></span><?php endif; ?>
      <button class="btn btn-sm no-print" data-print><?= icon('print') ?> Cetak</button>
    <?php endif; ?>
  </div>
</div>

<section class="card">
  <?php card_start($doc ? ('Dokumen ' . $doc['doc_no']) : 'Input Retur',
      'Retur ke supplier = barang dikirim balik (stok berkurang). Retur dari customer = barang masuk kembali (stok bertambah).'); ?>
  <form method="post" id="docForm">
    <?= csrf_field() ?>
    <input type="hidden" name="op" value="save"><input type="hidden" name="id" value="<?= (int)($doc['id'] ?? 0) ?>">
    <div class="form-grid">
      <div><label>No. Dokumen</label><input type="text" value="<?= e($doc['doc_no'] ?? 'otomatis saat disimpan') ?>" readonly></div>
      <div><label>Tanggal Retur</label><input type="date" name="doc_date" value="<?= e($doc['doc_date'] ?? today()) ?>" <?= $canEdit ? '' : 'readonly' ?>></div>
      <div><label>Jenis Retur</label>
        <select name="type" <?= $canEdit ? '' : 'disabled' ?> onchange="returTypeHint()">
          <option value="supplier" <?= ($doc['type'] ?? 'supplier') === 'supplier' ? 'selected' : '' ?>>Ke Supplier (stok keluar)</option>
          <option value="customer" <?= ($doc['type'] ?? '') === 'customer' ? 'selected' : '' ?>>Dari Customer (stok masuk)</option>
        </select>
      </div>
      <div><label>Nama Supplier / Customer</label><input type="text" name="party" value="<?= e($doc['party'] ?? '') ?>" <?= $canEdit ? '' : 'readonly' ?> placeholder="nama pihak yang meretur"></div>
      <div><label>Referensi Dokumen</label><input type="text" name="ref_doc_no" value="<?= e($doc['ref_doc_no'] ?? '') ?>" <?= $canEdit ? '' : 'readonly' ?> placeholder="no. IN-/OUT- terkait (opsional)"></div>
      <div><label>Catatan</label><input type="text" name="note" value="<?= e($doc['note'] ?? '') ?>" <?= $canEdit ? '' : 'readonly' ?> placeholder="alasan retur"></div>
    </div>
    <p class="help" id="returHint"></p>

    <div class="divider"></div>

    <?php if ($canEdit) sku_scan_tools([
        'mode' => 'items',
        'canCreate' => can('master.edit'),
        'brands' => $brands,
        'priceKey' => 'cost_price',
        'priceLabel' => 'Harga',
        'csrf' => csrf_token(),
        'hint' => 'Scan barcode/QR atau ketik SKU lalu Enter. Harga otomatis mengikuti HPP (retur ke supplier) atau harga jual (retur dari customer).',
    ]); ?>

    <div class="table-wrap">
      <table id="itemTable" data-items data-money="1" data-total-qty="totQty" data-total-amount="totAmount">
        <thead><tr><th style="min-width:200px">SKU</th><th class="num qty-col">Qty</th><th class="num" style="width:150px">Harga</th><th class="num" style="width:140px">Subtotal</th><?php if ($canEdit): ?><th style="width:80px"></th><?php endif; ?></tr></thead>
        <tbody id="itemBody">
        <?php foreach ($items as $it): ?>
          <tr data-sku="<?= e($it['sku']) ?>">
            <td>
              <input class="sku-input" type="text" data-sku-input name="item_sku[]" value="<?= e($it['sku']) ?>" placeholder="scan / ketik SKU" autocomplete="off" spellcheck="false" autocapitalize="characters" <?= $canEdit ? '' : 'readonly' ?>>
              <div class="sku-hint small muted"></div>
            </td>
            <td class="qty-cell"><?= $canEdit ? qty_stepper($it['qty'], true) : qty_stepper($it['qty'], false) ?></td>
            <td><input class="qty-input" style="max-width:140px" type="text" name="item_price[]" value="<?= e((float)$it['unit_price'] > 0 ? fmt_num($it['unit_price']) : '') ?>" placeholder="isi harga" <?= $canEdit ? '' : 'readonly' ?>></td>
            <td class="num row-subtotal"><?= fmt_money($it['subtotal']) ?></td>
            <?php if ($canEdit): ?><td><button class="btn btn-sm" type="button" onclick="this.closest('tr').remove();rowRecalc()">Hapus</button></td><?php endif; ?>
          </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr class="totals-row"><td class="right">TOTAL</td><td class="num" id="totQty">0</td><td></td><td class="num" id="totAmount">Rp 0</td><?php if ($canEdit): ?><td></td><?php endif; ?></tr>
        </tfoot>
      </table>
    </div>

    <?php if ($canEdit): ?>
    <template id="itemTpl">
      <td>
        <input class="sku-input" type="text" data-sku-input name="item_sku[]" placeholder="scan / ketik SKU" autocomplete="off" spellcheck="false" autocapitalize="characters">
        <div class="sku-hint small muted"></div>
      </td>
      <td class="qty-cell"><?= qty_stepper(1) ?></td>
      <td><input class="qty-input" style="max-width:140px" type="text" name="item_price[]" placeholder="isi harga" oninput="rowRecalc()"></td>
      <td class="num row-subtotal">Rp 0</td>
      <td><button class="btn btn-sm" type="button" onclick="this.closest('tr').remove();rowRecalc()">Hapus</button></td>
    </template>
    <?php endif; ?>

    <div class="form-actions">
      <?php if ($canEdit): ?>
        <button class="btn" type="button" onclick="itemRows.add({bodyId:'itemBody',tplId:'itemTpl'})"><?= icon('plus') ?> Baris kosong</button>
        <div style="flex:1"></div>
        <button class="btn" type="submit">Simpan sebagai Draft</button>
        <button class="btn btn-primary" type="button" onclick="submitPost('Posting retur ini? Stok akan disesuaikan.')">Simpan &amp; Posting</button>
      <?php elseif ($doc && $doc['status'] === 'draft' && can('tx.edit')): ?>
        <button class="btn btn-primary" type="submit" name="op" value="post_id">Posting Sekarang</button>
      <?php endif; ?>
    </div>
  </form>
  <?php card_end(); ?>
</section>

<?php if ($doc && $doc['status'] === 'posted'): ?>
<section class="card">
  <?php card_start('Pergerakan Stok dari Dokumen Ini'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal</th><th>Produk</th><th class="num">Perubahan</th><th class="num">Saldo Stok</th><th>Catatan</th></tr></thead>
        <tbody>
        <?php
          $ref = $doc['type'] === 'supplier' ? 'return_supplier' : 'return_customer';
          foreach (doc_ledger_rows($ref, (int)$doc['id']) as $l):
        ?>
          <tr>
            <td><?= e(fmt_date($l['move_date'])) ?></td>
            <td class="mono"><?= e($l['sku']) ?></td>
            <td class="num" style="color:<?= (float)$l['qty_change'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ((float)$l['qty_change'] >= 0 ? '+' : '') . fmt_qty($l['qty_change']) ?></td>
            <td class="num"><?= fmt_qty($l['qty_after']) ?></td>
            <td class="small"><?= e($l['note'] ?: doc_label((string)$l['ref_type'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<?php if ($doc && $doc['status'] === 'posted' && is_admin()): ?>
<section class="card">
  <?php card_start('Void Dokumen', 'Void membalik pergerakan stok dokumen retur ini.'); ?>
    <form method="post" data-need-reason data-confirm="<?= e(void_confirm_text('return', (int)$doc['id'], (string)$doc['doc_no'])) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="op" value="void"><input type="hidden" name="id" value="<?= (int)$doc['id'] ?>">
      <input type="text" name="void_reason" placeholder="alasan void (wajib)" required>
      <div class="form-actions"><button class="btn btn-danger" type="submit"><?= icon('ban') ?> Void Dokumen</button></div>
    </form>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<script src="<?= e(asset_url('assets/sku.js')) ?>"></script>
<script>
<?= product_js_maps($products, 'cost_price') ?>
window.PRODUCT_COST = <?= json_encode(array_column($products, 'cost_price', 'id')) ?>;
window.PRODUCT_SELL = <?= json_encode(array_column($products, 'sell_price', 'id')) ?>;
function returTypeHint() {
  var t = document.querySelector('select[name=type]').value;
  document.getElementById('returHint').textContent = t === 'supplier'
    ? 'Barang dikirim kembali ke supplier — stok akan berkurang saat diposting.'
    : 'Barang diterima kembali dari customer — stok akan bertambah saat diposting.';
  window.PRODUCT_PRICE = t === 'supplier' ? window.PRODUCT_COST : window.PRODUCT_SELL;
}
function rowRecalc() {
  itemRows.recalc({ tableId: 'itemTable', stockMap: window.PRODUCT_STOCK, totalQtyId: 'totQty', totalAmountId: 'totAmount' });
}
function submitPost(msg) {
  if (!confirm(msg)) return;
  var f = document.getElementById('docForm');
  f.querySelector('input[name=op]').value = 'save_post';
  f.submit();
}
document.addEventListener('DOMContentLoaded', function () { returTypeHint(); rowRecalc(); });
</script>
<?php page_end(); ?>
