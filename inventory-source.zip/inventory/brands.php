<?php
require_once __DIR__ . '/includes/init.php';
require_perm('master.view');

$id = (int)get('id');
$edit = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (!can('master.edit')) {
        flash('Role Anda hanya bisa melihat data master.', 'error');
        redirect('brands.php');
    }
    $op = (string)post('op');
    $bid = (int)post('id');
    if ($op === 'save') {
        $code = strtoupper((string)post('code'));
        $name = (string)post('name');
        $desc = (string)post('description');
        $active = (int)post('active') === 1 ? 1 : 0;
        if ($code === '' || $name === '') {
            flash('Kode dan Nama Brand wajib diisi.', 'error');
            redirect('brands.php?id=' . $bid);
        }
        $dupe = db_one('SELECT id FROM brands WHERE (code = ? OR name = ?) AND id <> ?', [$code, $name, $bid]);
        if ($dupe) {
            flash('Kode atau nama brand sudah dipakai.', 'error');
            redirect('brands.php?id=' . $bid);
        }
        if ($bid > 0) {
            db_run('UPDATE brands SET code=?, name=?, description=?, active=? WHERE id=?', [$code, $name, $desc, $active, $bid]);
            log_activity('update', 'Ubah brand ' . $code . ' - ' . $name, 'brand', $code);
            flash('Brand <strong>' . e($name) . '</strong> berhasil diperbarui.');
        } else {
            db_run('INSERT INTO brands (code, name, description, active, created_at) VALUES (?,?,?,?,?)', [$code, $name, $desc, $active, now()]);
            log_activity('create', 'Tambah brand ' . $code . ' - ' . $name, 'brand', $code);
            flash('Brand <strong>' . e($name) . '</strong> berhasil ditambahkan.');
        }
        redirect('brands.php');
    }
    if ($op === 'toggle') {
        db_run('UPDATE brands SET active = CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id = ?', [$bid]);
        log_activity('toggle', 'Ubah status aktif brand #' . $bid, 'brand', (string)$bid);
        flash('Status brand berhasil diubah.');
        redirect('brands.php');
    }
}

if ($id > 0) $edit = db_one('SELECT * FROM brands WHERE id = ?', [$id]);

$q = (string)get('q');
$where = [];
$params = [];
if ($q !== '') { $where[] = '(b.code LIKE ? OR b.name LIKE ?)'; $params[] = '%' . $q . '%'; $params[] = '%' . $q . '%'; }
$wsql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$rows = db_all(
    "SELECT b.*,
            (SELECT COUNT(*) FROM products p WHERE p.brand_id = b.id) AS product_count,
            (SELECT COALESCE(SUM(p.stock_qty),0) FROM products p WHERE p.brand_id = b.id) AS stock_qty,
            (SELECT COALESCE(SUM(p.stock_qty * p.cost_price),0) FROM products p WHERE p.brand_id = b.id) AS stock_value
       FROM brands b $wsql ORDER BY b.name",
    $params
);

page_start('Brand', 'brands');
?>
<div class="grid grid-3">
  <div class="card stat"><span class="label">Total Brand</span><span class="value"><?= fmt_num(count($rows)) ?></span><span class="hint">brand terdaftar</span></div>
  <div class="card stat"><span class="label">Brand Aktif</span><span class="value"><?= fmt_num((int)db_scalar('SELECT COUNT(*) FROM brands WHERE active = 1')) ?></span></div>
  <div class="card stat"><span class="label">Total Stok Semua Brand</span><span class="value"><?= fmt_qty((float)(db_scalar('SELECT COALESCE(SUM(stock_qty),0) FROM products') ?? 0)) ?></span><span class="hint">unit</span></div>
</div>

<section class="card">
  <?php card_start('Daftar Brand', 'Brand dipakai sebagai dimensi laporan stok.',
      '<a class="btn btn-sm" href="export.php?type=brands">' . icon('export') . ' Export Excel</a>'
      . '<a class="btn btn-sm" href="import.php?ds=brands">' . icon('import') . ' Import</a>'); ?>
    <form class="filters" method="get" style="margin-bottom:18px">
      <div class="f-item" style="min-width:240px"><label>Cari</label><input type="text" name="q" value="<?= e($q) ?>" placeholder="kode atau nama brand"></div>
      <button class="btn btn-primary" type="submit">Cari</button>
      <a class="btn" href="brands.php">Reset</a>
    </form>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Kode</th><th>Nama Brand</th><th>Keterangan</th><th class="num">Jumlah Produk</th><th class="num">Total Stok</th><th class="num">Nilai Stok</th><th>Status</th><?php if (can('master.edit')): ?><th></th><?php endif; ?></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="8"><?= empty_state('Belum ada brand.') ?></td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td class="mono"><?= e($r['code']) ?></td>
            <td><a href="brands.php?id=<?= (int)$r['id'] ?>"><?= e($r['name']) ?></a></td>
            <td><?= e($r['description'] ?: '-') ?></td>
            <td class="num"><?= fmt_num($r['product_count']) ?></td>
            <td class="num"><?= fmt_qty($r['stock_qty']) ?></td>
            <td class="num"><?= fmt_money($r['stock_value']) ?></td>
            <td><?= (int)$r['active'] === 1 ? '<span class="badge badge-ok">Aktif</span>' : '<span class="badge badge-muted">Nonaktif</span>' ?></td>
            <?php if (can('master.edit')): ?>
            <td><form class="inline-form" method="post" data-confirm="Ubah status aktif brand ini?">
              <?= csrf_field() ?><input type="hidden" name="op" value="toggle"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="btn btn-sm" type="submit"><?= (int)$r['active'] === 1 ? 'Nonaktifkan' : 'Aktifkan' ?></button>
            </form></td>
            <?php endif; ?>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<?php if (can('master.edit')): ?>
<section class="card">
  <?php card_start($edit ? ('Ubah Brand: ' . $edit['name']) : 'Tambah Brand'); ?>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="op" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
      <div class="form-grid">
        <div><label>Kode Brand *</label><input type="text" name="code" value="<?= e($edit['code'] ?? '') ?>" required></div>
        <div><label>Nama Brand *</label><input type="text" name="name" value="<?= e($edit['name'] ?? '') ?>" required></div>
        <div class="field-full"><label>Keterangan</label><input type="text" name="description" value="<?= e($edit['description'] ?? '') ?>"></div>
        <div><label>Status</label>
          <select name="active">
            <option value="1" <?= (int)($edit['active'] ?? 1) === 1 ? 'selected' : '' ?>>Aktif</option>
            <option value="0" <?= isset($edit['active']) && (int)$edit['active'] === 0 ? 'selected' : '' ?>>Nonaktif</option>
          </select>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-primary" type="submit"><?= $edit ? 'Simpan Perubahan' : 'Simpan Brand' ?></button>
        <?php if ($edit): ?><a class="btn" href="brands.php">Batal</a><?php endif; ?>
      </div>
    </form>
  <?php card_end(); ?>
</section>
<?php endif; ?>
<?php page_end(); ?>
