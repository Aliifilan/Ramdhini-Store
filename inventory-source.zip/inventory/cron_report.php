<?php
require_once __DIR__ . '/includes/init.php';

/* ============================================================
 * Endpoint untuk layanan cron (cron-job.org dsb) supaya laporan
 * terkirim tepat waktu. Dilindungi token rahasia dari pengaturan.
 *
 * Contoh: /cron_report.php?token=XXXX
 *         /cron_report.php?token=XXXX&type=daily
 *         /cron_report.php?token=XXXX&type=daily&force=1
 *
 * Sengaja hanya bisa MENGIRIM laporan (tidak bisa membaca data lain),
 * dan hanya laporan yang sudah jatuh tempo bila tanpa force.
 * ============================================================ */

header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');

$token = (string)get('token');
$expected = (string)setting('report_cron_token', '');
if ($expected === '' || strlen($token) < 32 || !hash_equals($expected, $token)) {
    http_response_code(403);
    echo "Token tidak valid.\n";
    exit;
}

if (!report_ready()) {
    echo "Laporan belum siap dikirim.\n";
    foreach (report_readiness_problems() as $p) echo '- ' . $p . "\n";
    exit;
}

$type = (string)get('type');
$force = get('force') === '1';
$lines = ['Inventori — pemeriksaan laporan: ' . now() . ' WIB'];

if ($type !== '' && in_array($type, ['daily', 'weekly', 'monthly'], true)) {
    $res = report_send($type, $force);
    $lines[] = ($res['ok'] ? '[TERKIRIM] ' : '[TIDAK DIKIRIM] ') . $res['period'] . ' — ' . $res['message'];
} else {
    $due = report_due_types();
    if (!$due) {
        $lines[] = 'Tidak ada laporan yang jatuh tempo.';
    }
    foreach ($due as $t) {
        $res = report_send($t);
        $lines[] = ($res['ok'] ? '[TERKIRIM] ' : '[GAGAL] ') . report_type_label($t) . ' (' . $res['period'] . ') — ' . $res['message'];
    }
}

echo implode("\n", $lines) . "\n";
