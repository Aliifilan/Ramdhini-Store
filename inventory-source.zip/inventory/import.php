<?php
require_once __DIR__ . '/includes/init.php';
require_perm('data.import');

$datasets = import_datasets();
$GLOBALS['datasets'] = $datasets;
$ds = (string)get('ds', 'products');
if (!isset($datasets[$ds])) $ds = 'products';

$report = null;
$reportDs = '';
$dry = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $ds = (string)post('ds');
    if (!isset($datasets[$ds])) $ds = 'products';
    $reportDs = $ds;
    $postDocs = post('posting') === '1';
    $dry = post('dry_run') === '1';

    $fileOk = isset($_FILES['file']) && is_uploaded_file($_FILES['file']['tmp_name']);
    if (!$fileOk || (int)$_FILES['file']['error'] !== 0) {
        flash('File belum dipilih atau gagal diunggah.', 'error');
        redirect('import.php?ds=' . urlencode($ds));
    }
    $name = (string)$_FILES['file']['name'];
    $kind = sheet_kind($name);
    if ($kind === null) {
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $msg = $ext === 'xls'
            ? 'File .xls (format Excel lama) belum didukung. Buka file itu di Excel, lalu pilih Simpan Sebagai → Excel Workbook (.xlsx).'
            : 'Format file harus Excel (.xlsx). Unduh template di sebelah kanan, isi datanya, lalu unggah kembali file .xlsx tersebut.';
        flash($msg, 'error');
        redirect('import.php?ds=' . urlencode($ds));
    }

    $tmp = rtrim(sys_get_temp_dir(), '/') . '/inventori_import_' . bin2hex(random_bytes(8)) . '.' . ($kind === 'xlsx' ? 'xlsx' : 'csv');
    if (!move_uploaded_file($_FILES['file']['tmp_name'], $tmp)) {
        flash('Gagal menyimpan file sementara untuk diproses.', 'error');
        redirect('import.php?ds=' . urlencode($ds));
    }

    $parsed = sheet_read($tmp, $kind);
    @unlink($tmp);

    if (!$parsed['rows']) {
        flash('File tidak berisi data yang bisa dibaca. Pastikan baris pertama berisi judul kolom (unduh template untuk contoh formatnya) dan datanya ada di baris berikutnya.', 'error');
        redirect('import.php?ds=' . urlencode($ds));
    }

    $hold = null;
    try {
        db_tx(function () use ($ds, $parsed, $postDocs, $dry, &$hold) {
            $r = run_import($ds, $parsed['rows'], $postDocs);
            $hold = $r;
            if ($dry) throw new DryRunSignal();
            log_activity('import', 'Import ' . ($GLOBALS['datasets'][$ds]['label'] ?? $ds) . ' dari file CSV: '
                . $r['created'] . ' dibuat, ' . $r['updated'] . ' diperbarui, ' . $r['skipped'] . ' dilewati, '
                . count($r['errors']) . ' error', $ds, (string)count($r['docs']));
            return $r;
        });
    } catch (DryRunSignal $sig) {
        /* uji coba: transaksi sudah di-rollback, laporan tetap ditampilkan */
    } catch (Throwable $ex) {
        flash('Import gagal: ' . e($ex->getMessage()), 'error');
        redirect('import.php?ds=' . urlencode($ds));
    }

    if (is_array($hold)) {
        $hold['dry'] = $dry;
        $hold['parsed_rows'] = count($parsed['rows']);
        $hold['columns'] = $parsed['header'];
        $report = $hold;
    }
}

$colsHint = [
    'brands' => ['code*', 'name*', 'description', 'active'],
    'suppliers' => ['code*', 'name*', 'contact_person', 'phone', 'email', 'address', 'active'],
    'products' => ['sku*', 'brand_code', 'category', 'size', 'unit', 'cost_price', 'sell_price', 'min_stock', 'active'],
    'opening' => ['sku*', 'qty*', 'cost_price', 'move_date', 'note'],
    'inbound' => ['doc_no', 'doc_date', 'supplier_code', 'sku*', 'qty*', 'unit_cost', 'note', 'status', 'discount_type', 'discount_value'],
    'outbound' => ['doc_no', 'doc_date', 'destination', 'channel', 'sku*', 'qty*', 'unit_price', 'note', 'status'],
    'returns' => ['doc_no', 'doc_date', 'type', 'party', 'ref_doc_no', 'sku*', 'qty*', 'price', 'note', 'status'],
];
/* saat di dalam closure pemrosesan dipakai lewat $GLOBALS['datasets'] */

page_start('Import Data', 'import');
?>
<?php if ($report): ?>
<section class="card">
  <?php card_start('Hasil Import ' . ($report['dry'] ? '(MODE UJI COBA — tidak ada data yang disimpan)' : '') . ': ' . $datasets[$reportDs]['label']); ?>
    <div class="grid grid-4" style="margin-bottom:16px">
      <div class="card stat"><span class="label">Dibuat</span><span class="value" style="color:var(--ok)"><?= fmt_num($report['created']) ?></span></div>
      <div class="card stat"><span class="label">Diperbarui</span><span class="value"><?= fmt_num($report['updated']) ?></span></div>
      <div class="card stat"><span class="label">Dilewati</span><span class="value"><?= fmt_num($report['skipped']) ?></span></div>
      <div class="card stat"><span class="label">Baris Bermasalah</span><span class="value" style="color:var(--danger)"><?= fmt_num(count($report['errors'])) ?></span></div>
    </div>
    <p class="small muted">Kolom terbaca: <?= e(implode(', ', $report['columns'])) ?> &middot; total baris data: <?= fmt_num($report['parsed_rows']) ?></p>

    <?php if ($report['docs']): ?>
      <h3 style="margin:18px 0 8px;font-size:13.5px">Dokumen yang dibuat (<?= fmt_num(count($report['docs'])) ?>)</h3>
      <div class="tag-list"><?php foreach (array_slice($report['docs'], 0, 60) as $d): ?><span class="pill"><?= e($d) ?></span><?php endforeach; ?>
      <?= count($report['docs']) > 60 ? '<span class="pill">+' . (count($report['docs']) - 60) . ' lainnya</span>' : '' ?></div>
    <?php endif; ?>

    <?php if ($report['errors']): ?>
      <h3 style="margin:18px 0 8px;font-size:13.5px">Baris yang dilewati karena bermasalah</h3>
      <ul class="result-list">
        <?php foreach (array_slice($report['errors'], 0, 200) as $er): ?><li class="err"><?= e($er) ?></li><?php endforeach; ?>
      </ul>
      <?php if (count($report['errors']) > 200): ?><p class="help">Dan <?= fmt_num(count($report['errors']) - 200) ?> pesan lainnya.</p><?php endif; ?>
    <?php endif; ?>

    <?php if ($report['notes']): ?>
      <h3 style="margin:18px 0 8px;font-size:13.5px">Catatan proses</h3>
      <ul class="result-list">
        <?php foreach (array_slice($report['notes'], 0, 100) as $nt): ?><li><?= e($nt) ?></li><?php endforeach; ?>
      </ul>
      <?php if (count($report['notes']) > 100): ?><p class="help">Dan <?= fmt_num(count($report['notes']) - 100) ?> catatan lainnya.</p><?php endif; ?>
    <?php endif; ?>

    <div class="form-actions">
      <a class="btn btn-primary" href="import.php?ds=<?= e($reportDs) ?>">Import File Lain</a>
      <a class="btn" href="stock.php">Lihat Stok</a>
      <a class="btn" href="ledger.php">Lihat Kartu Stok</a>
    </div>
    <?php if ($report['dry']): ?><p class="help">Mode uji coba hanya memvalidasi file — semua perubahan sudah dibatalkan. Hilangkan centang &ldquo;Mode uji coba&rdquo; untuk benar-benar menyimpan.</p><?php endif; ?>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<div class="grid grid-2">
  <section class="card">
    <?php card_start('Unggah File Excel (.xlsx)', 'Urutan kolom bebas, yang penting nama kolom (baris pertama) sama seperti template. File .csv juga masih bisa diunggah bila diperlukan.'); ?>
      <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="form-grid tight">
          <div class="field-full"><label>Jenis Data *</label>
            <select name="ds" required>
              <?php foreach ($datasets as $k => $d): ?>
                <option value="<?= e($k) ?>" <?= $ds === $k ? 'selected' : '' ?>><?= e($d['label']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field-full"><label>File Excel (.xlsx) *</label>
            <div class="file-drop">
              <input type="file" name="file" accept=".xlsx,.csv" required>
              <p class="help">Maksimal 8 MB. Paling aman: unduh <strong>template .xlsx</strong>, isi datanya, simpan apa adanya, lalu unggah kembali di sini.</p>
            </div>
          </div>
          <div>
            <label>Opsi</label>
            <label style="font-weight:500;display:flex;gap:8px;align-items:center;margin-bottom:6px">
              <input type="checkbox" name="posting" value="1" style="width:auto" checked> Langsung posting dokumen transaksi
            </label>
            <label style="font-weight:500;display:flex;gap:8px;align-items:center">
              <input type="checkbox" name="dry_run" value="1" style="width:auto"> Mode uji coba (tidak menyimpan)
            </label>
          </div>
        </div>
        <div class="form-actions">
          <button class="btn btn-primary" type="submit"><?= icon('import') ?> Proses Import</button>
        </div>
      </form>
    <?php card_end(); ?>
  </section>

  <section class="card">
    <?php card_start('Format Kolom & Template', 'Unduh template, isi datanya, lalu unggah kembali.'); ?>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Jenis Data</th><th>Kolom Wajib &amp; Opsional</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($datasets as $k => $d): ?>
            <tr>
              <td><strong><?= e($d['label']) ?></strong><div class="small muted"><?= e($d['help']) ?></div></td>
              <td class="small mono"><?= e(implode(', ', $colsHint[$k] ?? [])) ?></td>
              <td class="nowrap"><a class="btn btn-sm" href="export.php?type=template_<?= e($k) ?>"><?= icon('export') ?> Template .xlsx</a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <p class="help">Tanda * berarti wajib diisi. Kolom tanggal bisa diisi format tanggal Excel biasa (dd/mm/yyyy) atau <strong>YYYY-MM-DD</strong> &mdash; keduanya dikenali.</p>
    <?php card_end(); ?>
  </section>
</div>

<section class="card">
  <?php card_start('Tips Aman Import'); ?>
    <ul class="small" style="margin:0;padding-left:18px;line-height:1.9">
      <li>Selalu coba dulu dengan <strong>Mode uji coba</strong> supaya terlihat baris mana yang bermasalah tanpa mengubah data.</li>
      <li>Jangan mengubah/menghapus baris judul kolom, dan jangan menambah kolom baru dengan nama berbeda &mdash; kolom tambahan akan diabaikan.</li>
      <li>Untuk <strong>Produk Master</strong>, import ini memperbarui produk yang SKU-nya sudah ada (harga, nama, brand) — bukan menggandakan.</li>
      <li><strong>Stok Awal</strong> hanya berlaku untuk produk yang belum punya riwayat mutasi, sehingga import ulang tidak membuat stok dobel.</li>
      <li>Nomor dokumen (doc_no) yang sudah ada di sistem akan dilewati seluruhnya, jadi import transaksi aman diulang.</li>
      <li>Simpan backup/export sebelum melakukan import besar. Gunakan menu <strong>Export Data</strong> untuk mengunduh seluruh data terkini dalam format Excel.</li>
    </ul>
  <?php card_end(); ?>
</section>
<?php page_end(); ?>
