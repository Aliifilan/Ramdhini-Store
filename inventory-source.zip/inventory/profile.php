<?php
require_once __DIR__ . '/includes/init.php';
require_login();

$me = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $op = (string)post('op');
    if ($op === 'profile') {
        $name = (string)post('name');
        if ($name === '') {
            flash('Nama tidak boleh kosong.', 'error');
            redirect('profile.php');
        }
        db_run('UPDATE users SET name = ? WHERE id = ?', [$name, (int)$me['id']]);
        log_activity('update', 'Ubah profil sendiri', 'user', (string)$me['username']);
        flash('Profil berhasil diperbarui.');
        redirect('profile.php');
    }
    if ($op === 'password') {
        $old = (string)post('old_password');
        $new = (string)post('new_password');
        $conf = (string)post('confirm_password');
        if (!password_verify($old, (string)$me['password_hash'])) {
            flash('Password lama tidak sesuai.', 'error');
            redirect('profile.php');
        }
        if (strlen($new) < 5) {
            flash('Password baru minimal 5 karakter.', 'error');
            redirect('profile.php');
        }
        if ($new !== $conf) {
            flash('Konfirmasi password tidak sama.', 'error');
            redirect('profile.php');
        }
        db_run('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), (int)$me['id']]);
        log_activity('update', 'Ganti password sendiri', 'user', (string)$me['username']);
        flash('Password berhasil diganti.');
        redirect('profile.php');
    }
}

$myLog = db_all('SELECT * FROM activity_log WHERE user_id = ? ORDER BY id DESC LIMIT 15', [(int)$me['id']]);

page_start('Akun Saya', '');
?>
<div class="grid grid-2">
  <section class="card">
    <?php card_start('Profil', 'Informasi akun yang sedang Anda pakai.'); ?>
      <dl class="kv">
        <dt>Username</dt><dd class="mono"><?= e($me['username']) ?></dd>
        <dt>Role</dt><dd><span class="pill"><?= e(ROLES[$me['role']] ?? $me['role']) ?></span></dd>
        <dt>Dibuat</dt><dd><?= e(fmt_dt($me['created_at'])) ?></dd>
      </dl>
      <hr class="divider">
      <form method="post">
        <?= csrf_field() ?><input type="hidden" name="op" value="profile">
        <label>Nama Lengkap</label>
        <input type="text" name="name" value="<?= e($me['name']) ?>" required>
        <div class="form-actions"><button class="btn btn-primary" type="submit">Simpan Profil</button></div>
      </form>
    <?php card_end(); ?>
  </section>

  <section class="card">
    <?php card_start('Ganti Password'); ?>
      <form method="post" autocomplete="off">
        <?= csrf_field() ?><input type="hidden" name="op" value="password">
        <div class="form-grid tight">
          <div class="field-full"><label>Password Lama</label><input type="password" name="old_password" required></div>
          <div><label>Password Baru</label><input type="password" name="new_password" required></div>
          <div><label>Konfirmasi Password Baru</label><input type="password" name="confirm_password" required></div>
        </div>
        <div class="form-actions"><button class="btn btn-primary" type="submit">Ganti Password</button></div>
      </form>
    <?php card_end(); ?>
  </section>
</div>

<?php $apk = apk_info(); ?>
<?php if ($apk && $apk['exists']): ?>
<section class="card">
  <?php card_start('Aplikasi Android (APK)',
      'Pasang aplikasi Inventori di HP supaya lebih praktis dipakai saat bekerja — tombol unduhannya ada di sini, jadi bisa dibagikan ke staf juga.'); ?>
    <div class="grid grid-2" style="gap:24px;align-items:start">
      <div>
        <dl class="kv">
          <dt>Nama aplikasi</dt><dd><strong><?= e(APP_NAME) ?> &mdash; <?= e(APP_OWNER) ?></strong></dd>
          <dt>Versi</dt><dd><?= e((string)$apk['version']) ?> (build <?= e((string)$apk['version_code']) ?>)</dd>
          <dt>Ukuran berkas</dt><dd><?= e((string)$apk['size_label']) ?></dd>
          <dt>Terakhir dibangun</dt><dd><?= e((string)$apk['built']) ?> WIB</dd>
          <dt>Kode pemeriksaan (sha256)</dt><dd class="mono small"><?= e(substr((string)$apk['sha256'], 0, 32)) ?>…</dd>
        </dl>
        <div class="form-actions" style="border-top:none;padding-top:14px;margin-top:14px">
          <a class="btn btn-primary" href="<?= e((string)$apk['url']) ?>" download>
            <?= icon('download') ?> Unduh APK (<?= e((string)$apk['size_label']) ?>)
          </a>
          <a class="btn" href="<?= e((string)$apk['url']) ?>" target="_blank" rel="noopener">Buka di tab baru</a>
        </div>
      </div>
      <div>
        <h3 style="font-size:13.5px;margin-bottom:8px">Cara memasang di HP</h3>
        <ol class="small" style="margin:0;padding-left:18px;line-height:1.9">
          <li>Buka tautan di HP Android (bisa dikirim lewat WhatsApp ke staf).</li>
          <li>Unduh berkasnya, lalu buka dari notifikasi atau folder <strong>Download</strong>.</li>
          <li>Android akan meminta izin <em>“Izinkan dari sumber ini”</em> &mdash; izinkan, lalu pilih <strong>Pasang</strong>.</li>
          <li>Bila muncul peringatan Play Protect, pilih <strong>Pasang saja / Tetap pasang</strong> (aplikasi ini buatan Anda sendiri).</li>
          <li>Buka aplikasi, lalu masuk dengan akun inventori seperti biasa.</li>
        </ol>
        <p class="help" style="margin-top:10px">
          Catatan: aplikasi perlu koneksi internet karena data &amp; perhitungan stok ada di server.
          Keuntungannya, semua perbaikan aplikasi langsung terpakai di HP tanpa perlu memasang ulang.
          Ikon aplikasi: kotak putih di latar ungu-indigo.
        </p>
        <p class="help">
          Untuk administrator: bila ada perubahan kode, jalankan <span class="mono">androidapp/build.sh</span>
          lalu unggah ulang berkasnya &mdash; versi di halaman ini ikut berubah otomatis.
        </p>
      </div>
    </div>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<section class="card">
  <?php card_start('Aktivitas Saya Terakhir'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Waktu</th><th>Aksi</th><th>Keterangan</th></tr></thead>
        <tbody>
        <?php if (!$myLog): ?><tr><td colspan="3"><?= empty_state('Belum ada aktivitas.') ?></td></tr><?php endif; ?>
        <?php foreach ($myLog as $l): ?>
          <tr><td class="nowrap"><?= e(fmt_dt($l['created_at'])) ?></td><td><?= e($l['action']) ?></td><td><?= e($l['detail']) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>
<?php page_end(); ?>
