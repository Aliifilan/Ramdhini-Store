<?php
require_once __DIR__ . '/includes/init.php';
require_perm('inv.view');

$id = (int)get('id');
$product = $id > 0 ? db_one(
    "SELECT p.*, b.name AS brand_name,
            MAX(0, CAST(julianday('now') - julianday(p.created_at) AS INTEGER)) AS umur_hari
       FROM products p LEFT JOIN brands b ON b.id = p.brand_id WHERE p.id = ?",
    [$id]
) : null;
if (!$product) {
    flash('Produk tidak ditemukan.', 'error');
    redirect('stock.php');
}

$to = input_date('to', today());
$from = input_date('from', date('Y-m-d', strtotime($to . ' -29 days')));
if ($from > $to) { $t = $from; $from = $to; $to = $t; }

/* ---------- ringkasan periode ---------- */
$base = "REPLACE(l.ref_type,'_void','')";
$sum = db_one(
    "SELECT
        COALESCE(SUM(CASE WHEN $base IN ('inbound','opening') THEN l.qty_change ELSE 0 END),0) AS masuk_qty,
        COALESCE(SUM(CASE WHEN $base IN ('outbound','return_supplier') THEN -l.qty_change ELSE 0 END),0) AS keluar_qty,
        COALESCE(SUM(CASE WHEN $base = 'return_customer' THEN l.qty_change ELSE 0 END),0) AS retur_masuk,
        COALESCE(SUM(CASE WHEN $base IN ('adjustment','opname') THEN l.qty_change ELSE 0 END),0) AS penyesuaian
       FROM ledger l WHERE l.product_id = ? AND l.move_date BETWEEN ? AND ?",
    [$id, $from, $to]
);

/* nilai jual & nilai beli dari dokumen (bukan dari ledger, agar nilai rupiah tepat) */
$sold = db_one(
    "SELECT COALESCE(SUM(i.qty),0) AS qty, COALESCE(SUM(i.subtotal),0) AS amount,
            COUNT(DISTINCT o.id) AS docs
       FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
      WHERE i.product_id = ? AND o.status = 'posted' AND o.doc_date BETWEEN ? AND ?",
    [$id, $from, $to]
);
$bought = db_one(
    "SELECT COALESCE(SUM(i.qty),0) AS qty,
            COALESCE(SUM(COALESCE(NULLIF(i.subtotal_net,0), i.subtotal)),0) AS amount,
            COALESCE(SUM(i.subtotal),0) AS amount_gross,
            COALESCE(SUM(i.discount_share),0) AS discount,
            COUNT(DISTINCT o.id) AS docs
       FROM inbound_items i JOIN inbounds o ON o.id = i.inbound_id
      WHERE i.product_id = ? AND o.status = 'posted' AND o.doc_date BETWEEN ? AND ?",
    [$id, $from, $to]
);
$soldCogs = (float)(db_scalar(
    "SELECT COALESCE(SUM(i.cogs),0) FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
      WHERE i.product_id = ? AND o.status = 'posted' AND o.doc_date BETWEEN ? AND ?",
    [$id, $from, $to]
) ?? 0);

$returCus = db_one(
    "SELECT COALESCE(SUM(i.qty),0) AS qty, COALESCE(SUM(i.subtotal),0) AS amount
       FROM return_items i JOIN returns o ON o.id = i.return_id
      WHERE i.product_id = ? AND o.status = 'posted' AND o.type = 'customer' AND o.doc_date BETWEEN ? AND ?",
    [$id, $from, $to]
);
$returSup = db_one(
    "SELECT COALESCE(SUM(i.qty),0) AS qty, COALESCE(SUM(i.subtotal),0) AS amount
       FROM return_items i JOIN returns o ON o.id = i.return_id
      WHERE i.product_id = ? AND o.status = 'posted' AND o.type = 'supplier' AND o.doc_date BETWEEN ? AND ?",
    [$id, $from, $to]
);

/* ---------- detail dokumen ---------- */
$inboundRows = db_all(
    "SELECT o.doc_no, o.doc_date, o.status, o.note, o.created_at, s.name AS supplier_name,
            o.discount_type, o.discount_value, o.discount_amount,
            i.qty, i.unit_cost, i.subtotal, i.discount_share, i.unit_cost_net, i.subtotal_net, i.id AS item_id
       FROM inbound_items i JOIN inbounds o ON o.id = i.inbound_id
       LEFT JOIN suppliers s ON s.id = o.supplier_id
      WHERE i.product_id = ? AND o.doc_date BETWEEN ? AND ?
      ORDER BY o.doc_date DESC, i.id DESC",
    [$id, $from, $to]
);
$outboundRows = db_all(
    "SELECT o.doc_no, o.doc_date, o.status, o.destination, o.channel, o.created_at,
            i.qty, i.unit_price, i.subtotal, i.cogs, i.cogs_unit, i.id AS item_id
       FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
      WHERE i.product_id = ? AND o.doc_date BETWEEN ? AND ?
      ORDER BY o.doc_date DESC, i.id DESC",
    [$id, $from, $to]
);
$returnRows = db_all(
    "SELECT o.doc_no, o.doc_date, o.status, o.type, o.party, o.created_at,
            i.qty, i.unit_price, i.subtotal
       FROM return_items i JOIN returns o ON o.id = i.return_id
      WHERE i.product_id = ? AND o.doc_date BETWEEN ? AND ?
      ORDER BY o.doc_date DESC, i.id DESC",
    [$id, $from, $to]
);

/* ---------- umur stok & aktivitas penjualan ---------- */
$firstMove = db_scalar('SELECT MIN(move_date) FROM ledger WHERE product_id = ? AND ref_type LIKE ?', [$id, '%opening%']);
if (!$firstMove) $firstMove = db_scalar('SELECT MIN(move_date) FROM ledger WHERE product_id = ?', [$id]);
$lastIn = db_scalar("SELECT MAX(o.doc_date) FROM inbound_items i JOIN inbounds o ON o.id = i.inbound_id WHERE i.product_id = ? AND o.status = 'posted'", [$id]);
$lastOut = db_scalar("SELECT MAX(o.doc_date) FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id WHERE i.product_id = ? AND o.status = 'posted'", [$id]);
$soldAllTime = db_one(
    "SELECT COALESCE(SUM(i.qty),0) AS qty, COALESCE(SUM(i.subtotal),0) AS amount
       FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
      WHERE i.product_id = ? AND o.status = 'posted'",
    [$id]
);
$days = static function (?string $d): ?int {
    if (!$d) return null;
    $t = strtotime((string)$d);
    if ($t === false) return null;
    return (int)floor((strtotime(today()) - strtotime(date('Y-m-d', $t))) / 86400);
};

/* ---------- grafik masuk/keluar harian ---------- */
$mat = daily_stock_matrix(date('Y-m-d', strtotime($to . ' -13 days')), $to);
$labels = array_map(static fn($d) => date('d/m', strtotime($d)), $mat['dates']);
$flowRows = db_all(
    "SELECT move_date,
            SUM(CASE WHEN qty_change > 0 THEN qty_change ELSE 0 END) AS masuk,
            SUM(CASE WHEN qty_change < 0 THEN -qty_change ELSE 0 END) AS keluar
       FROM ledger WHERE product_id = ? AND move_date BETWEEN ? AND ? GROUP BY move_date",
    [$id, date('Y-m-d', strtotime($to . ' -13 days')), $to]
);
$flowMap = [];
foreach ($flowRows as $f) $flowMap[(string)$f['move_date']] = $f;
$inSeries = [];
$outSeries = [];
foreach ($mat['dates'] as $d) {
    $inSeries[] = (float)($flowMap[$d]['masuk'] ?? 0);
    $outSeries[] = (float)($flowMap[$d]['keluar'] ?? 0);
}

$avgSell = (float)$sold['qty'] > 0 ? (float)$sold['amount'] / (float)$sold['qty'] : (float)$product['sell_price'];
$layers = db_all(
    'SELECT * FROM stock_layers WHERE product_id = ? AND qty_remaining > 0 ORDER BY move_date, id',
    [$id]
);

page_start('Riwayat SKU: ' . $product['sku'], 'stock');
?>
<div class="grid" style="gap:16px">
  <div class="stepline no-print">
    <a class="btn btn-sm" href="stock.php"><?= icon('arrow-left') ?> Kembali ke Stok Total</a>
    <a class="btn btn-sm" href="ledger.php?product_id=<?= (int)$id ?>">Kartu Stok Lengkap</a>
    <a class="btn btn-sm" href="export.php?type=sku_history&product_id=<?= (int)$id ?>&from=<?= e($from) ?>&to=<?= e($to) ?>"><?= icon('export') ?> Export Excel (periode ini)</a>
    <button class="btn btn-sm" data-print><?= icon('print') ?> Cetak</button>
  </div>
</div>

<section class="card">
  <?php card_start('Identitas SKU', 'Ringkasan data produk dan umurnya di sistem.'); ?>
    <div class="grid grid-2" style="gap:24px">
      <dl class="kv">
        <dt>SKU</dt><dd class="mono"><strong><?= e($product['sku']) ?></strong></dd>
        <dt>Brand</dt><dd><?= e($product['brand_name'] ?? '-') ?></dd>
        <dt>Kategori</dt><dd><?= e($product['category'] ?: '-') ?></dd>
        <dt>Ukuran</dt><dd><?= (string)($product['size'] ?? '') !== '' ? '<span class="badge badge-info">' . e($product['size']) . '</span>' : '<span class="muted">-</span>' ?></dd>
        <dt>Satuan</dt><dd><?= e($product['unit']) ?></dd>
        <dt>HPP Awal</dt><dd><?= fmt_money($product['cost_price_initial'] ?: $product['cost_price']) ?>
          <span class="muted">(penerimaan pertama)</span></dd>
        <dt>HPP Rata-rata</dt><dd><strong><?= fmt_money($product['cost_price']) ?></strong>
          <span class="muted">(rata-rata lapisan stok sisa / FIFO)</span></dd>
        <dt>Harga Jual</dt><dd><?= fmt_money($product['sell_price']) ?></dd>
      </dl>
      <dl class="kv">
        <dt>Stok Saat Ini</dt><dd><strong><?= fmt_qty($product['stock_qty']) ?> <?= e($product['unit']) ?></strong>
          <?php if ((float)$product['stock_qty'] <= (float)$product['min_stock']): ?><span class="badge badge-warn">Menipis</span><?php endif; ?></dd>
        <dt>Umur SKU</dt><dd><strong><?= fmt_num($product['umur_hari']) ?> hari</strong>
          <span class="muted">(terdaftar <?= e(fmt_date($product['created_at'])) ?>)</span></dd>
        <dt>Stok pertama masuk</dt><dd><?= e(fmt_date($firstMove)) ?>
          <?php $du = $days((string)$firstMove); if ($du !== null): ?><span class="muted">— <?= fmt_num($du) ?> hari lalu</span><?php endif; ?></dd>
        <dt>Penerimaan terakhir</dt><dd><?= e(fmt_date($lastIn)) ?>
          <?php $dl = $days((string)$lastIn); if ($dl !== null): ?><span class="muted">— <?= fmt_num($dl) ?> hari lalu</span><?php endif; ?></dd>
        <dt>Penjualan terakhir</dt><dd><?= e(fmt_date($lastOut)) ?>
          <?php $do = $days((string)$lastOut); if ($do !== null): ?><span class="muted">— <?= fmt_num($do) ?> hari lalu</span><?php endif; ?></dd>
        <dt>Status</dt><dd><?= (int)$product['active'] === 1 ? '<span class="badge badge-ok">Aktif</span>' : '<span class="badge badge-muted">Nonaktif</span>' ?></dd>
      </dl>
    </div>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Periode Laporan', 'Semua tabel dan total di bawah mengikuti periode ini.',
      '<a class="btn btn-sm" href="?id=' . (int)$id . '&from=' . e(date('Y-m-01')) . '&to=' . e(today()) . '">Bulan ini</a>'
      . '<a class="btn btn-sm" href="?id=' . (int)$id . '&from=' . e(date('Y-m-01', strtotime('-1 month'))) . '&to=' . e(date('Y-m-t', strtotime('-1 month'))) . '">Bulan lalu</a>'
      . '<a class="btn btn-sm" href="?id=' . (int)$id . '&from=2000-01-01&to=' . e(today()) . '">Seluruh riwayat</a>'); ?>
    <form class="filters no-print" method="get">
      <input type="hidden" name="id" value="<?= (int)$id ?>">
      <div class="f-item"><label>Dari tanggal</label><input type="date" name="from" value="<?= e($from) ?>"></div>
      <div class="f-item"><label>Sampai tanggal</label><input type="date" name="to" value="<?= e($to) ?>"></div>
      <button class="btn btn-primary" type="submit">Tampilkan</button>
    </form>
  <?php card_end(); ?>
</section>

<div class="grid grid-4">
  <div class="card stat">
    <span class="label">Terjual (periode)</span>
    <span class="value" style="color:var(--danger)"><?= fmt_qty($sold['qty']) ?> <span class="muted" style="font-size:14px"><?= e($product['unit']) ?></span></span>
    <span class="hint"><?= fmt_num($sold['docs']) ?> dokumen barang keluar</span>
  </div>
  <div class="card stat">
    <span class="label">Nilai Penjualan (periode)</span>
    <span class="value" style="font-size:20px"><?= fmt_money($sold['amount']) ?></span>
    <span class="hint">rata-rata <?= fmt_money($avgSell) ?> / <?= e($product['unit']) ?></span>
  </div>
  <div class="card stat">
    <span class="label">HPP FIFO Barang Terjual</span>
    <span class="value" style="font-size:20px"><?= fmt_money($soldCogs) ?></span>
    <span class="hint">laba kotor <span style="color:var(--ok)"><strong><?= fmt_money((float)$sold['amount'] - $soldCogs) ?></strong></span></span>
  </div>
  <div class="card stat">
    <span class="label">Barang Masuk (periode)</span>
    <span class="value" style="color:var(--ok)">+<?= fmt_qty($bought['qty']) ?></span>
    <span class="hint">nilai beli net <?= fmt_money($bought['amount']) ?><?php if ((float)$bought['discount'] > 0): ?>
      (sebelum diskon <?= fmt_money($bought['amount_gross']) ?>, diskon &minus;<?= fmt_money($bought['discount']) ?>)<?php endif; ?></span>
  </div>
  <div class="card stat">
    <span class="label">Retur</span>
    <span class="value" style="font-size:20px">
      <span style="color:var(--ok)">+<?= fmt_qty($returCus['qty']) ?></span>
      <span class="muted">/</span>
      <span style="color:var(--danger)"><?= fmt_qty($returSup['qty']) ?></span>
    </span>
    <span class="hint">dari customer / ke supplier</span>
  </div>
</div>

<div class="grid grid-3">
  <div class="card stat"><span class="label">Masuk Menurut Kartu Stok</span><span class="value" style="font-size:20px">+<?= fmt_qty($sum['masuk_qty']) ?></span><span class="hint">inbound + stok awal</span></div>
  <div class="card stat"><span class="label">Keluar Menurut Kartu Stok</span><span class="value" style="font-size:20px"><?= fmt_qty($sum['keluar_qty']) ?></span><span class="hint">outbound + retur ke supplier</span></div>
  <div class="card stat"><span class="label">Penyesuaian (Adjustment + Opname)</span><span class="value" style="font-size:20px;color:<?= (float)$sum['penyesuaian'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ((float)$sum['penyesuaian'] >= 0 ? '+' : '') . fmt_qty($sum['penyesuaian']) ?></span></div>
</div>

<section class="card">
  <?php card_start('Arus Masuk & Keluar 14 Hari Terakhir'); ?>
    <div id="chart-sku-flow"></div>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Seluruh Data Barang Masuk (inbound) untuk SKU ini',
      'Total masuk periode ini: <strong>' . fmt_qty($bought['qty']) . ' ' . e($product['unit']) . '</strong> senilai <strong>' . fmt_money($bought['amount']) . '</strong> (setelah diskon).', ''); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal</th><th>No. Dokumen</th><th>Supplier</th><th class="num">Qty Masuk</th><th class="num">Harga Input</th><th class="num">Diskon Bagian</th><th class="num">Harga Setelah Diskon</th><th class="num">Nilai Net</th><th>Status</th><th>Catatan</th></tr></thead>
        <tbody>
        <?php if (!$inboundRows): ?><tr><td colspan="10"><?= empty_state('Belum ada barang masuk untuk SKU ini pada periode terpilih.') ?></td></tr><?php endif; ?>
        <?php $tq = 0.0; $ta = 0.0; foreach ($inboundRows as $r): $net = (float)($r['subtotal_net'] ?: $r['subtotal']); $tq += (float)$r['qty']; $ta += $net; ?>
          <tr>
            <td class="nowrap"><?= e(fmt_date($r['doc_date'])) ?>
              <?php if (!empty($r['created_at'])): ?><div class="muted small"><?= e(fmt_time($r['created_at'])) ?></div><?php endif; ?></td>
            <td class="mono"><a href="inbound_form.php?id=<?= (int)db_scalar('SELECT id FROM inbounds WHERE doc_no = ?', [$r['doc_no']]) ?>"><?= e($r['doc_no']) ?></a></td>
            <td><?= e($r['supplier_name'] ?? '-') ?></td>
            <td class="num"><strong><?= fmt_qty($r['qty']) ?></strong></td>
            <td class="num"><?= fmt_money($r['unit_cost']) ?></td>
            <td class="num"><?= (float)$r['discount_share'] > 0 ? '<span style="color:var(--ok)">&minus;' . fmt_money($r['discount_share']) . '</span>' : '-' ?>
              <?php if ((float)($r['discount_amount'] ?? 0) > 0): ?>
                <div class="small muted">diskon dokumen:
                  <?= (string)$r['discount_type'] === 'percent' ? fmt_num($r['discount_value'], 2) . '%' : fmt_money($r['discount_value']) ?></div>
              <?php endif; ?></td>
            <td class="num"><strong><?= fmt_money($r['unit_cost_net'] ?: $r['unit_cost']) ?></strong></td>
            <td class="num"><?= fmt_money($net) ?></td>
            <td><?= status_badge((string)$r['status']) ?></td>
            <td class="small"><?= e($r['note'] ?: '-') ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if ($inboundRows): ?>
        <tr class="totals-row"><td colspan="3">TOTAL BARANG MASUK (periode)</td><td class="num"><?= fmt_qty($tq) ?></td><td></td><td class="num"><?= fmt_money($bought['discount'] ?? 0) ?></td><td></td><td class="num"><?= fmt_money($ta) ?></td><td colspan="2"></td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Seluruh Data Barang Keluar (outbound) untuk SKU ini',
      'Terjual periode ini: <strong>' . fmt_qty($sold['qty']) . ' ' . e($product['unit']) . '</strong> senilai <strong>' . fmt_money($sold['amount']) . '</strong>'
      . ' · sepanjang waktu: ' . fmt_qty($soldAllTime['qty']) . ' ' . e($product['unit']) . ' / ' . fmt_money($soldAllTime['amount'])); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal</th><th>No. Dokumen</th><th>Tujuan / Pembeli</th><th>Channel</th><th class="num">Qty Keluar</th><th class="num">Harga Jual</th><th class="num">Nilai</th><th class="num">HPP FIFO</th><th class="num">Laba Kotor</th><th>Status</th></tr></thead>
        <tbody>
        <?php if (!$outboundRows): ?><tr><td colspan="10"><?= empty_state('Belum ada barang keluar untuk SKU ini pada periode terpilih.') ?></td></tr><?php endif; ?>
        <?php $tq = 0.0; $ta = 0.0; $tc = 0.0; foreach ($outboundRows as $r): $tq += (float)$r['qty']; $ta += (float)$r['subtotal']; $tc += (float)($r['cogs'] ?? 0); ?>
          <tr>
            <td class="nowrap"><?= e(fmt_date($r['doc_date'])) ?>
              <?php if (!empty($r['created_at'])): ?><div class="muted small"><?= e(fmt_time($r['created_at'])) ?></div><?php endif; ?></td>
            <td class="mono"><a href="outbound_form.php?id=<?= (int)db_scalar('SELECT id FROM outbounds WHERE doc_no = ?', [$r['doc_no']]) ?>"><?= e($r['doc_no']) ?></a></td>
            <td><?= e($r['destination'] ?: '-') ?></td>
            <td><?= e($r['channel'] ?: '-') ?></td>
            <td class="num"><strong><?= fmt_qty($r['qty']) ?></strong></td>
            <td class="num"><?= fmt_money($r['unit_price']) ?></td>
            <td class="num"><?= fmt_money($r['subtotal']) ?></td>
            <td class="num"><?php if ((float)($r['cogs'] ?? 0) > 0): ?><strong><?= fmt_money($r['cogs']) ?></strong>
                <div class="small muted"><?= fmt_money($r['cogs_unit'] ?? 0) ?> / unit</div>
              <?php else: ?><span class="muted">-</span><?php endif; ?></td>
            <td class="num"><?= (float)($r['cogs'] ?? 0) > 0
                ? '<span style="color:var(--ok)">' . fmt_money((float)$r['subtotal'] - (float)$r['cogs']) . '</span>'
                : '<span class="muted">-</span>' ?></td>
            <td><?= status_badge((string)$r['status']) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if ($outboundRows): ?>
        <tr class="totals-row"><td colspan="4">TOTAL TERJUAL (periode)</td><td class="num"><?= fmt_qty($tq) ?></td><td></td><td class="num"><?= fmt_money($ta) ?></td><td class="num"><?= fmt_money($tc) ?></td><td class="num"><?= fmt_money($ta - $tc) ?></td><td></td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Lapisan Stok FIFO yang Masih Tersisa',
      'Metode FIFO: setiap penerimaan menjadi satu lapisan. Barang keluar mengambil lapisan paling tua lebih dulu, sehingga ketahuan HPP berapa yang sebenarnya terjual.'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal Masuk</th><th>No. Dokumen</th><th>Sumber</th><th class="num">Qty Masuk</th><th class="num">Sisa</th><th class="num">HPP Satuan</th><th class="num">Nilai Sisa</th></tr></thead>
        <tbody>
        <?php if (!$layers): ?><tr><td colspan="7"><?= empty_state('Belum ada lapisan stok untuk SKU ini.') ?></td></tr><?php endif; ?>
        <?php $tqL = 0.0; $tvL = 0.0; foreach ($layers as $l): $tqL += (float)$l['qty_remaining']; $tvL += (float)$l['qty_remaining'] * (float)$l['unit_cost']; ?>
          <tr>
            <td class="nowrap"><?= e(fmt_date($l['move_date'])) ?></td>
            <td class="mono"><?= e($l['ref_no'] ?: '-') ?></td>
            <td><?= e(doc_label((string)$l['ref_type'])) ?></td>
            <td class="num"><?= fmt_qty($l['qty_original']) ?></td>
            <td class="num"><strong><?= fmt_qty($l['qty_remaining']) ?></strong></td>
            <td class="num"><?= fmt_money($l['unit_cost']) ?></td>
            <td class="num"><?= fmt_money((float)$l['qty_remaining'] * (float)$l['unit_cost']) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if ($layers): ?>
        <tr class="totals-row">
          <td colspan="4">SISA STOK BERDASARKAN FIFO</td>
          <td class="num"><?= fmt_qty($tqL) ?></td>
          <td class="num">rata-rata <?= fmt_money($tqL > 0 ? $tvL / $tqL : 0) ?></td>
          <td class="num"><?= fmt_money($tvL) ?></td>
        </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Data Retur untuk SKU ini'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal</th><th>No. Dokumen</th><th>Jenis</th><th>Pihak</th><th class="num">Qty</th><th class="num">Nilai</th><th>Status</th></tr></thead>
        <tbody>
        <?php if (!$returnRows): ?><tr><td colspan="7"><?= empty_state('Tidak ada retur untuk SKU ini pada periode terpilih.') ?></td></tr><?php endif; ?>
        <?php foreach ($returnRows as $r): ?>
          <tr>
            <td class="nowrap"><?= e(fmt_date($r['doc_date'])) ?>
              <?php if (!empty($r['created_at'])): ?><div class="muted small"><?= e(fmt_time($r['created_at'])) ?></div><?php endif; ?></td>
            <td class="mono"><?= e($r['doc_no']) ?></td>
            <td><?= $r['type'] === 'supplier' ? '<span class="badge badge-danger">Ke Supplier</span>' : '<span class="badge badge-ok">Dari Customer</span>' ?></td>
            <td><?= e($r['party'] ?: '-') ?></td>
            <td class="num"><?= fmt_qty($r['qty']) ?></td>
            <td class="num"><?= fmt_money($r['subtotal']) ?></td>
            <td><?= status_badge((string)$r['status']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<script src="<?= e(asset_url('assets/charts.js')) ?>"></script>
<script>
renderLineChart('chart-sku-flow', {
  labels: <?= json_encode($labels) ?>,
  series: [
    { name: 'Masuk', color: '#10B981', values: <?= json_encode($inSeries) ?> },
    { name: 'Keluar (terjual)', color: '#F472B6', values: <?= json_encode($outSeries) ?> }
  ]
});
</script>
<?php page_end(); ?>
