<?php
require_once __DIR__ . '/includes/init.php';
require_perm('inv.view');

$skuActive = (int)db_scalar('SELECT COUNT(*) FROM products WHERE active = 1');
$skuTotal = (int)db_scalar('SELECT COUNT(*) FROM products');
$stockQty = (float)(db_scalar('SELECT COALESCE(SUM(stock_qty),0) FROM products') ?? 0);
$stockVal = (float)(db_scalar('SELECT COALESCE(SUM(stock_qty*cost_price),0) FROM products') ?? 0);
$sellVal = (float)(db_scalar('SELECT COALESCE(SUM(stock_qty*sell_price),0) FROM products') ?? 0);
$lowCount = (int)db_scalar('SELECT COUNT(*) FROM products WHERE active=1 AND stock_qty <= min_stock');
$brandCount = (int)db_scalar('SELECT COUNT(*) FROM brands WHERE active=1');
$supplierCount = (int)db_scalar('SELECT COUNT(*) FROM suppliers WHERE active=1');

$todayIn = (float)(db_scalar("SELECT COALESCE(SUM(qty_change),0) FROM ledger WHERE ref_type='inbound' AND move_date = ?", [today()]) ?? 0);
$todayOut = (float)(db_scalar("SELECT COALESCE(SUM(qty_change),0) FROM ledger WHERE ref_type='outbound' AND move_date = ?", [today()]) ?? 0);
$draftCount = (int)db_scalar("SELECT (SELECT COUNT(*) FROM inbounds WHERE status='draft') + (SELECT COUNT(*) FROM outbounds WHERE status='draft') + (SELECT COUNT(*) FROM returns WHERE status='draft') + (SELECT COUNT(*) FROM adjustments WHERE status='draft') + (SELECT COUNT(*) FROM opnames WHERE status='draft')");

$to = today();
$from = date('Y-m-d', strtotime('-13 days'));
$matrix = daily_stock_matrix($from, $to);
$labels = array_map(static fn($d) => date('d/m', strtotime($d)), $matrix['dates']);
$stockSeries = array_map(static fn($d) => (float)$matrix['totals'][$d], $matrix['dates']);

$flow = db_all(
    "SELECT move_date,
            SUM(CASE WHEN qty_change > 0 THEN qty_change ELSE 0 END) AS ins,
            SUM(CASE WHEN qty_change < 0 THEN qty_change ELSE 0 END) AS outs
       FROM ledger WHERE move_date BETWEEN ? AND ? GROUP BY move_date ORDER BY move_date",
    [$from, $to]
);
$flowMap = [];
foreach ($flow as $f) $flowMap[(string)$f['move_date']] = $f;
$inSeries = [];
$outSeries = [];
foreach ($matrix['dates'] as $d) {
    $inSeries[] = (float)($flowMap[$d]['ins'] ?? 0);
    $outSeries[] = abs((float)($flowMap[$d]['outs'] ?? 0));
}

$lowStock = db_all(
    "SELECT p.*, b.name AS brand_name FROM products p LEFT JOIN brands b ON b.id = p.brand_id
      WHERE p.active = 1 AND p.stock_qty <= p.min_stock ORDER BY (p.stock_qty - p.min_stock), p.sku LIMIT 10"
);
/* Menampilkan STOK SAAT INI (bukan saldo lampau saat baris itu dibuat) supaya tidak
   membingungkan: baris lama bisa menyimpan saldo minus yang sekarang sudah diperbaiki. */
$recentLedger = db_all(
    "SELECT l.*, p.sku, p.stock_qty AS stock_now, u.name AS user_name FROM ledger l
       JOIN products p ON p.id = l.product_id LEFT JOIN users u ON u.id = l.user_id
      ORDER BY l.id DESC LIMIT 8"
);
$topOut = db_all(
    "SELECT p.id, p.sku, SUM(-l.qty_change) AS qty FROM ledger l JOIN products p ON p.id = l.product_id
      WHERE l.ref_type = 'outbound' AND l.move_date >= ? GROUP BY p.id ORDER BY qty DESC LIMIT 6",
    [date('Y-m-d', strtotime('-30 days'))]
);
$recentActivity = db_all('SELECT * FROM activity_log ORDER BY id DESC LIMIT 6');
/* Diagram lingkaran stok per brand: potongan bisa diklik ke produk brand itu. */
$brandPie = brand_pie_rows(stock_by_brand_rows(), null, 'stock_qty',
    static fn(float $v): string => fmt_qty($v) . ' unit', 7);

$me = current_user();
$stillDefault = $me && password_verify('admin123', (string)$me['password_hash']);
$noData = $skuTotal === 0;

page_start('Dashboard', 'dashboard');
?>
<?php if ($stillDefault): ?>
<div class="alert alert-warn">
  <strong>Keamanan akun:</strong> password akun <em><?= e($me['username']) ?></em> masih memakai password bawaan.
  Segera ganti di menu <a href="profile.php"><strong>Akun Saya &rarr; Ganti Password</strong></a> agar data inventory tetap aman.
</div>
<?php endif; ?>

<?php
$minusStock = db_all('SELECT id, sku, stock_qty FROM products WHERE active = 1 AND stock_qty < 0 ORDER BY stock_qty');
?>
<?php if ($minusStock): ?>
<div class="alert alert-error">
  <strong>Ada stok minus!</strong>
  <?php $mm = []; foreach ($minusStock as $m) { $mm[] = '<a href="sku_detail.php?id=' . (int)$m['id'] . '">' . e($m['sku']) . '</a> (' . fmt_qty($m['stock_qty']) . ')'; } ?>
  <?= implode(', ', $mm) ?>.
  Stok minus terjadi bila dokumen masuk di-void padahal barangnya sudah keluar/terjual.
  Perbaikannya: isi <a href="inbound_form.php">dokumen barang masuk</a> pengganti, atau
  <a href="adjustment_form.php">Stok Adjustment</a> dengan alasan yang sesuai.
</div>
<?php endif; ?>

<?php if ($noData): ?>
<section class="card">
  <?php card_start('Mulai dari sini', 'Urutan pengerjaan yang disarankan supaya angka stok konsisten sejak awal.'); ?>
    <div class="grid grid-3" style="gap:16px">
      <div>
        <h3 style="font-size:13.5px;margin-bottom:6px">1. Isi master data</h3>
        <p class="small muted" style="margin-top:0">Buat <a href="brands.php">Brand</a>, <a href="suppliers.php">Supplier</a>, lalu <a href="products.php">Produk Master</a> (bisa sekaligus lewat <a href="import.php">Import Excel</a>).</p>
        <h3 style="font-size:13.5px;margin-bottom:6px">2. Tambah pengguna</h3>
        <p class="small muted" style="margin-top:0">Di menu <a href="users.php">Pengguna</a>, buat akun Staf Gudang untuk operator harian. Semua aksi mereka tercatat di Log Aktivitas.</p>
      </div>
      <div>
        <h3 style="font-size:13.5px;margin-bottom:6px">3. Masukkan stok awal</h3>
        <p class="small muted" style="margin-top:0">Import <strong>Stok Awal</strong> (alur <em>opening</em>) atau pakai <a href="adjustments.php">Stok Adjustment</a> dengan alasan &ldquo;Stok Awal&rdquo;. Stok selalu berubah lewat dokumen, tidak pernah diketik langsung.</p>
        <h3 style="font-size:13.5px;margin-bottom:6px">4. Jalankan transaksi harian</h3>
        <p class="small muted" style="margin-top:0"><a href="inbound.php">Barang Masuk</a> saat kulakan, <a href="outbound.php">Barang Keluar</a> saat ada pesanan. Simpan sebagai draft dulu bila ingin diperiksa, lalu Posting.</p>
      </div>
      <div>
        <h3 style="font-size:13.5px;margin-bottom:6px">5. Koreksi bila salah</h3>
        <p class="small muted" style="margin-top:0">Salah input dokumen &rarr; pakai <strong>Void</strong> (khusus Admin). Hasil hitung fisik &rarr; <a href="opnames.php">Stok Opname</a>. Barang kembali &rarr; <a href="returns.php">Retur</a>.</p>
        <h3 style="font-size:13.5px;margin-bottom:6px">6. Pantau &amp; cadangkan</h3>
        <p class="small muted" style="margin-top:0">Cek <a href="daily_stock.php">Daily Stock</a> dan <a href="reports.php">Laporan Ringkas</a>, lalu unduh backup rutin di menu <a href="export.php">Export Data</a>.</p>
      </div>
    </div>
  <?php card_end(); ?>
</section>
<?php endif; ?>
<div class="grid grid-4">
  <div class="card stat">
    <span class="label">Total Unit Stok</span>
    <span class="value"><?= fmt_qty($stockQty) ?></span>
    <span class="hint"><?= fmt_num($skuActive) ?> SKU aktif dari <?= fmt_num($skuTotal) ?> produk</span>
  </div>
  <div class="card stat">
    <span class="label">Nilai Stok (HPP)</span>
    <span class="value" style="font-size:22px"><?= fmt_money($stockVal) ?></span>
    <span class="hint">potensi jual <?= fmt_money($sellVal) ?></span>
  </div>
  <div class="card stat">
    <span class="label">Mutasi Hari Ini</span>
    <span class="value" style="font-size:20px">
      <span style="color:var(--ok)">+<?= fmt_qty($todayIn) ?></span>
      <span class="muted">/</span>
      <span style="color:var(--danger)"><?= fmt_qty($todayOut) ?></span>
    </span>
    <span class="hint">masuk / keluar (<?= e(fmt_date(today())) ?>)</span>
  </div>
  <div class="card stat">
    <span class="label">Perlu Perhatian</span>
    <span class="value" style="font-size:20px">
      <?= fmt_num($lowCount) ?> <span class="muted">menipis</span>
    </span>
    <span class="hint"><?= fmt_num($draftCount) ?> dokumen draft belum diposting</span>
  </div>
</div>

<div class="grid grid-2">
  <section class="card">
    <?php card_start('Tren Stok 14 Hari Terakhir', 'Posisi stok akhir hari seluruh produk.', '<a class="btn btn-sm" href="daily_stock.php">Detail</a>'); ?>
      <div id="chart-stock"></div>
    <?php card_end(); ?>
  </section>
  <section class="card">
    <?php card_start('Barang Masuk vs Keluar', 'Perbandingan unit masuk dan keluar per hari.', '<a class="btn btn-sm" href="ledger.php">Kartu Stok</a>'); ?>
      <div id="chart-flow"></div>
    <?php card_end(); ?>
  </section>
</div>

<div class="grid grid-3">
  <section class="card">
    <?php card_start('Stok per Brand', 'Arahkan kursor ke potongan untuk melihat jumlahnya, klik untuk membuka produk brand tersebut.', '<a class="btn btn-sm" href="stock_brand.php">Semua brand</a>'); ?>
      <div id="chart-brand"></div>
    <?php card_end(); ?>
  </section>
  <section class="card">
    <?php card_start('Produk Keluar Terbanyak', '30 hari terakhir berdasarkan dokumen barang keluar.', '<a class="btn btn-sm" href="reports.php">Laporan</a>'); ?>
      <?php if (!$topOut): ?>
        <?= empty_state('Belum ada transaksi barang keluar.') ?>
      <?php else: ?>
        <div class="table-wrap">
          <table>
            <thead><tr><th>SKU</th><th class="num">Unit Keluar</th></tr></thead>
            <tbody>
            <?php foreach ($topOut as $t): ?>
              <tr><td class="mono"><a href="sku_detail.php?id=<?= (int)$t['id'] ?>"><?= e($t['sku']) ?></a></td><td class="num"><strong><?= fmt_qty($t['qty']) ?></strong></td></tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    <?php card_end(); ?>
  </section>
  <section class="card">
    <?php card_start('Aktivitas Terakhir', 'Siapa mengerjakan apa.', '<a class="btn btn-sm" href="activity.php">Log lengkap</a>'); ?>
      <?php if (!$recentActivity): ?>
        <?= empty_state('Belum ada aktivitas.') ?>
      <?php else: ?>
        <ul class="result-list">
          <?php foreach ($recentActivity as $a): ?>
            <li><strong><?= e($a['username']) ?></strong> &middot; <?= e($a['action']) ?><div class="small muted"><?= e($a['detail']) ?> &middot; <?= e(fmt_dt($a['created_at'])) ?></div></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    <?php card_end(); ?>
  </section>
</div>

<div class="grid grid-2">
  <section class="card">
    <?php card_start('Stok Menipis / Habis', 'Produk dengan stok sama atau di bawah batas minimum.',
        '<a class="btn btn-sm" href="stock.php?low=1">Lihat semua</a>'
        . (can('tx.create') ? '<a class="btn btn-sm btn-primary" href="inbound_form.php">' . icon('plus') . ' Barang Masuk</a>' : '')); ?>
      <?php if (!$lowStock): ?>
        <?= empty_state('Semua stok aman. Tidak ada produk di bawah batas minimum.') ?>
      <?php else: ?>
        <div class="table-wrap">
          <table>
            <thead><tr><th>SKU</th><th>Brand</th><th class="num">Stok</th><th class="num">Min</th><th class="num">Kurang</th></tr></thead>
            <tbody>
            <?php foreach ($lowStock as $r): ?>
              <tr>
                <td class="mono"><a href="sku_detail.php?id=<?= (int)$r['id'] ?>"><?= e($r['sku']) ?></a></td>
                <td><?= e($r['brand_name'] ?? '-') ?></td>
                <td class="num" style="color:var(--danger)"><strong><?= fmt_qty($r['stock_qty']) ?></strong></td>
                <td class="num"><?= fmt_qty($r['min_stock']) ?></td>
                <td class="num"><?= fmt_qty((float)$r['min_stock'] - (float)$r['stock_qty']) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    <?php card_end(); ?>
  </section>

  <section class="card">
    <?php card_start('Pergerakan Stok Terbaru', '', '<a class="btn btn-sm" href="ledger.php">Kartu stok</a>'); ?>
      <?php if (!$recentLedger): ?>
        <?= empty_state('Belum ada pergerakan stok. Mulai dengan menambah produk dan barang masuk.') ?>
      <?php else: ?>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Tanggal &middot; Jam</th><th>Dokumen</th><th>Jenis</th><th>SKU</th><th class="num">Perubahan</th><th class="num">Stok Kini</th><th>Petugas</th></tr></thead>
            <tbody>
            <?php foreach ($recentLedger as $l): ?>
              <tr>
                <td class="nowrap"><?= e(fmt_date($l['move_date'])) ?>
                  <?php if (!empty($l['created_at'])): ?><div class="muted small"><?= e(fmt_time($l['created_at'])) ?></div><?php endif; ?></td>
                <td class="mono"><?= e($l['ref_no'] ?: '-') ?></td>
                <td class="small"><?= e(doc_label((string)$l['ref_type'])) ?></td>
                <td><?= e($l['sku']) ?></td>
                <td class="num" style="color:<?= (float)$l['qty_change'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ((float)$l['qty_change'] >= 0 ? '+' : '') . fmt_qty($l['qty_change']) ?></td>
                <td class="num"><strong><?= fmt_qty($l['stock_now']) ?></strong></td>
                <td class="small"><?= e($l['user_name'] ?? '-') ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    <?php card_end(); ?>
  </section>
</div>

<script src="<?= e(asset_url('assets/charts.js')) ?>"></script>
<script>
renderLineChart('chart-stock', {
  labels: <?= json_encode($labels) ?>,
  series: [{ name: 'Total stok (unit)', color: '#4F46E5', values: <?= json_encode($stockSeries) ?> }]
});
renderLineChart('chart-flow', {
  labels: <?= json_encode($labels) ?>,
  series: [
    { name: 'Masuk', color: '#10B981', values: <?= json_encode($inSeries) ?> },
    { name: 'Keluar', color: '#F472B6', values: <?= json_encode($outSeries) ?> }
  ]
});
renderPieChart('chart-brand', {
  rows: <?= json_encode($brandPie, JSON_UNESCAPED_UNICODE) ?>,
  centerLabel: 'Total stok',
  centerValue: <?= json_encode(fmt_qty(array_sum(array_column($brandPie, 'value'))) . ' unit') ?>,
  title: 'Stok per brand'
});
</script>
<?php page_end(); ?>
