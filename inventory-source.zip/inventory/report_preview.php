<?php
require_once __DIR__ . '/includes/init.php';

/* Pratinjau isi email laporan (hanya Admin). Menampilkan HTML yang sama
   dengan yang dikirim, sehingga bisa dicek sebelum diaktifkan. */
if (!is_admin()) {
    flash('Hanya Admin yang boleh melihat pratinjau laporan.', 'error');
    redirect('index.php');
}

$type = (string)get('type', 'daily');
if (!in_array($type, ['daily', 'weekly', 'monthly'], true)) $type = 'daily';

[$from, $to, $label] = report_period($type);
$data = report_data($from, $to);
$subject = report_subject($type, $data);
$html = report_html($type, $data);

/* tampilkan surat lengkap dengan kepala email, bukan hanya badan HTML-nya */
?><!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pratinjau Laporan <?= e(report_type_label($type)) ?></title>
<style>
  body{margin:0;background:#EDEAFB;font-family:Inter,-apple-system,Segoe UI,Roboto,Arial,sans-serif;color:#1F1B3A}
  .bar{background:#fff;border-bottom:1px solid #E7E4F5;padding:12px 18px;position:sticky;top:0;z-index:5}
  .bar-in{max-width:760px;margin:0 auto;display:flex;gap:12px;align-items:center;flex-wrap:wrap}
  .bar a{color:#4F46E5;text-decoration:none;font-weight:600;font-size:13.5px;padding:7px 12px;border:1px solid #DDD8F5;border-radius:9px;background:#fff}
  .bar a.on{background:linear-gradient(135deg,#4F46E5,#8B5CF6);color:#fff;border-color:transparent}
  .wrap{max-width:720px;margin:18px auto 40px;padding:0 14px}
  .meta{background:#fff;border:1px solid #E7E4F5;border-radius:12px;padding:12px 16px;font-size:13px;margin-bottom:14px}
  .meta b{color:#1F1B3A}
  .meta div{padding:3px 0;color:#635F82}
  .frame{background:#F3F0FF;border:1px solid #E7E4F5;border-radius:14px;overflow:hidden}
</style>
</head>
<body>
<div class="bar"><div class="bar-in">
  <strong style="font-size:14px">Pratinjau Email</strong>
  <a class="<?= $type === 'daily' ? 'on' : '' ?>" href="?type=daily">Harian</a>
  <a class="<?= $type === 'weekly' ? 'on' : '' ?>" href="?type=weekly">Mingguan</a>
  <a class="<?= $type === 'monthly' ? 'on' : '' ?>" href="?type=monthly">Bulanan</a>
  <span style="flex:1"></span>
  <a href="report_settings.php">Kembali ke Pengaturan</a>
</div></div>
<div class="wrap">
  <div class="meta">
    <div><b>Dari:</b> <?= e((string)setting('report_sender_name')) ?> &lt;<?= e((string)setting('report_sender_email') ?: 'belum diisi') ?>&gt;</div>
    <div><b>Kepada:</b> <?= e(report_recipients() ? implode(', ', report_recipients()) : 'belum ada penerima') ?></div>
    <div><b>Subjek:</b> <?= e($subject) ?></div>
    <div><b>Isi:</b> HTML + versi teks (untuk aplikasi email yang tidak mendukung HTML)</div>
  </div>
  <div class="frame"><?= $html ?></div>
</div>
</body>
</html>
