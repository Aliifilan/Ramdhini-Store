<?php
require_once __DIR__ . '/includes/init.php';
require_perm('data.export');

$type = (string)get('type');
if ($type !== '') {
    $isTemplate = str_starts_with($type, 'template_');
    if (!$isTemplate && !array_key_exists($type, export_datasets())) {
        http_response_code(400);
        exit('Jenis export tidak dikenal.');
    }
    log_activity('export', 'Export data: ' . $type, $type, '');
    export_run($type, [
        'from' => input_date('from', date('Y-m-d', strtotime('-30 days'))),
        'to' => input_date('to', today()),
        'status' => (string)get('status'),
        'product_id' => get('product_id'),
        'ref_type' => get('ref_type'),
    ]);
    exit;
}

$from = input_date('from', date('Y-m-d', strtotime('-30 days')));
$to = input_date('to', today());
$filtered = ['daily_stock', 'ledger', 'inbound', 'inbound_items', 'outbound', 'outbound_items', 'adjustments', 'adjustment_items', 'opnames', 'opname_items', 'returns', 'return_items', 'activity'];
$qparams = 'from=' . urlencode($from) . '&to=' . urlencode($to);

page_start('Export Data', 'export');
?>
<div class="grid grid-2">
  <section class="card">
    <?php card_start('Filter Periode Export', 'Dipakai untuk semua export yang berbasis tanggal (transaksi, kartu stok, daily stock, log).'); ?>
      <form class="filters" method="get">
        <input type="hidden" name="page" value="1">
        <div class="f-item"><label>Dari tanggal</label><input type="date" name="from" value="<?= e($from) ?>"></div>
        <div class="f-item"><label>Sampai tanggal</label><input type="date" name="to" value="<?= e($to) ?>"></div>
        <button class="btn btn-primary" type="submit">Terapkan</button>
      </form>
      <p class="help">Semua file unduhan berformat <strong>Excel (.xlsx)</strong> &mdash; bisa dibuka langsung di Excel, WPS, atau Google Sheets tanpa pengaturan tambahan. Angka tetap terbaca sebagai angka (bukan teks), judul kolom dicetak tebal, dan baris judul dibekukan.</p>
    <?php card_end(); ?>
  </section>
  <section class="card">
    <?php card_start('Template Import', 'Unduh template Excel kosong sesuai format import.'); ?>
      <div class="tag-list">
        <?php foreach (export_templates() as $key => $cols): ?>
          <a class="btn btn-sm" href="export.php?type=template_<?= e($key) ?>"><?= icon('export') ?> template_<?= e($key) ?>.xlsx</a>
        <?php endforeach; ?>
      </div>
      <p class="help">Template berisi baris judul kolom saja, siap diisi data Anda. Kolom wajib diberi tanda * pada menu Import Data.</p>
    <?php card_end(); ?>
  </section>
</div>

<section class="card">
  <?php card_start('Pilih Data yang Ingin Diexport ke Excel', 'Setiap alur kerja punya tombol export-nya sendiri.'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Jenis Data</th><th>Keterangan</th><th></th></tr></thead>
        <tbody>
        <?php foreach (export_datasets() as $key => $label): ?>
          <tr>
            <td><strong><?= e($label) ?></strong><?= in_array($key, $filtered, true) ? ' <span class="pill">pakai filter tanggal</span>' : '' ?></td>
            <td class="small muted"><?= e(in_array($key, $filtered, true) ? 'Periode: ' . fmt_date($from) . ' – ' . fmt_date($to) : 'Seluruh data terkini') ?></td>
            <td class="right nowrap"><a class="btn btn-sm btn-primary" href="export.php?type=<?= e($key) ?>&<?= e($qparams) ?>"><?= icon('export') ?> Download Excel</a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>
<?php page_end(); ?>
