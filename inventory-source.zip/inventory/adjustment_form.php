<?php
require_once __DIR__ . '/includes/init.php';
require_perm('inv.view');

const ADJ_REASONS = ['Stok Awal', 'Koreksi Salah Input', 'Barang Rusak', 'Barang Hilang / Susut', 'Barang Kadaluarsa', 'Lainnya'];

$id = (int)get('id');
$products = db_all(
    "SELECT p.id, p.sku, p.unit, p.stock_qty FROM products p WHERE p.active = 1 ORDER BY p.sku"
);
$brands = db_all('SELECT id, name FROM brands WHERE active = 1 ORDER BY name');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $op = (string)post('op');
    $did = (int)post('id');

    if ($op === 'void') {
        if (!is_admin()) {
            flash('Hanya Admin yang boleh melakukan void dokumen.', 'error');
        } else {
            $reason = (string)post('void_reason');
            $res = void_document('adjustment', $did, $reason !== '' ? $reason : 'tanpa alasan');
            if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil di-void dan stok dikembalikan.');
            if (!empty($res['warning'])) flash($res['warning'], 'warn');
            else flash('Gagal void: ' . e(implode(' ', $res['errors'])), 'error');
        }
        redirect('adjustment_form.php?id=' . $did);
    }

    if ($op === 'post_id') {
        $res = post_document('adjustment', $did);
        if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil diposting.');
        else flash('Gagal posting: ' . e(implode(' ', $res['errors'])), 'error');
        redirect('adjustment_form.php?id=' . $did);
    }

    if ($op === 'save' || $op === 'save_post') {
        if (!can('inv.adjust')) {
            flash('Role Anda tidak boleh membuat penyesuaian stok.', 'error');
            redirect('adjustments.php');
        }
        $docDate = (string)post('doc_date');
        $reason = (string)post('reason');
        $note = (string)post('note');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $docDate)) $docDate = today();
        if (!in_array($reason, ADJ_REASONS, true)) $reason = 'Lainnya';

        $skus = (array)post('item_sku', []);
        $afters = (array)post('item_after', []);
        $resolved = resolve_skus($skus);
        $pids = $resolved['ids'];
        $filled = 0;
        foreach ($skus as $i => $sku) {
            if (!empty($pids[$i]) && trim((string)($afters[$i] ?? '')) !== '') $filled++;
        }
        if ($resolved['unknown']) {
            flash(unknown_sku_message($resolved['unknown']), 'warn');
        }
        if ($filled === 0) {
            flash('Scan atau ketik SKU yang terdaftar, lalu isi jumlah stok fisik hasil hitung.', 'error');
            redirect('adjustment_form.php' . ($did ? '?id=' . $did : ''));
        }

        $me = current_user();
        try {
            $did = db_tx(function () use ($did, $docDate, $reason, $note, $pids, $afters, $me) {
                if ($did > 0) {
                    $doc = db_one('SELECT * FROM adjustments WHERE id = ?', [$did]);
                    if (!$doc) throw new RuntimeException('Dokumen tidak ditemukan.');
                    if ($doc['status'] !== 'draft') throw new RuntimeException('Dokumen yang sudah diposting/void tidak bisa diubah.');
                    db_run('UPDATE adjustments SET doc_date=?, reason=?, note=? WHERE id=?', [$docDate, $reason, $note, $did]);
                } else {
                    $docNo = next_doc_no('adjustment', 'ADJ', $docDate);
                    db_run(
                        'INSERT INTO adjustments (doc_no, doc_date, reason, note, status, created_by, created_at) VALUES (?,?,?,?,?,?,?)',
                        [$docNo, $docDate, $reason, $note, 'draft', (int)$me['id'], now()]
                    );
                    $did = (int)db()->lastInsertId();
                }
                save_adjustment_items($did, $pids, $afters);
                recalc_doc_totals('adjustment', $did);
                return $did;
            });
        } catch (Throwable $ex) {
            flash('Gagal menyimpan: ' . e($ex->getMessage()), 'error');
            redirect('adjustment_form.php' . ($did ? '?id=' . $did : ''));
        }

        $docNo = (string)db_scalar('SELECT doc_no FROM adjustments WHERE id = ?', [$did]);
        log_activity('save', 'Simpan penyesuaian stok ' . $docNo . ' (' . $reason . ')', 'adjustment', $docNo);

        if ($op === 'save_post') {
            $res = post_document('adjustment', $did);
            if ($res['ok']) {
                flash('Dokumen <strong>' . e($docNo) . '</strong> berhasil disimpan dan diposting. Stok sudah diperbarui.');
                redirect('adjustment_form.php?id=' . $did);
            }
            flash('Dokumen tersimpan sebagai draft, tetapi gagal posting: ' . e(implode(' ', $res['errors'])), 'warn');
            redirect('adjustment_form.php?id=' . $did);
        }
        flash('Dokumen <strong>' . e($docNo) . '</strong> disimpan sebagai draft. Stok belum berubah sampai diposting.');
        redirect('adjustments.php');
    }
}

$doc = null;
$items = [];
if ($id > 0) {
    $doc = db_one('SELECT a.*, u.name AS created_name FROM adjustments a LEFT JOIN users u ON u.id = a.created_by WHERE a.id = ?', [$id]);
    if (!$doc) {
        flash('Dokumen tidak ditemukan.', 'error');
        redirect('adjustments.php');
    }
    $items = doc_items('adjustment', $id);
}
$readonly = $doc && $doc['status'] !== 'draft';
$canEdit = can('inv.adjust') && (!$doc || $doc['status'] === 'draft');
$backUrl = $doc ? ('adjustments.php?q=' . urlencode((string)$doc['doc_no'])) : 'adjustments.php';

page_start($doc ? ('Penyesuaian Stok ' . $doc['doc_no']) : 'Penyesuaian Stok Baru', 'adjustments');
?>
<div class="grid" style="gap:16px">
  <div class="stepline">
    <a class="btn btn-sm" href="<?= e($backUrl) ?>"><?= icon('arrow-left') ?> Kembali ke daftar</a>
    <?php if ($doc): ?>
      <?= status_badge((string)$doc['status']) ?>
      <span class="muted">Dibuat oleh <?= e($doc['created_name'] ?? '-') ?> pada <?= e(fmt_dt($doc['created_at'])) ?></span>
      <?php if (!empty($doc['posted_at'])): ?>
        <span class="badge badge-info">Diposting <?= e(fmt_dt($doc['posted_at'])) ?></span>
      <?php endif; ?>
      <?php if ($doc['status'] === 'void'): ?>
        <span class="badge badge-danger">Void: <?= e($doc['void_reason']) ?><?= !empty($doc['voided_at']) ? ' — ' . e(fmt_dt($doc['voided_at'])) : '' ?></span>
      <?php endif; ?>
      <button class="btn btn-sm no-print" data-print><?= icon('print') ?> Cetak</button>
    <?php endif; ?>
  </div>
</div>

<section class="card">
  <?php card_start(
      $doc ? ('Dokumen ' . $doc['doc_no']) : 'Buat Penyesuaian Stok',
      $readonly ? 'Dokumen ini sudah final dan hanya bisa dibaca.' : 'Masukkan jumlah stok fisik hasil hitung. Sistem akan mencatat selisihnya.'
  ); ?>
  <form method="post" id="adjForm">
    <?= csrf_field() ?>
    <input type="hidden" name="op" value="save">
    <input type="hidden" name="id" value="<?= (int)($doc['id'] ?? 0) ?>">
    <div class="form-grid">
      <div><label>No. Dokumen</label><input type="text" value="<?= e($doc['doc_no'] ?? 'otomatis saat disimpan') ?>" readonly></div>
      <div><label>Tanggal</label><input type="date" name="doc_date" value="<?= e($doc['doc_date'] ?? today()) ?>" <?= $canEdit ? '' : 'readonly' ?>></div>
      <div><label>Alasan Penyesuaian</label>
        <select name="reason" <?= $canEdit ? '' : 'disabled' ?>>
          <?php foreach (ADJ_REASONS as $rc): ?>
            <option value="<?= e($rc) ?>" <?= ($doc['reason'] ?? '') === $rc ? 'selected' : '' ?>><?= e($rc) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field-full"><label>Catatan</label><input type="text" name="note" value="<?= e($doc['note'] ?? '') ?>" <?= $canEdit ? '' : 'readonly' ?> placeholder="contoh: hasil cek rak gudang depan"></div>
    </div>

    <div class="divider"></div>

    <?php if ($canEdit): ?>
    <?php sku_scan_tools([
        'mode' => 'count_rows',
        'canCreate' => can('master.edit'),
        'brands' => $brands,
        'focusField' => '[name="item_after[]"]',
        'body' => 'adjBody',
        'tpl' => 'adjTpl',
        'table' => 'adjTable',
        'csrf' => csrf_token(),
        'hint' => 'Scan barcode/QR atau ketik SKU lalu Enter — baris muncul dengan stok sistem terisi otomatis. Ketik jumlah fisik hasil hitung, lalu Enter untuk kembali ke kolom scan.',
    ]); ?>
    <div class="table-wrap">
      <table id="adjTable" data-items>
        <thead><tr><th style="min-width:220px">SKU</th><th class="num">Stok Sistem</th><th class="num">Stok Fisik (baru)</th><th class="num">Selisih</th><th></th></tr></thead>
        <tbody id="adjBody">
        <?php if ($items): ?>
          <?php foreach ($items as $it): ?>
            <tr data-sku="<?= e($it['sku']) ?>" data-stock="<?= (float)$it['qty_before'] ?>" data-unit="<?= e($it['unit']) ?>">
              <td>
                <input class="sku-input" type="text" data-sku-input name="item_sku[]" value="<?= e($it['sku']) ?>" placeholder="scan / ketik SKU" autocomplete="off" spellcheck="false" autocapitalize="characters">
                <div class="sku-hint small muted"></div>
              </td>
              <td class="num sys-stock"><?= fmt_qty($it['qty_before']) ?> <span class="muted"><?= e($it['unit']) ?></span></td>
              <td><input class="qty-input count-field" type="text" name="item_after[]" value="<?= e(fmt_qty($it['qty_after'])) ?>" oninput="adjRecalc()"></td>
              <td class="num delta-cell"><?= fmt_qty($it['delta']) ?></td>
              <td><button class="btn btn-sm" type="button" onclick="this.closest('tr').remove();adjRecalc()">Hapus</button></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
        <tfoot>
          <tr class="totals-row"><td colspan="3" class="right">Total selisih</td><td class="num" id="adjTotal">0</td><td></td></tr>
        </tfoot>
      </table>
    </div>
    <template id="adjTpl">
      <td>
        <input class="sku-input" type="text" data-sku-input name="item_sku[]" placeholder="scan / ketik SKU" autocomplete="off" spellcheck="false" autocapitalize="characters">
        <div class="sku-hint small muted"></div>
      </td>
      <td class="num sys-stock">-</td>
      <td><input class="qty-input count-field" type="text" name="item_after[]" placeholder="0" oninput="adjRecalc()"></td>
      <td class="num delta-cell">-</td>
      <td><button class="btn btn-sm" type="button" onclick="this.closest('tr').remove();adjRecalc()">Hapus</button></td>
    </template>
    <div class="form-actions">
      <button class="btn" type="button" onclick="addAdjRow()"><?= icon('plus') ?> Tambah Baris</button>
      <div style="flex:1"></div>
      <button class="btn" type="submit">Simpan sebagai Draft</button>
      <button class="btn btn-primary" type="button" onclick="submitPost()">Simpan &amp; Posting (stok langsung berubah)</button>
    </div>
    <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead><tr><th>SKU</th><th>Satuan</th><th class="num">Stok Sistem</th><th class="num">Stok Fisik</th><th class="num">Selisih</th></tr></thead>
          <tbody>
          <?php if (!$items): ?><tr><td colspan="5"><?= empty_state('Dokumen ini belum memiliki item.') ?></td></tr><?php endif; ?>
          <?php $tot = 0; foreach ($items as $it): $tot += (float)$it['delta']; ?>
            <tr>
              <td class="mono"><?= e($it['sku']) ?></td>
              <td><?= e($it['unit']) ?></td>
              <td class="num"><?= fmt_qty($it['qty_before']) ?></td>
              <td class="num"><?= fmt_qty($it['qty_after']) ?></td>
              <td class="num" style="color:<?= (float)$it['delta'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ((float)$it['delta'] >= 0 ? '+' : '') . fmt_qty($it['delta']) ?></td>
            </tr>
          <?php endforeach; ?>
          <tr class="totals-row"><td colspan="4" class="right">Total selisih</td><td class="num"><?= fmt_qty($tot) ?></td></tr>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </form>
  <?php card_end(); ?>
</section>

<?php if ($doc && $doc['status'] === 'posted'): ?>
<section class="card">
  <?php card_start('Pergerakan Stok dari Dokumen Ini', 'Baris pembatalan muncul bila dokumen di-void.'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal</th><th>SKU</th><th class="num">Perubahan</th><th class="num">Saldo Stok</th><th>Catatan</th></tr></thead>
        <tbody>
        <?php foreach (doc_ledger_rows('adjustment', (int)$doc['id']) as $l): ?>
          <tr>
            <td><?= e(fmt_date($l['move_date'])) ?></td>
            <td class="mono"><?= e($l['sku']) ?></td>
            <td class="num" style="color:<?= (float)$l['qty_change'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ((float)$l['qty_change'] >= 0 ? '+' : '') . fmt_qty($l['qty_change']) ?></td>
            <td class="num"><?= fmt_qty($l['qty_after']) ?></td>
            <td class="small"><?= e($l['note'] ?: doc_label((string)$l['ref_type'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<?php if ($doc && $doc['status'] === 'posted' && is_admin()): ?>
<section class="card">
  <?php card_start('Void Dokumen', 'Void membalik seluruh pergerakan stok dokumen ini dan mencatat alasannya.'); ?>
    <form method="post" data-need-reason data-confirm="<?= e(void_confirm_text('adjustment', (int)$doc['id'], (string)$doc['doc_no'])) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="op" value="void"><input type="hidden" name="id" value="<?= (int)$doc['id'] ?>">
      <input type="text" name="void_reason" placeholder="alasan void (wajib)" required>
      <div class="form-actions"><button class="btn btn-danger" type="submit"><?= icon('ban') ?> Void Dokumen</button></div>
    </form>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<script src="<?= e(asset_url('assets/sku.js')) ?>"></script>
<script>
function adjRecalc() {
  var body = document.getElementById('adjBody');
  if (!body) return;
  var total = 0;
  Array.prototype.forEach.call(body.querySelectorAll('tr'), function (tr) {
    var input = tr.querySelector('input[name="item_after[]"]');
    var sysCell = tr.querySelector('.sys-stock');
    var deltaCell = tr.querySelector('.delta-cell');
    var hint = tr.querySelector('.sku-hint');
    var haveRaw = tr.getAttribute('data-stock');
    var have = haveRaw === null || haveRaw === '' ? null : parseFloat(haveRaw);
    var unit = tr.getAttribute('data-unit') || '';
    if (have !== null && sysCell) sysCell.textContent = fmtNum(have) + (unit ? ' ' + unit : '');
    var raw = input ? input.value.trim() : '';
    var after = raw === '' ? null : parseFloat(raw.replace(/\./g, '').replace(',', '.'));
    if (after !== null && isNaN(after)) after = null;
    if (after !== null && have !== null) {
      var d = after - have;
      total += d;
      if (deltaCell) {
        deltaCell.textContent = (d > 0 ? '+' : '') + fmtNum(d);
        deltaCell.style.color = d > 0 ? 'var(--ok)' : (d < 0 ? 'var(--danger)' : 'inherit');
      }
      if (hint && !tr.classList.contains('row-ok')) hint.textContent = 'stok sistem saat ini: ' + fmtNum(have);
    } else if (deltaCell) {
      deltaCell.textContent = '-';
    }
  });
  var t = document.getElementById('adjTotal');
  if (t) t.textContent = (total > 0 ? '+' : '') + fmtNum(total);
}
window.adjRecalc = adjRecalc;
function addAdjRow() { itemRows.add({ bodyId: 'adjBody', tplId: 'adjTpl' }); adjRecalc(); }
function submitPost() {
  var f = document.getElementById('adjForm');
  f.querySelector('input[name=op]').value = 'save_post';
  f.submit();
}
document.addEventListener('DOMContentLoaded', adjRecalc);
</script>
<?php page_end(); ?>
