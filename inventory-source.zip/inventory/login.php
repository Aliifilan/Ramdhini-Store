<?php
require_once __DIR__ . '/includes/init.php';

if (current_user()) redirect('index.php');

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $u = (string)post('username');
    $p = (string)post('password');
    if (do_login($u, $p)) {
        log_activity('login', 'Login berhasil');
        flash('Selamat datang, <strong>' . e((string)(current_user()['name'] ?? '')) . '</strong>.');
        redirect('index.php');
    }
    $err = 'Username atau password salah, atau akun Anda dinonaktifkan.';
}
?><!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Masuk &middot; <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= e(asset_url('assets/app.css')) ?>">
<style>
  .login-wrap{min-height:100vh;display:grid;place-items:center;padding:24px}
  .login-card{width:100%;max-width:400px;padding:30px 28px}
  .login-brand{display:flex;align-items:center;gap:12px;margin-bottom:22px}
  .login-mark{width:46px;height:46px;border-radius:14px;display:grid;place-items:center;color:#fff;background:linear-gradient(135deg,var(--indigo),var(--violet));box-shadow:0 10px 24px -10px rgba(79,70,229,.8)}
  .login-mark svg{width:24px;height:24px}
  .login-brand strong{display:block;font-size:17px}
  .login-brand small{color:var(--muted);font-size:12px}
  .login-card .btn{width:100%;justify-content:center;margin-top:6px}
  .login-note{margin-top:18px;font-size:12px;color:var(--ink-2);text-align:center}
</style>
</head>
<body>
<div class="login-wrap">
  <div class="card login-card">
    <div class="login-brand">
      <span class="login-mark"><?= icon('box') ?></span>
      <span>
        <strong><?= e(APP_NAME) ?></strong>
        <small><?= e(APP_OWNER) ?> &middot; Sistem Inventory</small>
      </span>
    </div>
    <?php if ($err): ?>
      <div class="alert alert-error" style="margin-bottom:16px"><?= e($err) ?></div>
    <?php endif; ?>
    <form method="post" autocomplete="off">
      <?= csrf_field() ?>
      <div style="margin-bottom:14px">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" required autofocus>
      </div>
      <div style="margin-bottom:10px">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
      </div>
      <button class="btn btn-primary" type="submit">Masuk</button>
    </form>
    <p class="login-note">Gunakan akun yang diberikan Admin aplikasi. Lupa password? Minta Admin mereset dari menu Pengguna.</p>
  </div>
</div>
</body>
</html>
