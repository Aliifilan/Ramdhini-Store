<?php
/* Berkas ini ditulis otomatis oleh androidapp/build.sh — jangan diubah manual. */
return [
    'version' => '1.0',
    'version_code' => '1',
    'file' => 'inventori-ramdhini-store.apk',
    'size' => 38451,
    'sha256' => 'da7bcd981b3511b9210d9154f94b92ba3906196883afd05ad7b0fcd300ed0042',
    'built' => '2026-10-14 02:05',
];
