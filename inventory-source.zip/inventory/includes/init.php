<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/xlsx.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/fifo.php';
require_once __DIR__ . '/docs.php';
require_once __DIR__ . '/apk.php';
require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/report_mail.php';
require_once __DIR__ . '/reports.php';
require_once __DIR__ . '/exporter.php';
require_once __DIR__ . '/importer.php';
require_once __DIR__ . '/layout.php';

session_boot();
db();
ensure_schema();

if (PHP_SAPI !== 'cli') {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    /* Halaman HTML tidak boleh disimpan browser/WebView: kalau halaman lama yang
       dipakai, tautan aset & skrip di dalamnya juga versi lama (fitur baru tampak
       "tidak jalan" padahal server sudah benar). Aset statis tetap versi-cache sendiri
       lewat asset_url(). */
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');

    /* Server ini tidak punya penjadwal, jadi laporan email diperiksa/dikirim saat
       aplikasi dibuka. Dijalankan SETELAH halaman dikirim ke pengguna supaya tidak
       memperlambat tampilan; kalau server tidak mendukung, tetap jalan di akhir request. */
    register_shutdown_function(static function () {
        try {
            if (!current_user()) return;            // hanya untuk pengguna yang sudah masuk
            if (function_exists('fastcgi_finish_request')) { @fastcgi_finish_request(); }
            report_auto_check();
        } catch (Throwable $e) {
            // kegagalan pengiriman laporan tidak boleh mengganggu aplikasi
        }
    });
}
