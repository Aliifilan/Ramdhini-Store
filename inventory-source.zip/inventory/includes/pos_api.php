<?php
declare(strict_types=1);

/* ============================================================
 * POS (Kasir) — dokumen penjualan yang berasal dari aplikasi Kasir.
 *
 * Aplikasi Kasir (folder `kasir/`) memuat berkas ini LANGSUNG (in-process),
 * jadi penjualan di kasir memakai jalur yang sama persis dengan aplikasi
 * Inventory: products.stock_qty, kartu stok (ledger), dan FIFO/HPP.
 * Tidak ada HTTP, tidak ada endpoint terbuka, tidak ada penulisan langsung
 * ke kolom stok dari luar.
 *
 * Aturan penting:
 *  - Penjualan kasir dibuat sebagai dokumen Barang Keluar biasa (channel = POS),
 *    sehingga ikut muncul di laporan/stok aplikasi Inventory tanpa perubahan lain.
 *  - Stok BOLEH menjadi minus di sini: barang sudah benar-benar keluar dari toko.
 *    Kalau stok di sistem tidak cukup (sinkronisasi tertinggal), penjualan tetap
 *    dicatat dan selisihnya dikembalikan sebagai `warnings` supaya terlihat.
 *  - Semua operasi idempoten berdasarkan `pos_uuid` (uuid dari perangkat kasir),
 *    karena perangkat bisa mengirim ulang operasi yang sama saat sinkronisasi.
 * ============================================================ */

const POS_CHANNEL   = 'POS';
const POS_DEST      = 'Penjualan Kasir (POS)';
const POS_COUNTER_K = 'pos';

/** Kolom penanda POS. Dibuat sekalian di sini supaya aplikasi Kasir tetap jalan
 *  walau aplikasi Inventory belum pernah dibuka setelah pemasangan (migrasi). */
function pos_ensure_columns(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    ensure_column(db(), 'outbounds', 'pos_uuid', "TEXT DEFAULT ''");
    ensure_column(db(), 'returns', 'pos_uuid', "TEXT DEFAULT ''");
}

/**
 * Daftar produk untuk cache perangkat kasir (harga jual, stok, identitas SKU).
 * Bentuknya sengaja ringkas supaya ringan dikirim/di-cache (443 SKU ≈ 60 KB).
 */
function pos_catalog(): array
{
    $brands = [];
    foreach (db_all('SELECT id, name FROM brands') as $b) {
        $brands[(int)$b['id']] = (string)$b['name'];
    }
    $out = [];
    $rows = db_all(
        'SELECT id, sku, brand_id, category, size, unit, sell_price, cost_price, min_stock, stock_qty, active, updated_at
           FROM products ORDER BY sku'
    );
    foreach ($rows as $p) {
        $out[] = [
            'id' => (int)$p['id'],
            'sku' => (string)$p['sku'],
            'brand' => $brands[(int)$p['brand_id']] ?? '',
            'category' => (string)($p['category'] ?? ''),
            'size' => (string)($p['size'] ?? ''),
            'unit' => (string)($p['unit'] ?? 'pcs'),
            'price' => (float)$p['sell_price'],
            'cost' => (float)$p['cost_price'],
            'min_stock' => (float)$p['min_stock'],
            'stock' => (float)$p['stock_qty'],
            'active' => (int)$p['active'],
            'updated' => (string)($p['updated_at'] ?? ''),
        ];
    }
    return $out;
}

/** Stok terkini beberapa SKU (dipakai kasir menyegarkan sisa stok setelah penjualan). */
function pos_stock_by_sku(array $skus): array
{
    $out = [];
    foreach (array_slice(array_values(array_unique(array_filter(array_map('strval', $skus)))), 0, 500) as $sku) {
        $r = db_one('SELECT id, sku, stock_qty, sell_price, active FROM products WHERE sku = ?', [strtoupper(trim($sku))]);
        if ($r) {
            $out[strtoupper((string)$r['sku'])] = [
                'id' => (int)$r['id'],
                'stock' => (float)$r['stock_qty'],
                'price' => (float)$r['sell_price'],
                'active' => (int)$r['active'],
            ];
        }
    }
    return $out;
}

function pos_normalize_date($v): string
{
    $s = trim((string)$v);
    if (preg_match('/^\d{4}-\d{2}-\d{2}/', $s)) return substr($s, 0, 10);
    return today();
}

/**
 * Simpan penjualan kasir sebagai dokumen Barang Keluar + pergerakan stok.
 *
 * @param array $sale {
 *   uuid, doc_date, local_no, cashier_name, member_name, note,
 *   items: [ { product_id|sku, qty, price, discount } ], total
 * }
 * @return array{ok:bool,errors:string[],doc_no:string,warnings:string[],already?:bool}
 */
function pos_post_sale(array $sale, ?int $userId = null): array
{
    pos_ensure_columns();
    $uuid = trim((string)($sale['uuid'] ?? ''));
    try {
        return db_tx(function () use ($sale, $userId, $uuid) {
            if ($uuid !== '') {
                $ex = db_one('SELECT id, doc_no FROM outbounds WHERE channel = ? AND pos_uuid = ?', [POS_CHANNEL, $uuid]);
                if ($ex) {
                    return ['ok' => true, 'errors' => [], 'doc_no' => (string)$ex['doc_no'], 'warnings' => [], 'already' => true];
                }
            }

            $date = pos_normalize_date($sale['doc_date'] ?? '');
            $localNo = trim((string)($sale['local_no'] ?? ''));
            $cashier = trim((string)($sale['cashier_name'] ?? ''));
            $member = trim((string)($sale['member_name'] ?? ''));

            /* Baris disusun dari product_id (dikirim perangkat) atau dari SKU. */
            $rows = [];
            foreach ((array)($sale['items'] ?? []) as $it) {
                $pid = (int)($it['product_id'] ?? 0);
                $p = null;
                if ($pid > 0) {
                    $p = db_one('SELECT id, sku FROM products WHERE id = ?', [$pid]);
                }
                if (!$p && !empty($it['sku'])) {
                    $p = product_by_sku((string)$it['sku']);
                }
                if (!$p) {
                    throw new RuntimeException('SKU tidak dikenal: ' . (string)($it['sku'] ?? ('#' . $pid)));
                }
                $qty = (float)($it['qty'] ?? 0);
                if ($qty <= 0) continue;
                $price = (float)($it['price'] ?? 0);
                $disc = (float)($it['discount'] ?? 0);
                $line = (float)($it['line_total'] ?? 0);
                if ($line <= 0) $line = max(0.0, $qty * $price - $disc);
                $rows[] = [
                    'pid' => (int)$p['id'],
                    'sku' => (string)$p['sku'],
                    'qty' => $qty,
                    'unit' => $qty > 0 ? round($line / $qty, 4) : 0.0,
                    'subtotal' => round($line, 2),
                ];
            }
            if (!$rows) throw new RuntimeException('Tidak ada baris barang pada penjualan ini.');

            $docNo = next_doc_no(POS_COUNTER_K, 'POS', $date);
            $note = 'Kasir ' . ($localNo !== '' ? $localNo : $uuid);
            if ($cashier !== '') $note .= ' • ' . $cashier;
            if ($member !== '') $note .= ' • Member: ' . $member;
            if (!empty($sale['note'])) $note .= ' • ' . trim((string)$sale['note']);

            $totalQty = 0.0;
            $totalAmount = 0.0;
            foreach ($rows as $r) { $totalQty += $r['qty']; $totalAmount += $r['subtotal']; }

            db_run(
                'INSERT INTO outbounds (doc_no, doc_date, destination, channel, note, status, total_qty, total_amount, created_by, created_at, pos_uuid)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                [$docNo, $date, POS_DEST, POS_CHANNEL, $note, 'draft', $totalQty, $totalAmount, $userId, now(), $uuid]
            );
            $docId = (int)db()->lastInsertId();
            foreach ($rows as $r) {
                db_run(
                    'INSERT INTO outbound_items (outbound_id, product_id, qty, unit_price, subtotal, cogs, cogs_unit, note)
                     VALUES (?,?,?,?,?,0,0,?)',
                    [$docId, $r['pid'], $r['qty'], $r['unit'], $r['subtotal'], $localNo]
                );
            }
            recalc_doc_totals('outbound', $docId);

            /* Pergerakan stok. Stok boleh minus (lihat catatan di kepala berkas). */
            $warnings = [];
            $touched = [];
            foreach ($rows as $r) {
                $after = apply_move(
                    $r['pid'],
                    -$r['qty'],
                    $date,
                    'outbound',
                    $docId,
                    $docNo,
                    'Penjualan kasir ' . $localNo,
                    $userId,
                    (float)$r['unit']
                );
                $touched[] = $r['pid'];
                if ($after < -0.0000001) {
                    $warnings[] = $r['sku'] . ' (stok menjadi ' . fmt_qty($after) . ')';
                }
            }

            db_run("UPDATE outbounds SET status = 'posted', posted_by = ?, posted_at = ? WHERE id = ?", [$userId, now(), $docId]);
            fifo_rebuild(array_values(array_unique($touched)), true);
            log_activity('pos_sale', 'Penjualan kasir ' . ($localNo !== '' ? $localNo : $uuid) . ' → ' . $docNo, 'outbound', $docNo);

            return [
                'ok' => true,
                'errors' => [],
                'doc_no' => $docNo,
                'warnings' => $warnings,
                'already' => false,
            ];
        });
    } catch (Throwable $ex) {
        return ['ok' => false, 'errors' => [$ex->getMessage()], 'doc_no' => '', 'warnings' => []];
    }
}

/**
 * Batalkan dokumen penjualan kasir (void).
 * Stok dikembalikan lewat void_document() aplikasi Inventory, jadi kartu stok &
 * FIFO/HPP ikut kembali seperti sebelum penjualan itu ada.
 */
function pos_void_sale(string $docNo, string $reason, ?int $userId = null): array
{
    pos_ensure_columns();
    $docNo = trim($docNo);
    if ($docNo === '') return ['ok' => false, 'errors' => ['Nomor dokumen kosong.']];
    $doc = db_one('SELECT id, status, doc_no FROM outbounds WHERE doc_no = ? AND channel = ?', [$docNo, POS_CHANNEL]);
    if (!$doc) return ['ok' => false, 'errors' => ['Dokumen penjualan ' . $docNo . ' tidak ditemukan di Inventory.']];
    if ((string)$doc['status'] === 'void') {
        return ['ok' => true, 'errors' => [], 'doc_no' => $docNo, 'already' => true, 'warning' => ''];
    }
    $res = void_document('outbound', (int)$doc['id'], $reason === '' ? 'Pembatalan dari kasir' : $reason);
    return $res;
}

/** Cari dokumen penjualan kasir berdasarkan uuid perangkat. */
function pos_find_sale(string $uuid): ?array
{
    pos_ensure_columns();
    $r = db_one('SELECT id, doc_no, status FROM outbounds WHERE channel = ? AND pos_uuid = ?', [POS_CHANNEL, trim($uuid)]);
    return $r ?: null;
}

/**
 * Retur dari customer: dokumen Barang Keluar dibalik → stok masuk lagi dengan
 * aturan FIFO aplikasi Inventory (rata-rata berjalan), bukan harga jual.
 */
function pos_post_return(array $ret, ?int $userId = null): array
{
    pos_ensure_columns();
    $uuid = trim((string)($ret['uuid'] ?? ''));
    try {
        return db_tx(function () use ($ret, $userId, $uuid) {
            if ($uuid !== '') {
                $ex = db_one('SELECT id, doc_no FROM returns WHERE pos_uuid = ?', [$uuid]);
                if ($ex) return ['ok' => true, 'errors' => [], 'doc_no' => (string)$ex['doc_no'], 'already' => true];
            }
            $date = pos_normalize_date($ret['doc_date'] ?? '');
            $rows = [];
            foreach ((array)($ret['items'] ?? []) as $it) {
                $pid = (int)($it['product_id'] ?? 0);
                $p = $pid > 0 ? db_one('SELECT id, sku, unit FROM products WHERE id = ?', [$pid]) : null;
                if (!$p && !empty($it['sku'])) $p = product_by_sku((string)$it['sku']);
                if (!$p) throw new RuntimeException('SKU tidak dikenal pada retur: ' . (string)($it['sku'] ?? ('#' . $pid)));
                $qty = (float)($it['qty'] ?? 0);
                if ($qty <= 0) continue;
                $price = (float)($it['price'] ?? 0);
                $rows[] = ['pid' => (int)$p['id'], 'qty' => $qty, 'price' => $price];
            }
            if (!$rows) throw new RuntimeException('Tidak ada baris barang pada retur ini.');

            $docNo = next_doc_no('return', 'RTB', $date);
            $party = trim((string)($ret['party'] ?? '')) ?: 'Customer kasir';
            $note = 'Retur kasir';
            if (!empty($ret['local_no'])) $note .= ' ' . trim((string)$ret['local_no']);
            if (!empty($ret['ref_doc_no'])) $note .= ' • dari ' . trim((string)$ret['ref_doc_no']);
            if (!empty($ret['note'])) $note .= ' • ' . trim((string)$ret['note']);

            $totalQty = 0.0; $totalAmount = 0.0;
            foreach ($rows as $r) { $totalQty += $r['qty']; $totalAmount += $r['qty'] * $r['price']; }

            db_run(
                'INSERT INTO returns (doc_no, doc_date, type, party, ref_doc_no, note, status, total_qty, total_amount, created_by, created_at, pos_uuid)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
                [$docNo, $date, 'customer', $party, (string)($ret['ref_doc_no'] ?? ''), $note, 'draft', $totalQty, $totalAmount, $userId, now(), $uuid]
            );
            $id = (int)db()->lastInsertId();
            foreach ($rows as $r) {
                db_run(
                    'INSERT INTO return_items (return_id, product_id, qty, unit_price, subtotal, note) VALUES (?,?,?,?,?,?)',
                    [$id, $r['pid'], $r['qty'], $r['price'], $r['qty'] * $r['price'], '']
                );
            }

            $res = post_document('return', $id);
            if (empty($res['ok'])) throw new RuntimeException(implode('; ', (array)($res['errors'] ?? ['gagal posting retur'])));
            return ['ok' => true, 'errors' => [], 'doc_no' => $docNo, 'already' => false];
        });
    } catch (Throwable $ex) {
        return ['ok' => false, 'errors' => [$ex->getMessage()], 'doc_no' => '', 'warnings' => []];
    }
}

/**
 * Ubah harga jual sebuah SKU dari aplikasi Kasir (harga di kasir = harga label).
 * Hanya harga JUAL yang diubah; HPP tetap urusan FIFO/barang masuk.
 */
function pos_set_price(int $productId, float $price, ?int $userId = null): array
{
    $p = db_one('SELECT id, sku, sell_price FROM products WHERE id = ?', [$productId]);
    if (!$p) return ['ok' => false, 'error' => 'Produk tidak ditemukan.'];
    $price = max(0.0, round($price, 2));
    db_tx(function () use ($p, $price, $userId) {
        db_run('UPDATE products SET sell_price = ?, updated_at = ? WHERE id = ?', [$price, now(), (int)$p['id']]);
        log_activity('pos_price', 'Harga jual ' . $p['sku'] . ' diubah kasir: ' . fmt_money($p['sell_price']) . ' → ' . fmt_money($price), 'product', (string)$p['sku']);
    });
    return ['ok' => true, 'product_id' => (int)$p['id'], 'sku' => (string)$p['sku'], 'price' => $price];
}

/** Harga jual beberapa SKU sekaligus (impor daftar harga dari kasir). */
function pos_set_prices(array $pairs, ?int $userId = null): array
{
    $ok = 0; $fail = [];
    foreach ($pairs as $pair) {
        $r = pos_set_price((int)($pair['product_id'] ?? 0), (float)($pair['price'] ?? 0), $userId);
        if (!empty($r['ok'])) $ok++; else $fail[] = (string)($pair['sku'] ?? $pair['product_id']) . ': ' . (string)$r['error'];
    }
    return ['ok' => true, 'updated' => $ok, 'errors' => $fail];
}
