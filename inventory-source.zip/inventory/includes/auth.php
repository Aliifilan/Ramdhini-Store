<?php
declare(strict_types=1);

const ROLES = [
    'admin'  => 'Admin',
    'staff'  => 'Staf Gudang',
    'viewer' => 'Viewer',
];

const ROLE_PERMS = [
    'admin' => ['*'],
    'staff' => [
        'master.view', 'master.edit',
        'inv.view', 'inv.adjust', 'inv.opname',
        'tx.view', 'tx.create', 'tx.edit', 'tx.edit_posted',
        'report.view', 'data.import', 'data.export',
    ],
    /* Permintaan pemilik toko: SEMUA user boleh mengoreksi dokumen yang sudah diposting
       (barang masuk & barang keluar). Hak ini terpisah dari 'tx.create' supaya bisa
       dicabut lagi tanpa mengubah kemampuan membuat dokumen baru. */
    'viewer' => ['master.view', 'inv.view', 'tx.view', 'tx.edit_posted', 'report.view', 'data.export'],
    /* catatan: 'settings.manage' (pengaturan laporan email) hanya dimiliki role admin lewat '*'. */
];

function session_boot(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    /* Pastikan folder penyimpanan sesi benar-benar ada & bisa ditulis.
       Pada sebagian server, session.save_path default (/var/lib/php/sessions)
       tidak ada sehingga sesi gagal dibuat dan login tidak bisa dipakai. */
    $savePath = (string)ini_get('session.save_path');
    if (str_contains($savePath, ';')) {
        $parts = explode(';', $savePath);
        $savePath = (string)end($parts);
    }
    if ($savePath === '' || !is_dir($savePath) || !is_writable($savePath)) {
        $alt = rtrim(sys_get_temp_dir(), '/\\') . '/inventori_sessions';
        if (!is_dir($alt)) { @mkdir($alt, 0700, true); }
        if (is_dir($alt) && is_writable($alt)) {
            @chmod($alt, 0700);
            session_save_path($alt);
        }
    }

    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => $https,
    ]);
    session_name('inv_sess');
    session_start();
}

function current_user(): ?array
{
    static $u = null;
    static $loaded = false;
    if ($loaded) return $u;
    $loaded = true;
    $id = $_SESSION['uid'] ?? null;
    if (!$id) return $u = null;
    $row = db_one('SELECT * FROM users WHERE id = ? AND active = 1', [(int)$id]);
    if (!$row) {
        unset($_SESSION['uid']);
        return $u = null;
    }
    return $u = $row;
}

function can(string $perm): bool
{
    $u = current_user();
    if (!$u) return false;
    $perms = ROLE_PERMS[$u['role']] ?? [];
    return in_array('*', $perms, true) || in_array($perm, $perms, true);
}

function is_admin(): bool
{
    $u = current_user();
    return $u && $u['role'] === 'admin';
}

function require_login(): void
{
    if (!current_user()) {
        redirect('login.php');
    }
}

function require_perm(string $perm): void
{
    require_login();
    if (!can($perm)) {
        http_response_code(403);
        include __DIR__ . '/../denied.php';
        exit;
    }
}

function do_login(string $username, string $password): bool
{
    $row = db_one('SELECT * FROM users WHERE username = ?', [$username]);
    if (!$row || (int)$row['active'] !== 1) return false;
    if (!password_verify($password, $row['password_hash'])) return false;
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$row['id'];
    return true;
}

function do_logout(): void
{
    $_SESSION = [];
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}

function log_activity(string $action, string $detail = '', string $refType = '', string $refNo = ''): void
{
    $u = current_user();
    if (!$u) return;
    db_run(
        'INSERT INTO activity_log (user_id, username, action, detail, ref_type, ref_no, created_at)
         VALUES (?,?,?,?,?,?,?)',
        [(int)$u['id'], (string)$u['username'], $action, $detail, $refType, $refNo, now()]
    );
}
