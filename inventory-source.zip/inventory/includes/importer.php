<?php
declare(strict_types=1);

/** Sinyal internal untuk membatalkan transaksi saat mode uji coba (dry-run). */
class DryRunSignal extends Exception
{
}

function import_datasets(): array
{
    return [
        'brands' => [
            'label' => 'Brand',
            'help' => 'Membuat/memperbarui brand berdasarkan kode. Kolom: code, name, description, active.',
        ],
        'suppliers' => [
            'label' => 'Supplier',
            'help' => 'Membuat/memperbarui supplier berdasarkan kode. Kolom: code, name, contact_person, phone, email, address, active.',
        ],
        'products' => [
            'label' => 'Produk Master',
            'help' => 'Membuat/memperbarui produk berdasarkan SKU. Brand yang belum ada otomatis dibuat; supplier diisi nanti saat barang masuk. Kolom: sku, brand_code, category, size, unit, cost_price, sell_price, min_stock, active. Kolom size diisi dari daftar ukuran resmi (XS–XXXXL, 27–44, All Size) — nilai lain diabaikan.',
        ],
        'opening' => [
            'label' => 'Stok Awal (opening balance)',
            'help' => 'Menetapkan stok awal produk beserta catatan kartu stok. Produk yang sudah punya mutasi stok akan dilewati agar tidak dobel. Kolom: sku, qty, cost_price, move_date, note.',
        ],
        'inbound' => [
            'label' => 'Barang Masuk (inbound)',
            'help' => 'Satu baris = satu item. Baris dengan doc_no sama digabung menjadi satu dokumen. Kolom: doc_no, doc_date, supplier_code, sku, qty, unit_cost, note, status, discount_type (persen/rupiah), discount_value. Diskon dibagi proporsional ke tiap SKU.',
        ],
        'outbound' => [
            'label' => 'Barang Keluar (outbound)',
            'help' => 'Satu baris = satu item, digabung per doc_no. Kolom: doc_no, doc_date, destination, channel, sku, qty, unit_price, note, status.',
        ],
        'returns' => [
            'label' => 'Retur',
            'help' => 'Satu baris = satu item, digabung per doc_no. Kolom: doc_no, doc_date, type (supplier/customer), party, ref_doc_no, sku, qty, price, note, status.',
        ],
    ];
}

function import_bool($v): int
{
    $s = strtolower(trim((string)$v));
    if ($s === '' ) return 1;
    if (in_array($s, ['1', 'y', 'ya', 'yes', 'true', 'aktif', 'active'], true)) return 1;
    return 0;
}

function import_find_or_create_brand(string $code, string $name = ''): ?int
{
    $code = strtoupper(trim($code));
    if ($code === '' && $name !== '') $code = strtoupper(preg_replace('/[^A-Za-z0-9]+/', '-', $name));
    if ($code === '') return null;
    $row = db_one('SELECT id FROM brands WHERE UPPER(code) = ?', [$code]);
    if ($row) return (int)$row['id'];
    db_run('INSERT INTO brands (code, name, description, active, created_at) VALUES (?,?,?,?,?)',
        [$code, $name !== '' ? $name : $code, '', 1, now()]);
    return (int)db()->lastInsertId();
}

/**
 * Buat atau perbarui supplier berdasarkan kode (tidak peka huruf besar/kecil).
 *
 * Satu fungsi dipakai bersama oleh impor supplier dan impor barang masuk supaya
 * daftar kolomnya tidak pernah berbeda antar pemanggil. (Dulu impor supplier punya
 * INSERT-nya sendiri dengan 8 tanda ? tetapi hanya 7 nilai — akibatnya nama supplier
 * tersimpan di kolom kode dan impor berikutnya gagal "UNIQUE constraint failed".)
 *
 * @param array $fields name, contact_person, phone, email, address, active (opsional)
 * @return array{id:int, created:bool}|null
 */
function import_upsert_supplier(string $code, array $fields = []): ?array
{
    $code = strtoupper(trim($code));
    $name = trim((string)($fields['name'] ?? ''));
    if ($code === '' && $name !== '') {
        $code = strtoupper((string)preg_replace('/[^A-Za-z0-9]+/', '-', $name));
    }
    if ($code === '') return null;

    $vals = [
        ($name !== '' ? $name : $code),
        (string)($fields['contact_person'] ?? ''),
        (string)($fields['phone'] ?? ''),
        (string)($fields['email'] ?? ''),
        (string)($fields['address'] ?? ''),
        isset($fields['active']) ? (int)(bool)$fields['active'] : 1,
    ];

    $row = db_one('SELECT id FROM suppliers WHERE UPPER(code) = ?', [$code]);
    if ($row) {
        db_run(
            'UPDATE suppliers SET name=?, contact_person=?, phone=?, email=?, address=?, active=? WHERE id=?',
            array_merge($vals, [(int)$row['id']])
        );
        return ['id' => (int)$row['id'], 'created' => false];
    }

    db_run(
        'INSERT INTO suppliers (code, name, contact_person, phone, email, address, active, created_at)
         VALUES (?,?,?,?,?,?,?,?)',
        array_merge([$code], $vals, [now()])
    );
    return ['id' => (int)db()->lastInsertId(), 'created' => true];
}

/** Cari / buat supplier, kembalikan id-nya (dipakai impor barang masuk). */
function import_find_or_create_supplier(string $code, string $name = ''): ?int
{
    $res = import_upsert_supplier($code, ['name' => $name]);
    return $res === null ? null : (int)$res['id'];
}

function import_product_id(string $sku): ?int
{
    $sku = strtoupper(trim($sku));
    if ($sku === '') return null;
    $row = db_one('SELECT id FROM products WHERE UPPER(sku) = ?', [$sku]);
    return $row ? (int)$row['id'] : null;
}

/**
 * @return array{created:int,updated:int,skipped:int,errors:array<int,string>,notes:array<int,string>,docs:array<int,string>}
 */
function run_import(string $ds, array $rows, bool $postDocs): array
{
    $res = ['created' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => [], 'notes' => [], 'docs' => []];
    $me = current_user();
    $uid = $me ? (int)$me['id'] : null;

    if ($ds === 'brands') {
        foreach ($rows as $i => $r) {
            $line = $i + 2;
            $code = strtoupper((string)($r['code'] ?? ''));
            $name = trim((string)($r['name'] ?? ''));
            if ($code === '' || $name === '') { $res['errors'][] = "Baris $line: kolom code dan name wajib diisi."; continue; }
            $ex = db_one('SELECT id FROM brands WHERE UPPER(code) = ?', [$code]);
            if ($ex) {
                db_run('UPDATE brands SET name=?, description=?, active=? WHERE id=?',
                    [$name, (string)($r['description'] ?? ''), import_bool($r['active'] ?? 1), (int)$ex['id']]);
                $res['updated']++;
                $res['notes'][] = "Baris $line: brand $code diperbarui.";
            } else {
                db_run('INSERT INTO brands (code, name, description, active, created_at) VALUES (?,?,?,?,?)',
                    [$code, $name, (string)($r['description'] ?? ''), import_bool($r['active'] ?? 1), now()]);
                $res['created']++;
            }
        }
        return $res;
    }

    if ($ds === 'suppliers') {
        foreach ($rows as $i => $r) {
            $line = $i + 2;
            $code = strtoupper((string)($r['code'] ?? ''));
            $name = trim((string)($r['name'] ?? ''));
            if ($code === '' || $name === '') { $res['errors'][] = "Baris $line: kolom code dan name wajib diisi."; continue; }
            $up = import_upsert_supplier($code, [
                'name' => $name,
                'contact_person' => (string)($r['contact_person'] ?? ''),
                'phone' => (string)($r['phone'] ?? ''),
                'email' => (string)($r['email'] ?? ''),
                'address' => (string)($r['address'] ?? ''),
                'active' => import_bool($r['active'] ?? 1),
            ]);
            if ($up === null) { $res['errors'][] = "Baris $line: kode supplier tidak bisa ditentukan."; continue; }
            if ($up['created']) {
                $res['created']++;
            } else {
                $res['updated']++;
                $res['notes'][] = "Baris $line: supplier $code diperbarui.";
            }
        }
        return $res;
    }

    if ($ds === 'products') {
        foreach ($rows as $i => $r) {
            $line = $i + 2;
            $sku = strtoupper(trim((string)($r['sku'] ?? '')));
            if ($sku === '') { $res['errors'][] = "Baris $line: kolom sku wajib diisi."; continue; }
            $brandId = import_find_or_create_brand((string)($r['brand_code'] ?? ''), (string)($r['brand_name'] ?? ''));
            $category = (string)($r['category'] ?? '');   // supplier tidak lagi bagian dari master produk
            $size = normalize_size($r['size'] ?? '');     // ukuran: hanya nilai dari daftar resmi yang diterima
            $unit = (string)($r['unit'] ?? 'pcs') ?: 'pcs';
            $cost = parse_num($r['cost_price'] ?? 0);
            $sell = parse_num($r['sell_price'] ?? 0);
            $minStock = parse_qty($r['min_stock'] ?? 0);
            $active = import_bool($r['active'] ?? 1);
            $ex = db_one('SELECT id FROM products WHERE UPPER(sku) = ?', [$sku]);
            if ($ex) {
                if (products_has_name_column()) {
                    db_run('UPDATE products SET name = sku WHERE id = ?', [(int)$ex['id']]);
                }
                db_run('UPDATE products SET brand_id=?, category=?, size=?, unit=?, cost_price=?, sell_price=?, min_stock=?, active=?, updated_at=? WHERE id=?',
                    [$brandId, $category, $size, $unit, $cost, $sell, $minStock, $active, now(), (int)$ex['id']]);
                $res['updated']++;
            } else {
                product_create($sku, $brandId, null, $category, $unit, $cost, $sell, $minStock, $active, $size);
                $res['created']++;
            }
        }
        return $res;
    }

    if ($ds === 'opening') {
        $openingProducts = [];
        foreach ($rows as $i => $r) {
            $line = $i + 2;
            $sku = (string)($r['sku'] ?? '');
            $pid = import_product_id($sku);
            if (!$pid) { $res['errors'][] = "Baris $line: SKU '" . $sku . "' tidak ditemukan (import Produk Master dulu)."; continue; }
            $qty = parse_qty($r['qty'] ?? 0);
            if ($qty == 0.0) { $res['skipped']++; continue; }
            $hasMove = (int)db_scalar('SELECT COUNT(*) FROM ledger WHERE product_id = ?', [$pid]);
            if ($hasMove > 0) {
                $res['skipped']++;
                $res['notes'][] = "Baris $line: produk " . strtoupper($sku) . " sudah punya riwayat mutasi — stok awal dilewati (agar tidak dobel). Pakai Stok Adjustment bila ingin mengubah stoknya.";
                continue;
            }
            $date = parse_date_flexible($r['move_date'] ?? '') ?? today();
            $cost = parse_num($r['cost_price'] ?? 0);
            if ($cost > 0) {
                db_run('UPDATE products SET cost_price = ? WHERE id = ?', [$cost, $pid]);
            }
            apply_move($pid, $qty, $date, 'opening', 0, 'OPENING', 'Stok awal: ' . (string)($r['note'] ?? ''), $uid, $cost);
            $openingProducts[] = $pid;
            $res['created']++;
        }
        if (!empty($openingProducts)) {
            /* stok awal membentuk lapisan FIFO tersendiri */
            fifo_rebuild(array_values(array_unique($openingProducts)));
        }
        return $res;
    }

    /* ---------- dokumen: inbound / outbound / returns ---------- */
    $groups = [];
    foreach ($rows as $i => $r) {
        $line = $i + 2;
        $docNo = trim((string)($r['doc_no'] ?? ''));
        if ($docNo === '') $docNo = '__auto_' . $line;
        $groups[$docNo]['rows'][] = ['line' => $line, 'data' => $r];
    }

    foreach ($groups as $docNo => $grp) {
        $first = $grp['rows'][0]['data'];
        $docDate = parse_date_flexible($first['doc_date'] ?? '') ?? today();
        $statusWanted = strtolower(trim((string)($first['status'] ?? '')));
        $autoPost = $postDocs && ($statusWanted === '' || in_array($statusWanted, ['posted', 'posting'], true));

        $table = $ds === 'inbound' ? 'inbounds' : ($ds === 'outbound' ? 'outbounds' : 'returns');
        if (!str_starts_with($docNo, '__auto_')) {
            $dup = db_one("SELECT id, status FROM $table WHERE doc_no = ?", [$docNo]);
            if ($dup) {
                $res['errors'][] = "Dokumen $docNo sudah ada di sistem (status: {$dup['status']}) — seluruh baris dokumen ini dilewati.";
                $res['skipped'] += count($grp['rows']);
                continue;
            }
        }

        $items = [];
        $head = [];
        foreach ($grp['rows'] as $rr) {
            $d = $rr['data'];
            $sku = (string)($d['sku'] ?? '');
            $pid = import_product_id($sku);
            if (!$pid) { $res['errors'][] = "Baris {$rr['line']}: SKU '" . $sku . "' tidak ditemukan — baris dilewati."; continue; }
            $qty = parse_qty($d['qty'] ?? 0);
            if ($qty <= 0) { $res['errors'][] = "Baris {$rr['line']}: qty harus lebih dari 0 — baris dilewati."; continue; }
            $price = parse_num($d['unit_cost'] ?? ($d['unit_price'] ?? ($d['price'] ?? 0)));
            $items[] = [$pid, $qty, $price];
            if (!$head) $head = $d;
        }
        if (!$items) {
            $res['errors'][] = "Dokumen $docNo tidak punya baris valid — dilewati.";
            continue;
        }

        /* diskon tingkat dokumen (opsional pada file import barang masuk) */
        $discType = strtolower(trim((string)($head['discount_type'] ?? '')));
        $discType = str_contains($discType, 'rp') || str_contains($discType, 'rupiah') || str_contains($discType, 'amount') ? 'amount' : 'percent';
        $discValue = parse_num($head['discount_value'] ?? 0);
        if ($discValue < 0) $discValue = 0;
        if ($discType === 'percent' && $discValue > 100) $discValue = 100;

        try {
            $docId = 0;
            db_tx(function () use ($ds, $docDate, $docNo, $head, $items, $uid, $discType, $discValue, &$docId) {
                if ($ds === 'inbound') {
                    $supplierId = import_find_or_create_supplier((string)($head['supplier_code'] ?? ''), (string)($head['supplier_name'] ?? ''));
                    $no = str_starts_with($docNo, '__auto_') ? next_doc_no('inbound', 'IN', $docDate) : $docNo;
                    db_run('INSERT INTO inbounds (doc_no, doc_date, supplier_id, note, status, discount_type, discount_value, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
                        [$no, $docDate, $supplierId, (string)($head['note'] ?? ''), 'draft', $discType, $discValue, $uid, now()]);
                    $docId = (int)db()->lastInsertId();
                    foreach ($items as [$pid, $qty, $price]) {
                        db_run('INSERT INTO inbound_items (inbound_id, product_id, qty, unit_cost, subtotal) VALUES (?,?,?,?,?)', [$docId, $pid, $qty, $price, $qty * $price]);
                    }
                    apply_inbound_discount($docId);
                } elseif ($ds === 'outbound') {
                    $no = str_starts_with($docNo, '__auto_') ? next_doc_no('outbound', 'OUT', $docDate) : $docNo;
                    db_run('INSERT INTO outbounds (doc_no, doc_date, destination, channel, note, status, created_by, created_at) VALUES (?,?,?,?,?,?,?,?)',
                        [$no, $docDate, (string)($head['destination'] ?? ''), (string)($head['channel'] ?? ''), (string)($head['note'] ?? ''), 'draft', $uid, now()]);
                    $docId = (int)db()->lastInsertId();
                    foreach ($items as [$pid, $qty, $price]) {
                        db_run('INSERT INTO outbound_items (outbound_id, product_id, qty, unit_price, subtotal) VALUES (?,?,?,?,?)', [$docId, $pid, $qty, $price, $qty * $price]);
                    }
                    recalc_doc_totals('outbound', $docId);
                } else {
                    $type = strtolower(trim((string)($head['type'] ?? 'supplier'))) === 'customer' ? 'customer' : 'supplier';
                    $no = str_starts_with($docNo, '__auto_') ? next_doc_no('return', 'RTB', $docDate) : $docNo;
                    db_run('INSERT INTO returns (doc_no, doc_date, type, party, ref_doc_no, note, status, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
                        [$no, $docDate, $type, (string)($head['party'] ?? ''), (string)($head['ref_doc_no'] ?? ''), (string)($head['note'] ?? ''), 'draft', $uid, now()]);
                    $docId = (int)db()->lastInsertId();
                    foreach ($items as [$pid, $qty, $price]) {
                        db_run('INSERT INTO return_items (return_id, product_id, qty, unit_price, subtotal) VALUES (?,?,?,?,?)', [$docId, $pid, $qty, $price, $qty * $price]);
                    }
                    recalc_doc_totals('return', $docId);
                }
                return $docId;
            });
        } catch (Throwable $ex) {
            $res['errors'][] = "Dokumen $docNo gagal disimpan: " . $ex->getMessage();
            continue;
        }

        $realNo = (string)db_scalar('SELECT doc_no FROM ' . $table . ' WHERE id = ?', [$docId]);
        $res['created']++;
        $res['docs'][] = $realNo;

        if ($autoPost) {
            $p = post_document($ds === 'returns' ? 'return' : $ds, $docId);
            if ($p['ok']) {
                $res['notes'][] = "Dokumen $realNo diposting — stok sudah disesuaikan.";
            } else {
                $res['errors'][] = "Dokumen $realNo tersimpan sebagai draft, gagal posting: " . implode(' ', $p['errors']);
            }
        } else {
            $res['notes'][] = "Dokumen $realNo disimpan sebagai draft (belum mempengaruhi stok).";
        }
    }

    return $res;
}
