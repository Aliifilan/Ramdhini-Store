<?php
declare(strict_types=1);

define('APP_NAME', 'Inventori');
define('APP_OWNER', 'Ramdhini Store');
define('LOW_STOCK_NOTE', 'peringatan');

date_default_timezone_set('Asia/Jakarta');

/* ---------- output & input ---------- */

function e($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function fmt_num($n, int $dec = 0): string
{
    return number_format((float)$n, $dec, ',', '.');
}

/**
 * URL aset dengan penanda versi (waktu berkas diubah).
 *
 * Kenapa perlu: server ini tidak mengirim header cache untuk berkas statis, sehingga
 * browser (terutama WebView aplikasi Android) menyimpan app.css/charts.js lama dan
 * tetap memakainya berhari-hari. Akibatnya fitur baru "tidak muncul" walau servernya
 * sudah benar. Dengan `?v=<mtime>` setiap perubahan berkas menghasilkan URL baru,
 * jadi browser wajib mengambil versi terbaru.
 */
function asset_url(string $path): string
{
    static $cache = [];
    if (!isset($cache[$path])) {
        $file = dirname(__DIR__) . '/' . ltrim($path, '/');
        $cache[$path] = is_file($file) ? (string)filemtime($file) : '1';
    }
    return $path . '?v=' . $cache[$path];
}

function fmt_money($n): string
{
    return 'Rp ' . number_format((float)$n, 0, ',', '.');
}

/**
 * Angka jumlah (qty): SELALU bilangan bulat, tidak pernah menampilkan koma desimal
 * (permintaan pemilik toko: "qty dibulatkan saja, tidak ada koma di belakangnya").
 * Dibulatkan ke angka terdekat, jadi 0,75 tampil "1" — sama dengan nilai yang disimpan
 * (lihat parse_qty()) sehingga angka di layar tidak pernah berbeda dari stok sebenarnya.
 */
function fmt_qty($n): string
{
    $v = round((float)$n);
    if ($v == 0.0) $v = 0.0;      // hindari "-0" untuk nilai negatif kecil
    return number_format($v, 0, ',', '.');
}

function fmt_date($d): string
{
    if (!$d) return '-';
    $t = strtotime((string)$d);
    return $t ? date('d/m/Y', $t) : (string)$d;
}

/**
 * Tanggal + jam:menit:detik. Dipakai untuk semua jejak waktu transaksi
 * (dibuat, diposting, di-void) supaya urutan kejadian bisa dipastikan
 * sampai satuan detik — penting saat ada beberapa dokumen di hari yang sama.
 */
function fmt_dt($d): string
{
    if (!$d) return '-';
    $t = strtotime((string)$d);
    return $t ? date('d/m/Y H:i:s', $t) : (string)$d;
}

/** Jam saja (tanpa tanggal) dengan detik — untuk kolom yang tanggalnya sudah ada. */
function fmt_time($d): string
{
    if (!$d) return '-';
    $t = strtotime((string)$d);
    return $t ? date('H:i:s', $t) : '-';
}

function now(): string
{
    return date('Y-m-d H:i:s');
}

function today(): string
{
    return date('Y-m-d');
}

function post(string $k, $d = '')
{
    if (!isset($_POST[$k])) return $d;
    $v = $_POST[$k];
    return is_array($v) ? $v : trim((string)$v);
}

function get(string $k, $d = '')
{
    if (!isset($_GET[$k])) return $d;
    $v = $_GET[$k];
    return is_array($v) ? $v : trim((string)$v);
}

function redirect(string $u): void
{
    header('Location: ' . $u);
    exit;
}

/**
 * URL absolut untuk aplikasi ini (dipakai menampilkan tautan cron dsb).
 * Skema & host diambil dari request supaya tidak salah saat diakses lewat http
 * maupun di balik proxy (Caddy mengirim X-Forwarded-Proto).
 */
function app_base_url(): string
{
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    $host = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
    $dir = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
    return ($https ? 'https://' : 'http://') . $host . $dir;
}

function qs(array $override = []): string
{
    $p = array_merge($_GET, $override);
    foreach ($p as $k => $v) {
        if ($v === '' || $v === null) unset($p[$k]);
    }
    return http_build_query($p);
}

/* ---------- flash + csrf ---------- */

function flash(string $msg, string $type = 'success'): void
{
    $_SESSION['flash'][] = ['msg' => $msg, 'type' => $type];
}

function take_flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return is_array($f) ? $f : [];
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . csrf_token() . '">';
}

function csrf_verify(): void
{
    $t = $_POST['_csrf'] ?? '';
    if (!is_string($t) || $t === '' || !hash_equals($_SESSION['csrf'] ?? '', $t)) {
        http_response_code(419);
        exit('Sesi Anda sudah kedaluwarsa. Silakan muat ulang halaman dan coba lagi.');
    }
}

/* ---------- angka & CSV ---------- */

/**
 * Baca angka dari input apa pun.
 *
 * Aplikasi menampilkan angka gaya Indonesia ("226.600" = dua ratus dua puluh enam
 * ribu enam ratus, "1,5" = satu koma lima). Aturan di sini sengaja dibuat SAMA
 * PERSIS dengan num() di assets/app.js (diuji oleh tests/parse_check.sh) supaya
 * angka yang ditampilkan dan yang disimpan tidak pernah berbeda:
 *   - ada "." dan ","  -> pemisah paling belakang = tanda desimal
 *   - hanya "." atau hanya "," dengan tepat 3 angka di belakang dan angka depan
 *     1-3 digit -> pemisah ribuan         ("50.000" -> 50000, "1,000" -> 1000)
 *   - selain itu desimal                 ("12.3" -> 12.3, "1,5" -> 1.5)
 */
function parse_num($v): float
{
    $s = trim((string)$v);
    if ($s === '') return 0.0;
    $neg = str_starts_with($s, '-');
    $s = preg_replace('/[^0-9.,]/', '', $s);
    if ($s === '' || $s === '.' || $s === ',') return 0.0;

    $hasDot = str_contains($s, '.');
    $hasComma = str_contains($s, ',');

    if ($hasDot && $hasComma) {
        if (strrpos($s, ',') > strrpos($s, '.')) {
            $s = str_replace(',', '.', str_replace('.', '', $s));
        } else {
            $s = str_replace(',', '', $s);
        }
        $value = (float)$s;
    } elseif (!$hasDot && !$hasComma) {
        $value = (float)$s;
    } else {
        $sep = $hasDot ? '.' : ',';
        $parts = explode($sep, $s);
        $last = $parts[count($parts) - 1];
        $first = ltrim($parts[0], '0');
        $isThousands = $last !== ''
            && strlen($last) === 3
            && $first !== ''
            && strlen($first) <= 3;
        $value = $isThousands ? (float)implode('', $parts) : (float)str_replace($sep, '.', $s);
    }
    return $neg ? -$value : $value;
}

/**
 * Baca jumlah (qty) dari input: sama seperti parse_num(), lalu DIBULATKAN ke
 * bilangan bulat terdekat. Qty di aplikasi ini selalu satuan utuh (pcs), jadi
 * "0,75" disimpan sebagai 1 — bukan 0,75 yang lalu tampil "1" di layar
 * sementara stoknya tetap 0,75 (angka layar dan stok tidak boleh berbeda).
 */
function parse_qty($v): float
{
    return (float)round(parse_num($v));
}

function csv_read(string $path): array
{
    $fh = fopen($path, 'r');
    if (!$fh) return ['header' => [], 'rows' => []];
    $first = (string)fgets($fh);
    $counts = [',' => substr_count($first, ','), ';' => substr_count($first, ';'), "\t" => substr_count($first, "\t")];
    arsort($counts);
    $delim = (string)array_key_first($counts);
    if ($counts[$delim] === 0) $delim = ',';
    rewind($fh);
    $header = null;
    $rows = [];
    while (($r = fgetcsv($fh, 0, $delim, '"', '')) !== false) {
        if ($r === [null]) continue;
        $r = array_map(static fn($x) => is_string($x) ? trim($x) : $x, $r);
        if ($header === null) {
            $header = [];
            foreach ($r as $h) {
                $h = strtolower(trim((string)$h));
                $h = preg_replace('/^\xEF\xBB\xBF/', '', (string)$h);
                $h = str_replace([' ', '-'], '_', (string)$h);
                $header[] = (string)$h;
            }
            continue;
        }
        if (count(array_filter($r, static fn($x) => $x !== null && $x !== '')) === 0) continue;
        $assoc = [];
        foreach ($header as $i => $h) {
            $assoc[$h] = $r[$i] ?? '';
        }
        $rows[] = $assoc;
    }
    fclose($fh);
    return ['header' => $header ?? [], 'rows' => $rows];
}

/* ---------- ukuran produk ---------- */

/**
 * Daftar ukuran yang tersedia di Produk Master (persis sesuai permintaan pemilik toko).
 * Dipakai form produk, filter, dan tampilan supaya penulisannya selalu sama.
 */
function product_sizes(): array
{
    return [
        'XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL', 'XXXXL',
        '27', '28', '29', '30', '31', '32', '33', '34', '36', '38', '40', '41', '42', '44',
        'All Size',
    ];
}

/** Ukuran dari input bebas: hanya diterima bila ada di daftar resmi (selain itu dibiarkan kosong). */
function normalize_size($value): string
{
    $v = trim((string)$value);
    if ($v === '') return '';
    foreach (product_sizes() as $s) {
        if (strcasecmp($s, $v) === 0) return $s;
    }
    /* Terima juga angka ukuran yang ditulis dengan spasi/format berbeda, mis. " 30 " */
    $num = preg_replace('/[^0-9]/', '', $v);
    if ($num !== '' && in_array($num, product_sizes(), true)) return $num;
    return '';
}

/* ---------- misc ---------- */

function input_date(string $key, ?string $default = null): string
{
    $v = get($key, '');
    if (is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)) return $v;
    return $default ?? today();
}

/**
 * Baca tanggal dari input bebas (Excel/CSV) -> Y-m-d, atau null bila tidak dikenali.
 * Mengenali: 2026-01-31, 31/01/2026, 31-01-2026, 31.01.2026, 2026/01/31, 1/31/2026 (bila hari > 12).
 */
function parse_date_flexible($v): ?string
{
    $s = trim((string)$v);
    if ($s === '') return null;
    if (preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})/', $s, $m)) {
        if (checkdate((int)$m[2], (int)$m[3], (int)$m[1])) {
            return sprintf('%04d-%02d-%02d', (int)$m[1], (int)$m[2], (int)$m[3]);
        }
        return null;
    }
    if (preg_match('/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})/', $s, $m)) {
        $a = (int)$m[1];
        $b = (int)$m[2];
        $y = (int)$m[3];
        if ($a > 12 && $b <= 12) { $d = $a; $mo = $b; }
        elseif ($b > 12 && $a <= 12) { $d = $b; $mo = $a; }
        else { $d = $a; $mo = $b; }   // format Indonesia: hari dulu (dd/mm/yyyy)
        if (checkdate($mo, $d, $y)) return sprintf('%04d-%02d-%02d', $y, $mo, $d);
        return null;
    }
    if (preg_match('/^(\d{4})(\d{2})(\d{2})$/', $s, $m)) {
        if (checkdate((int)$m[2], (int)$m[3], (int)$m[1])) return sprintf('%s-%s-%s', $m[1], $m[2], $m[3]);
    }
    $ts = strtotime($s);
    if ($ts !== false && $ts > 0 && strlen($s) > 5) return date('Y-m-d', $ts);
    return null;
}

function pager(int $total, int $perPage = 25): array
{
    $pages = max(1, (int)ceil($total / $perPage));
    $page = (int)get('page', 1);
    if ($page < 1) $page = 1;
    if ($page > $pages) $page = $pages;
    return ['page' => $page, 'pages' => $pages, 'offset' => ($page - 1) * $perPage, 'per' => $perPage, 'total' => $total];
}

function render_pager(array $p): string
{
    if ($p['pages'] <= 1) return '';
    $out = '<div class="pager">';
    $out .= '<span class="pager-info">Halaman ' . $p['page'] . ' dari ' . $p['pages'] . ' (' . fmt_num($p['total']) . ' data)</span>';
    $out .= '<span class="pager-links">';
    if ($p['page'] > 1) {
        $out .= '<a class="btn btn-sm" href="?' . e(qs(['page' => $p['page'] - 1])) . '">&laquo; Sebelumnya</a>';
    }
    if ($p['page'] < $p['pages']) {
        $out .= '<a class="btn btn-sm" href="?' . e(qs(['page' => $p['page'] + 1])) . '">Berikutnya &raquo;</a>';
    }
    $out .= '</span></div>';
    return $out;
}

function status_badge(string $status): string
{
    $map = [
        'draft' => ['Draft', 'badge-warn'],
        'posted' => ['Posted', 'badge-ok'],
        'void' => ['Void', 'badge-danger'],
    ];
    [$label, $cls] = $map[$status] ?? [$status, 'badge-muted'];
    return '<span class="badge ' . $cls . '">' . e($label) . '</span>';
}

function doc_types(): array
{
    return [
        'inbound' => 'Barang Masuk',
        'outbound' => 'Barang Keluar',
        'adjustment' => 'Penyesuaian Stok',
        'opname' => 'Stok Opname',
        'return_supplier' => 'Retur ke Supplier',
        'return_customer' => 'Retur dari Customer',
    ];
}
