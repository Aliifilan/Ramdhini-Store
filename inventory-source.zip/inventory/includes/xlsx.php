<?php
declare(strict_types=1);

/* ============================================================
 * XLSX (Excel) tanpa dependensi eksternal.
 *
 * Tulis : xlsx_send($filename, $header, $rows, $sheetName)
 * Baca  : xlsx_read($path)  -> ['header' => [...], 'rows' => [[kolom => nilai], ...]]
 *
 * File .xlsx pada dasarnya arsip ZIP berisi beberapa file XML. ZIP ditulis
 * dan dibaca manual (pakai gzdeflate/gzinflate bawaan PHP) supaya aplikasi
 * tidak bergantung pada ekstensi zip / library composer apa pun.
 * ============================================================ */

/* ---------------- util XML ---------------- */

function xlsx_xml_escape($v): string
{
    $s = (string)$v;
    // buang karakter kontrol yang tidak sah di XML 1.0
    $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', '', $s) ?? $s;
    return htmlspecialchars($s, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

function xlsx_xml_unescape(string $s): string
{
    return html_entity_decode($s, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

function xlsx_col_letter(int $idx): string
{
    $s = '';
    $idx++;
    while ($idx > 0) {
        $rem = ($idx - 1) % 26;
        $s = chr(65 + $rem) . $s;
        $idx = (int)(($idx - 1) / 26);
    }
    return $s;
}

function xlsx_col_index(string $letters): int
{
    $letters = strtoupper(preg_replace('/[^A-Za-z]/', '', $letters) ?? '');
    $n = 0;
    for ($i = 0; $i < strlen($letters); $i++) {
        $n = $n * 26 + (ord($letters[$i]) - 64);
    }
    return $n - 1;
}

/** Nilai yang aman ditulis sebagai angka di Excel. */
function xlsx_is_number($v): bool
{
    if (is_int($v) || is_float($v)) return true;
    if (!is_string($v)) return false;
    $s = trim($v);
    if ($s === '' || strlen($s) > 15) return false;
    if (!preg_match('/^-?\d+(\.\d+)?$/', $s)) return false;
    if (strlen($s) > 1 && $s[0] === '0') return false;   // kode seperti 00123 tetap teks
    if ($s[0] === '-' && strlen($s) > 2 && $s[1] === '0') return false;
    return true;
}

/* ---------------- ZIP writer ---------------- */

function xlsx_dos_datetime(): array
{
    $t = getdate();
    $time = ($t['hours'] << 11) | ($t['minutes'] << 5) | ((int)($t['seconds'] / 2));
    $date = (($t['year'] - 1980) << 9) | ($t['mon'] << 5) | $t['mday'];
    return [$time, $date];
}

function xlsx_crc32(string $data): int
{
    $c = crc32($data);
    if ($c < 0) $c += 4294967296;
    return (int)$c;
}

/**
 * Bangun arsip ZIP berisi daftar entry (nama => isi).
 */
function xlsx_zip_build(array $files): string
{
    [$time, $date] = xlsx_dos_datetime();
    $useDeflate = function_exists('gzdeflate');
    $locals = '';
    $central = '';
    $count = 0;

    foreach ($files as $name => $content) {
        $name = (string)$name;
        $raw = (string)$content;
        $crc = xlsx_crc32($raw);
        $usize = strlen($raw);
        $method = 0;
        $data = $raw;
        if ($useDeflate) {
            $z = gzdeflate($raw, 6);
            if ($z !== false && strlen($z) < $usize) {
                $data = $z;
                $method = 8;
            }
        }
        $csize = strlen($data);
        $offset = strlen($locals);

        $locals .= pack('VvvvvvVVVvv', 0x04034b50, 20, 0x0800, $method, $time, $date, $crc, $csize, $usize, strlen($name), 0)
            . $name . $data;

        $central .= pack('VvvvvvvVVVvvvvvVV', 0x02014b50, 20, 20, 0x0800, $method, $time, $date, $crc, $csize, $usize,
                strlen($name), 0, 0, 0, 0, 0, $offset)
            . $name;
        $count++;
    }

    $eocd = pack('VvvvvVVv', 0x06054b50, 0, 0, $count, $count, strlen($central), strlen($locals), 0);
    return $locals . $central . $eocd;
}

/* ---------------- ZIP reader ---------------- */

/**
 * Baca arsip ZIP dan kembalikan daftar entry (nama => isi mentah).
 */
function xlsx_zip_read(string $blob): array
{
    $files = [];
    $len = strlen($blob);
    $pos = 0;
    while ($pos + 30 <= $len) {
        $sig = substr($blob, $pos, 4);
        if ($sig !== "PK\x03\x04") break;
        $h = unpack('vversion/vflags/vmethod/vtime/vdate/Vcrc/Vcsize/Vusize/vnlen/vexlen', substr($blob, $pos + 4, 26));
        if (!$h) break;
        $name = substr($blob, $pos + 30, $h['nlen']);
        $dataStart = $pos + 30 + $h['nlen'] + $h['exlen'];
        $csize = (int)$h['csize'];
        $usize = (int)$h['usize'];

        // ukuran 0 di header lokal -> ada data descriptor setelah data (streaming writer)
        if ($csize === 0 && $usize === 0 && !($h['flags'] & 0x08)) {
            $csize = 0;
        }
        if ($h['flags'] & 0x08) {
            // cari signature data descriptor setelah data terkompres
            $scan = $dataStart;
            $found = false;
            while ($scan + 16 <= $len) {
                if (substr($blob, $scan, 4) === "PK\x07\x08") {
                    $dd = unpack('Vcrc/Vcsize/Vusize', substr($blob, $scan + 4, 12));
                    $csize = (int)$dd['csize'];
                    $usize = (int)$dd['usize'];
                    $found = true;
                    break;
                }
                $scan++;
            }
            if (!$found) break;
        }

        $raw = substr($blob, $dataStart, $csize);
        if ($h['method'] === 8) {
            $inf = @gzinflate($raw);
            if ($inf === false) {
                // fallback: coba baca sampai ukuran asli terpenuhi (sebagian writer menulis csize=0)
                $inf = @gzinflate(substr($blob, $dataStart));
            }
            $raw = $inf === false ? '' : $inf;
        }
        $files[$name] = $raw;

        $pos = $dataStart + $csize;
        if ($h['flags'] & 0x08) {
            $pos += 16;
        }
    }
    return $files;
}

/* ---------------- XLSX writer ---------------- */

function xlsx_sheet_name(string $name): string
{
    $name = preg_replace('/[\\\\\/\?\*\[\]:]/', ' ', $name) ?? $name;
    $name = trim($name);
    if ($name === '') $name = 'Data';
    return mb_substr($name, 0, 31, 'UTF-8');
}

/**
 * Susun isi satu worksheet. String dikumpulkan ke sharedStrings.
 */
function xlsx_sheet_xml(array $rows, array &$shared, array &$sharedIndex): string
{
    $widths = [];
    $out = [];
    $rowNum = 0;
    foreach ($rows as $cols) {
        $rowNum++;
        $cells = '';
        $colIdx = -1;
        foreach (array_values($cols) as $val) {
            $colIdx++;
            if ($val === null || $val === '') continue;
            $ref = xlsx_col_letter($colIdx) . $rowNum;
            $style = $rowNum === 1 ? ' s="1"' : '';
            if (xlsx_is_number($val)) {
                $num = is_string($val) ? $val : (string)$val;
                if (is_float($val) && floor($val) === $val) $num = (string)(int)$val;
                $cells .= '<c r="' . $ref . '"' . $style . '><v>' . $num . '</v></c>';
            } else {
                $s = (string)$val;
                if (!isset($sharedIndex[$s])) {
                    $sharedIndex[$s] = count($shared);
                    $shared[] = $s;
                }
                $si = $sharedIndex[$s];
                $cells .= '<c r="' . $ref . '"' . $style . ' t="s"><v>' . $si . '</v></c>';
            }
            $text = (string)$val;
            $need = min(46, max(9, mb_strlen($text, 'UTF-8') + 2));
            if (!isset($widths[$colIdx]) || $widths[$colIdx] < $need) $widths[$colIdx] = $need;
        }
        if ($cells !== '') {
            $out[] = '<row r="' . $rowNum . '">' . $cells . '</row>';
        } else {
            $rowNum--;
        }
    }

    $cols = '';
    if ($widths) {
        ksort($widths);
        $cols = '<cols>';
        foreach ($widths as $i => $w) {
            $cols .= '<col min="' . ($i + 1) . '" max="' . ($i + 1) . '" width="' . $w . '" customWidth="1"/>';
        }
        $cols .= '</cols>';
    }

    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<sheetViews><sheetView workbookViewId="0">'
        . '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
        . '<selection pane="bottomLeft" activeCell="A2" sqref="A2"/>'
        . '</sheetView></sheetViews>'
        . $cols
        . '<sheetData>' . implode('', $out) . '</sheetData>'
        . '</worksheet>';
}

/**
 * Bangun isi file .xlsx dari beberapa sheet.
 * $sheets = [['name' => 'Unit', 'rows' => [[...], [...]]], ...]
 */
function xlsx_build_multi(array $sheets): string
{
    if (!$sheets) $sheets = [['name' => 'Data', 'rows' => []]];
    $shared = [];
    $sharedIndex = [];
    $sheetFiles = [];
    $contentOverrides = '';
    $wbRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
    $sheetTags = '';
    $usedNames = [];
    $i = 0;

    foreach ($sheets as $sheet) {
        $i++;
        $name = xlsx_sheet_name((string)($sheet['name'] ?? ('Sheet' . $i)));
        $base = $name;
        $n = 2;
        while (in_array($name, $usedNames, true)) { $name = mb_substr($base, 0, 28, 'UTF-8') . ' (' . $n . ')'; $n++; }
        $usedNames[] = $name;

        $rows = $sheet['rows'] ?? [];
        $sheetFiles['xl/worksheets/sheet' . $i . '.xml'] = xlsx_sheet_xml($rows, $shared, $sharedIndex);
        $contentOverrides .= '<Override PartName="/xl/worksheets/sheet' . $i . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        $wbRels .= '<Relationship Id="rIdS' . $i . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $i . '.xml"/>';
        $sheetTags .= '<sheet name="' . xlsx_xml_escape($name) . '" sheetId="' . $i . '" r:id="rIdS' . $i . '"/>';
    }

    $ssXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="' . count($shared) . '" uniqueCount="' . count($shared) . '">';
    foreach ($shared as $s) {
        $ssXml .= '<si><t xml:space="preserve">' . xlsx_xml_escape($s) . '</t></si>';
    }
    $ssXml .= '</sst>';

    $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        . $contentOverrides
        . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        . '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
        . '</Types>';

    $rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        . '</Relationships>';

    $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
        . ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<sheets>' . $sheetTags . '</sheets>'
        . '</workbook>';

    $wbRels .= '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        . '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>'
        . '</Relationships>';

    $styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<fonts count="2">'
        . '<font><sz val="11"/><color theme="1"/><name val="Calibri"/><family val="2"/></font>'
        . '<font><b/><sz val="11"/><color theme="1"/><name val="Calibri"/><family val="2"/></font>'
        . '</fonts>'
        . '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
        . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
        . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        . '<cellXfs count="2">'
        . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
        . '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
        . '</cellXfs>'
        . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        . '</styleSheet>';

    $files = [
        '[Content_Types].xml' => $contentTypes,
        '_rels/.rels' => $rootRels,
        'xl/workbook.xml' => $workbook,
        'xl/_rels/workbook.xml.rels' => $wbRels,
        'xl/styles.xml' => $styles,
        'xl/sharedStrings.xml' => $ssXml,
    ];
    foreach ($sheetFiles as $k => $v) $files[$k] = $v;
    return xlsx_zip_build($files);
}

/**
 * Bangun isi file .xlsx dari daftar baris (baris pertama = judul kolom).
 */
function xlsx_build(array $rows, string $sheetName = 'Data'): string
{
    return xlsx_build_multi([['name' => $sheetName, 'rows' => $rows]]);
}

/**
 * Kirim file .xlsx berisi beberapa sheet sebagai unduhan.
 * $sheets = [['name' => 'Unit', 'header' => [...], 'rows' => [...]], ...]
 */
function xlsx_send_multi(string $filename, array $sheets): void
{
    $prepared = [];
    foreach ($sheets as $sh) {
        $rows = [$sh['header'] ?? []];
        foreach (($sh['rows'] ?? []) as $r) {
            $rows[] = is_array($r) ? array_values($r) : array_values((array)$r);
        }
        $prepared[] = ['name' => $sh['name'] ?? 'Data', 'rows' => $rows];
    }
    $blob = xlsx_build_multi($prepared);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . xlsx_filename($filename) . '"');
    header('Content-Length: ' . strlen($blob));
    header('Cache-Control: no-store');
    echo $blob;
}

function xlsx_filename(string $name): string
{
    $name = preg_replace('/[^A-Za-z0-9._-]/', '-', $name) ?? $name;
    return $name . (str_ends_with(strtolower($name), '.xlsx') ? '' : '.xlsx');
}

/** Nama sheet yang enak dibaca, diambil dari nama file (mis. "stok-per-brand-20261012"). */
function xlsx_sheet_from_filename(string $filename): string
{
    $base = preg_replace('/\.xlsx$/i', '', $filename) ?? $filename;
    $base = preg_replace('/-?\d{6,8}$/', '', $base) ?? $base;   // buang bagian tanggal
    $base = str_replace(['_', '-'], ' ', $base);
    $base = trim(preg_replace('/\s+/', ' ', $base) ?? $base);
    if ($base === '') return 'Data';
    return mb_convert_case($base, MB_CASE_TITLE, 'UTF-8');
}

/**
 * Kirim file .xlsx sebagai unduhan (header pertama = judul kolom).
 * $sheetName kosong = ambil otomatis dari nama file.
 */
function xlsx_send(string $filename, array $header, iterable $rows, string $sheetName = ''): void
{
    if ($sheetName === '') $sheetName = xlsx_sheet_from_filename($filename);
    $data = [];
    $data[] = array_values($header);
    foreach ($rows as $r) {
        if (is_array($r)) {
            $data[] = array_values($r);
        } else {
            $data[] = array_values((array)$r);
        }
    }
    $blob = xlsx_build($data, $sheetName);

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . xlsx_filename($filename) . '"');
    header('Content-Length: ' . strlen($blob));
    header('Cache-Control: no-store');
    echo $blob;
}

/* ---------------- XLSX reader ---------------- */

/** Kolom yang isinya tanggal, dipakai untuk mengubah nomor seri Excel jadi tanggal. */
function xlsx_date_columns(): array
{
    return ['doc_date', 'move_date', 'date', 'tanggal', 'tgl', 'created_at', 'posted_at'];
}

function xlsx_serial_to_date(float $serial): ?string
{
    if ($serial < 20000 || $serial > 80000) return null;
    $days = (int)floor($serial);
    // nomor seri Excel: hari ke-25569 = 1970-01-01 (zona aman, di luar bug tahun 1900)
    $ts = ($days - 25569) * 86400;
    return gmdate('Y-m-d', (int)$ts);
}

/**
 * Baca worksheet XLSX jadi daftar baris asosiatif.
 *
 * @return array{header:array<int,string>,rows:array<int,array<string,string>>}
 */
function xlsx_read(string $path): array
{
    $blob = @file_get_contents($path);
    if ($blob === false || strncmp($blob, "PK", 2) !== 0) {
        return ['header' => [], 'rows' => []];
    }
    $zip = xlsx_zip_read($blob);
    if (!$zip) return ['header' => [], 'rows' => []];

    /* 1. shared strings */
    $shared = [];
    foreach ($zip as $name => $content) {
        if (str_ends_with($name, 'sharedStrings.xml')) {
            if (preg_match_all('/<(?:[a-zA-Z0-9]+:)?si\b[^>]*>(.*?)<\/(?:[a-zA-Z0-9]+:)?si>/s', $content, $m)) {
                foreach ($m[1] as $si) {
                    if (preg_match_all('/<(?:[a-zA-Z0-9]+:)?t\b[^>]*>(.*?)<\/(?:[a-zA-Z0-9]+:)?t>/s', $si, $tt)) {
                        $shared[] = xlsx_xml_unescape(implode('', $tt[1]));
                    } else {
                        $shared[] = '';
                    }
                }
            }
            break;
        }
    }

    /* 2. worksheet (semua sheet digabung, urut nama) */
    $sheets = [];
    foreach ($zip as $name => $content) {
        if (preg_match('#xl/worksheets/[^/]*sheet[^/]*\.xml$#', $name)) {
            $sheets[$name] = $content;
        }
    }
    if (!$sheets) {
        // sebagian penulis memakai nama lain; ambil file xml apa pun yang punya sheetData
        foreach ($zip as $name => $content) {
            if (str_contains($content, '<sheetData') || str_contains($content, ':sheetData')) {
                $sheets[$name] = $content;
            }
        }
    }
    /* Kalau file punya beberapa sheet, hanya sheet pertama yang dibaca
       (baris dari beberapa sheet tidak boleh tercampur menjadi satu tabel). */
    if (count($sheets) > 1) {
        $order = [];
        foreach ($zip as $name => $content) {
            if (str_ends_with($name, 'workbook.xml') && preg_match_all('/<sheet[^>]*r:id="(rId[^"]+)"[^>]*>/', $content, $mm)) {
                if (preg_match_all('/<Relationship Id="(rId[^"]+)"[^>]*Target="([^"]+)"/', $zip['xl/_rels/workbook.xml.rels'] ?? '', $rr)) {
                    $map = array_combine($rr[1], $rr[2]);
                    foreach ($mm[1] as $rid) {
                        $target = $map[$rid] ?? '';
                        if ($target !== '') $order[] = 'xl/' . ltrim(str_replace('../', '', $target), '/');
                    }
                }
            }
        }
        foreach ($order as $want) {
            if (isset($sheets[$want])) { $sheets = [$want => $sheets[$want]]; break; }
        }
        if (count($sheets) > 1) {
            ksort($sheets);
            $first = array_key_first($sheets);
            $sheets = [$first => $sheets[$first]];
        }
    }
    ksort($sheets);

    $header = null;
    $rows = [];
    $dateCols = xlsx_date_columns();

    foreach ($sheets as $content) {
        if (!preg_match_all('/<(?:[a-zA-Z0-9]+:)?row\b[^>]*>(.*?)<\/(?:[a-zA-Z0-9]+:)?row>/s', $content, $rowMatches)) {
            continue;
        }
        foreach ($rowMatches[1] as $rowXml) {
            $values = [];
            $auto = 0;
            if (preg_match_all('/<(?:[a-zA-Z0-9]+:)?c\b([^>]*)(?:\/>|>(.*?)<\/(?:[a-zA-Z0-9]+:)?c>)/s', $rowXml, $cellMatches, PREG_SET_ORDER)) {
                foreach ($cellMatches as $cm) {
                    $attrs = $cm[1];
                    $inner = $cm[2] ?? '';
                    $ref = '';
                    $type = '';
                    if (preg_match('/\br="([A-Za-z]+)\d+"/', $attrs, $rm)) $ref = $rm[1];
                    if (preg_match('/\bt="([a-zA-Z]+)"/', $attrs, $tm)) $type = $tm[1];
                    $col = $ref !== '' ? xlsx_col_index($ref) : $auto;
                    $auto = $col + 1;

                    $val = '';
                    if ($type === 'inlineStr') {
                        if (preg_match_all('/<(?:[a-zA-Z0-9]+:)?t\b[^>]*>(.*?)<\/(?:[a-zA-Z0-9]+:)?t>/s', $inner, $im)) {
                            $val = xlsx_xml_unescape(implode('', $im[1]));
                        }
                    } elseif (preg_match('/<(?:[a-zA-Z0-9]+:)?v[^>]*>(.*?)<\/(?:[a-zA-Z0-9]+:)?v>/s', $inner, $vm)) {
                        $raw = xlsx_xml_unescape($vm[1]);
                        if ($type === 's') {
                            $idx = (int)$raw;
                            $val = $shared[$idx] ?? '';
                        } else {
                            $val = $raw;
                        }
                    } elseif (preg_match('/<(?:[a-zA-Z0-9]+:)?is\b[^>]*>(.*?)<\/(?:[a-zA-Z0-9]+:)?is>/s', $inner, $im)) {
                        if (preg_match_all('/<(?:[a-zA-Z0-9]+:)?t\b[^>]*>(.*?)<\/(?:[a-zA-Z0-9]+:)?t>/s', $im[1], $tm2)) {
                            $val = xlsx_xml_unescape(implode('', $tm2[1]));
                        }
                    }
                    $values[$col] = trim((string)$val);
                }
            }
            if (!$values) continue;
            $maxCol = max(array_keys($values));

            if ($header === null) {
                $head = [];
                for ($i = 0; $i <= $maxCol; $i++) {
                    $h = strtolower($values[$i] ?? '');
                    $h = str_replace([' ', '-'], '_', $h);
                    $head[] = preg_replace('/[^a-z0-9_]/', '', $h) ?? $h;
                }
                // baris judul dibuang bila seluruhnya kosong
                if (count(array_filter($head, static fn($x) => $x !== '')) === 0) continue;
                $header = $head;
                continue;
            }

            $assoc = [];
            $nonEmpty = 0;
            for ($i = 0; $i <= $maxCol; $i++) {
                $key = $header[$i] ?? ('kolom_' . ($i + 1));
                $val = $values[$i] ?? '';
                if ($val !== '') $nonEmpty++;
                if ($val !== '' && in_array($key, $dateCols, true) && preg_match('/^\d+(\.\d+)?$/', $val)) {
                    $d = xlsx_serial_to_date((float)$val);
                    if ($d !== null) $val = $d;
                }
                $assoc[$key] = $val;
            }
            if ($nonEmpty === 0) continue;

            // baris judul berulang (mis. sheet kedua) tidak dianggap data
            if ($nonEmpty > 0) {
                $sameAsHeader = true;
                foreach ($assoc as $k => $v) {
                    $norm = preg_replace('/[^a-z0-9_]/', '', str_replace([' ', '-'], '_', strtolower((string)$v))) ?? '';
                    if ($norm !== '' && $norm !== $k) { $sameAsHeader = false; break; }
                }
                if ($sameAsHeader) continue;
            }
            $rows[] = $assoc;
        }
    }

    return ['header' => $header ?? [], 'rows' => $rows];
}

/** Deteksi jenis file spreadsheet dari namanya. */
function sheet_kind(string $filename): ?string
{
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if ($ext === 'xlsx') return 'xlsx';
    if (in_array($ext, ['csv', 'txt'], true)) return 'csv';
    return null;
}

/** Baca spreadsheet (xlsx atau csv) -> bentuk yang sama seperti csv_read(). */
function sheet_read(string $path, string $kind): array
{
    if ($kind === 'xlsx') return xlsx_read($path);
    return csv_read($path);
}
