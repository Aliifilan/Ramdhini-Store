<?php
declare(strict_types=1);

function db_path(): string
{
    $env = getenv('INVENTORY_DB');
    if (is_string($env) && $env !== '') return $env;
    return dirname(__DIR__) . '/data.sqlite';
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $pdo = new PDO('sqlite:' . db_path());
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA busy_timeout = 5000');
    $pdo->exec('PRAGMA journal_mode = WAL');
    $pdo->exec('PRAGMA synchronous = NORMAL');
    $pdo->exec('PRAGMA foreign_keys = ON');
    return $pdo;
}

function db_scalar(string $sql, array $params = [])
{
    $v = db_prepare($sql, $params)->fetchColumn();
    return $v === false ? null : $v;
}

function db_all(string $sql, array $params = []): array
{
    return db_prepare($sql, $params)->fetchAll();
}

function db_one(string $sql, array $params = [])
{
    $r = db_prepare($sql, $params)->fetch();
    return $r === false ? null : $r;
}

/**
 * Hitung jumlah tanda tanya (placeholder) di SQL, mengabaikan yang ada di dalam
 * tanda kutip ('...' atau "...") supaya nilai seperti 'a?b' tidak ikut terhitung.
 */
function db_placeholder_count(string $sql): int
{
    $count = 0;
    $len = strlen($sql);
    $quote = null;
    for ($i = 0; $i < $len; $i++) {
        $ch = $sql[$i];
        if ($quote !== null) {
            if ($ch === $quote) {
                /* tanda kutip ganda ditulis '' di SQL */
                if ($i + 1 < $len && $sql[$i + 1] === $quote) { $i++; continue; }
                $quote = null;
            }
            continue;
        }
        if ($ch === "'" || $ch === '"') { $quote = $ch; continue; }
        if ($ch === '?') $count++;
    }
    return $count;
}

/**
 * Siapkan statement sambil MEMERIKSA kecocokan jumlah parameter.
 *
 * Pengaman ini dipasang setelah terjadi bug nyata: sebuah INSERT di importer
 * menulis 8 tanda ? tetapi hanya menerima 7 nilai, sehingga seluruh nilai bergeser
 * satu kolom (nama supplier tersimpan sebagai kode) dan import berikutnya gagal
 * dengan "UNIQUE constraint failed: suppliers.code". Kesalahan seperti itu tidak
 * terlihat sampai data rusak, jadi sekarang langsung ditolak dengan pesan jelas.
 */
function db_prepare(string $sql, array $params = []): PDOStatement
{
    $expected = db_placeholder_count($sql);
    if ($expected !== count($params)) {
        $snippet = preg_replace('/\s+/', ' ', substr($sql, 0, 90));
        throw new RuntimeException(
            'Jumlah parameter SQL tidak cocok: ' . $expected . ' tanda ? tetapi ' . count($params)
            . ' nilai dikirim. Query: ' . $snippet . '…'
        );
    }
    $st = db()->prepare($sql);
    $st->execute(array_values($params));
    return $st;
}

function db_run(string $sql, array $params = []): PDOStatement
{
    return db_prepare($sql, $params);
}

/**
 * Tambah kolom bila belum ada. Mengembalikan true hanya saat kolom benar-benar ditambahkan,
 * supaya pemanggil bisa menjalankan pengisian data awal (backfill) tepat sekali.
 */
function ensure_column(PDO $pdo, string $table, string $column, string $definition): bool
{
    if (column_exists($pdo, $table, $column)) return false;
    try {
        $pdo->exec('ALTER TABLE ' . $table . ' ADD COLUMN ' . $column . ' ' . $definition);
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/** Apakah tabel punya kolom tertentu (dipakai untuk migrasi ringan). */
function column_exists(PDO $pdo, string $table, string $column): bool
{
    try {
        $st = $pdo->query('PRAGMA table_info(' . $table . ')');
        if (!$st) return false;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $c) {
            if (strtolower((string)($c['name'] ?? '')) === strtolower($column)) return true;
        }
    } catch (Throwable $e) {
        return false;
    }
    return false;
}

/**
 * Sisa kolom lama "products.name" (dihapus otomatis saat migrasi bila SQLite mendukung).
 * Kalau masih ada, setiap produk baru tetap diisi SKU-nya agar NOT NULL tidak dilanggar.
 */
function products_has_name_column(): bool
{
    static $has = null;
    if ($has === null) {
        $has = column_exists(db(), 'products', 'name');
    }
    return $has;
}

function db_tx(callable $fn)
{
    static $depth = 0;
    $pdo = db();
    if ($depth === 0) {
        $pdo->exec('BEGIN IMMEDIATE');
    }
    $depth++;
    try {
        $r = $fn($pdo);
        $depth--;
        if ($depth === 0) {
            $pdo->exec('COMMIT');
        }
        return $r;
    } catch (Throwable $ex) {
        $depth--;
        if ($depth === 0) {
            try { $pdo->exec('ROLLBACK'); } catch (Throwable $e2) {}
        }
        throw $ex;
    }
}

function ensure_schema(): void
{
    static $done = false;
    if ($done) return;
    $done = true;

    db_tx(function (PDO $pdo) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'viewer',
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS brands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS suppliers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            contact_person TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            email TEXT DEFAULT '',
            address TEXT DEFAULT '',
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sku TEXT NOT NULL UNIQUE,
            brand_id INTEGER REFERENCES brands(id),
            category TEXT DEFAULT '',
            size TEXT DEFAULT '',
            unit TEXT DEFAULT 'pcs',
            cost_price REAL NOT NULL DEFAULT 0,
            cost_price_initial REAL NOT NULL DEFAULT 0,
            sell_price REAL NOT NULL DEFAULT 0,
            min_stock REAL NOT NULL DEFAULT 0,
            stock_qty REAL NOT NULL DEFAULT 0,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT,
            updated_at TEXT
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS inbounds (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            doc_no TEXT NOT NULL UNIQUE,
            doc_date TEXT NOT NULL,
            supplier_id INTEGER REFERENCES suppliers(id),
            note TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'draft',
            total_qty REAL NOT NULL DEFAULT 0,
            subtotal_amount REAL NOT NULL DEFAULT 0,
            discount_type TEXT NOT NULL DEFAULT 'percent',
            discount_value REAL NOT NULL DEFAULT 0,
            discount_amount REAL NOT NULL DEFAULT 0,
            total_amount REAL NOT NULL DEFAULT 0,
            created_by INTEGER, created_at TEXT,
            posted_by INTEGER, posted_at TEXT,
            void_reason TEXT DEFAULT '', voided_by INTEGER, voided_at TEXT
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS inbound_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            inbound_id INTEGER NOT NULL REFERENCES inbounds(id) ON DELETE CASCADE,
            product_id INTEGER NOT NULL REFERENCES products(id),
            qty REAL NOT NULL DEFAULT 0,
            unit_cost REAL NOT NULL DEFAULT 0,
            subtotal REAL NOT NULL DEFAULT 0,
            discount_share REAL NOT NULL DEFAULT 0,
            unit_cost_net REAL NOT NULL DEFAULT 0,
            subtotal_net REAL NOT NULL DEFAULT 0,
            note TEXT DEFAULT ''
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS outbounds (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            doc_no TEXT NOT NULL UNIQUE,
            doc_date TEXT NOT NULL,
            destination TEXT DEFAULT '',
            channel TEXT DEFAULT '',
            note TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'draft',
            total_qty REAL NOT NULL DEFAULT 0,
            total_amount REAL NOT NULL DEFAULT 0,
            created_by INTEGER, created_at TEXT,
            posted_by INTEGER, posted_at TEXT,
            void_reason TEXT DEFAULT '', voided_by INTEGER, voided_at TEXT
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS outbound_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            outbound_id INTEGER NOT NULL REFERENCES outbounds(id) ON DELETE CASCADE,
            product_id INTEGER NOT NULL REFERENCES products(id),
            qty REAL NOT NULL DEFAULT 0,
            unit_price REAL NOT NULL DEFAULT 0,
            subtotal REAL NOT NULL DEFAULT 0,
            cogs REAL NOT NULL DEFAULT 0,
            cogs_unit REAL NOT NULL DEFAULT 0,
            note TEXT DEFAULT ''
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS adjustments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            doc_no TEXT NOT NULL UNIQUE,
            doc_date TEXT NOT NULL,
            reason TEXT DEFAULT '',
            note TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'posted',
            total_items INTEGER NOT NULL DEFAULT 0,
            total_delta REAL NOT NULL DEFAULT 0,
            created_by INTEGER, created_at TEXT,
            posted_by INTEGER, posted_at TEXT,
            void_reason TEXT DEFAULT '', voided_by INTEGER, voided_at TEXT
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS adjustment_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            adjustment_id INTEGER NOT NULL REFERENCES adjustments(id) ON DELETE CASCADE,
            product_id INTEGER NOT NULL REFERENCES products(id),
            qty_before REAL NOT NULL DEFAULT 0,
            qty_after REAL NOT NULL DEFAULT 0,
            delta REAL NOT NULL DEFAULT 0,
            note TEXT DEFAULT ''
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS opnames (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            doc_no TEXT NOT NULL UNIQUE,
            doc_date TEXT NOT NULL,
            note TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'draft',
            total_items INTEGER NOT NULL DEFAULT 0,
            total_diff REAL NOT NULL DEFAULT 0,
            created_by INTEGER, created_at TEXT,
            posted_by INTEGER, posted_at TEXT,
            void_reason TEXT DEFAULT '', voided_by INTEGER, voided_at TEXT
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS opname_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            opname_id INTEGER NOT NULL REFERENCES opnames(id) ON DELETE CASCADE,
            product_id INTEGER NOT NULL REFERENCES products(id),
            qty_system REAL NOT NULL DEFAULT 0,
            qty_counted REAL NOT NULL DEFAULT 0,
            diff REAL NOT NULL DEFAULT 0,
            note TEXT DEFAULT ''
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS returns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            doc_no TEXT NOT NULL UNIQUE,
            doc_date TEXT NOT NULL,
            type TEXT NOT NULL,
            party TEXT DEFAULT '',
            ref_doc_no TEXT DEFAULT '',
            note TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'draft',
            total_qty REAL NOT NULL DEFAULT 0,
            total_amount REAL NOT NULL DEFAULT 0,
            created_by INTEGER, created_at TEXT,
            posted_by INTEGER, posted_at TEXT,
            void_reason TEXT DEFAULT '', voided_by INTEGER, voided_at TEXT
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS return_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            return_id INTEGER NOT NULL REFERENCES returns(id) ON DELETE CASCADE,
            product_id INTEGER NOT NULL REFERENCES products(id),
            qty REAL NOT NULL DEFAULT 0,
            unit_price REAL NOT NULL DEFAULT 0,
            subtotal REAL NOT NULL DEFAULT 0,
            note TEXT DEFAULT ''
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS ledger (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            move_date TEXT NOT NULL,
            product_id INTEGER NOT NULL REFERENCES products(id),
            qty_change REAL NOT NULL DEFAULT 0,
            qty_after REAL NOT NULL DEFAULT 0,
            unit_cost REAL NOT NULL DEFAULT 0,
            ref_type TEXT NOT NULL,
            ref_id INTEGER,
            ref_no TEXT DEFAULT '',
            note TEXT DEFAULT '',
            user_id INTEGER,
            created_at TEXT
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS counters (
            k TEXT PRIMARY KEY,
            v INTEGER NOT NULL DEFAULT 0
        )");

        $pdo->exec("CREATE TABLE IF NOT EXISTS activity_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            username TEXT DEFAULT '',
            action TEXT NOT NULL,
            detail TEXT DEFAULT '',
            ref_type TEXT DEFAULT '',
            ref_no TEXT DEFAULT '',
            created_at TEXT
        )");

        /* FIFO: setiap penerimaan barang membentuk satu lapisan (layer) dengan harga
           satuannya sendiri. Barang keluar memakai lapisan tertua lebih dulu. */
        $pdo->exec("CREATE TABLE IF NOT EXISTS stock_layers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
            move_date TEXT NOT NULL,
            ledger_id INTEGER,
            ref_type TEXT NOT NULL DEFAULT '',
            ref_id INTEGER,
            ref_no TEXT DEFAULT '',
            qty_original REAL NOT NULL DEFAULT 0,
            qty_remaining REAL NOT NULL DEFAULT 0,
            unit_cost REAL NOT NULL DEFAULT 0,
            created_at TEXT
        )");

        /* Pemakaian lapisan oleh barang keluar: inilah HPP (FIFO) tiap penjualan. */
        $pdo->exec("CREATE TABLE IF NOT EXISTS layer_uses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            layer_id INTEGER NOT NULL REFERENCES stock_layers(id) ON DELETE CASCADE,
            product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
            ledger_id INTEGER,
            move_date TEXT NOT NULL,
            ref_type TEXT NOT NULL DEFAULT '',
            ref_id INTEGER,
            ref_no TEXT DEFAULT '',
            qty REAL NOT NULL DEFAULT 0,
            unit_cost REAL NOT NULL DEFAULT 0,
            total_cost REAL NOT NULL DEFAULT 0,
            created_at TEXT
        )");

        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_layers_product ON stock_layers(product_id, id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_layer_uses_ref ON layer_uses(ref_type, ref_id)");
        /* Pengaturan aplikasi (kunci-nilai): dipakai fitur laporan email. */
        $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
            k TEXT PRIMARY KEY,
            v TEXT NOT NULL DEFAULT ''
        )");

        /* Riwayat pengiriman laporan: mencegah laporan terkirim dua kali untuk periode yang sama. */
        $pdo->exec("CREATE TABLE IF NOT EXISTS report_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            period_key TEXT NOT NULL,
            period_from TEXT DEFAULT '',
            period_to TEXT DEFAULT '',
            period_label TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'sent',
            recipients INTEGER NOT NULL DEFAULT 0,
            detail TEXT DEFAULT '',
            created_at TEXT
        )");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_report_log ON report_log(type, period_key, status)");

        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_ledger_product ON ledger(product_id, id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_ledger_date ON ledger(move_date)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_ledger_ref ON ledger(ref_type, ref_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_inbound_items_doc ON inbound_items(inbound_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_outbound_items_doc ON outbound_items(outbound_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_adj_items_doc ON adjustment_items(adjustment_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_opname_items_doc ON opname_items(opname_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_return_items_doc ON return_items(return_id)");

        $pdo->prepare("INSERT OR IGNORE INTO counters(k, v) VALUES ('inbound', 0)")->execute();
        $pdo->prepare("INSERT OR IGNORE INTO counters(k, v) VALUES ('outbound', 0)")->execute();
        $pdo->prepare("INSERT OR IGNORE INTO counters(k, v) VALUES ('adjustment', 0)")->execute();
        $pdo->prepare("INSERT OR IGNORE INTO counters(k, v) VALUES ('opname', 0)")->execute();
        $pdo->prepare("INSERT OR IGNORE INTO counters(k, v) VALUES ('return', 0)")->execute();

        /* Migrasi: identitas produk cukup SKU, jadi kolom "name" dihapus bila masih ada
           (database lama). Kalau versi SQLite belum mendukung DROP COLUMN, kolom dibiarkan
           dan tetap diisi dengan nilai SKU oleh product_create() supaya tidak melanggar NOT NULL. */
        if (column_exists($pdo, 'products', 'name')) {
            try {
                $pdo->exec('ALTER TABLE products DROP COLUMN name');
            } catch (Throwable $e) {
                // sengaja dibiarkan: product_create() menangani kolom yang masih ada
            }
        }

        /* Migrasi: diskon dokumen barang masuk + harga satuan setelah diskon.
           Diskon dibagi proporsional ke setiap baris, jadi tiap SKU punya harga net sendiri. */
        $newDiscountCols = ensure_column($pdo, 'inbounds', 'subtotal_amount', 'REAL NOT NULL DEFAULT 0');
        ensure_column($pdo, 'inbounds', 'discount_type', "TEXT NOT NULL DEFAULT 'percent'");
        ensure_column($pdo, 'inbounds', 'discount_value', 'REAL NOT NULL DEFAULT 0');
        ensure_column($pdo, 'inbounds', 'discount_amount', 'REAL NOT NULL DEFAULT 0');
        $newItemCols = ensure_column($pdo, 'inbound_items', 'discount_share', 'REAL NOT NULL DEFAULT 0');
        ensure_column($pdo, 'inbound_items', 'unit_cost_net', 'REAL NOT NULL DEFAULT 0');
        ensure_column($pdo, 'inbound_items', 'subtotal_net', 'REAL NOT NULL DEFAULT 0');

        if ($newDiscountCols) {
            /* dokumen lama belum mengenal diskon: harga net = harga beli apa adanya */
            $pdo->exec('UPDATE inbounds SET subtotal_amount = total_amount WHERE subtotal_amount = 0 AND total_amount <> 0');
        }
        if ($newItemCols) {
            $pdo->exec('UPDATE inbound_items SET unit_cost_net = unit_cost, subtotal_net = subtotal WHERE unit_cost_net = 0 AND unit_cost <> 0');
            $pdo->exec('UPDATE inbound_items SET subtotal_net = subtotal WHERE subtotal_net = 0 AND subtotal <> 0');
        }

        /* Migrasi: kolom ukuran (size) pada produk */
        ensure_column($pdo, 'products', 'size', "TEXT DEFAULT ''");

        /* POS (aplikasi Kasir): penanda uuid perangkat pada dokumen yang dikirim kasir.
           Dipakai supaya pengiriman ulang (sinkronisasi offline) tidak membuat dokumen ganda. */
        ensure_column($pdo, 'outbounds', 'pos_uuid', "TEXT DEFAULT ''");
        ensure_column($pdo, 'returns', 'pos_uuid', "TEXT DEFAULT ''");

        /* Migrasi FIFO */
        $newInitial = ensure_column($pdo, 'products', 'cost_price_initial', 'REAL NOT NULL DEFAULT 0');
        ensure_column($pdo, 'ledger', 'unit_cost', 'REAL NOT NULL DEFAULT 0');
        ensure_column($pdo, 'outbound_items', 'cogs', 'REAL NOT NULL DEFAULT 0');
        ensure_column($pdo, 'outbound_items', 'cogs_unit', 'REAL NOT NULL DEFAULT 0');
        if ($newInitial) {
            /* database lama belum mengenal HPP awal: pakai HPP yang ada sebagai titik awal */
            $pdo->exec('UPDATE products SET cost_price_initial = cost_price WHERE cost_price_initial = 0');
        }

        /* Migrasi: supplier bukan lagi bagian master produk (ditentukan saat barang masuk),
           jadi kolom products.supplier_id dihapus bila database lama masih memilikinya. */
        if (column_exists($pdo, 'products', 'supplier_id')) {
            try {
                $pdo->exec('ALTER TABLE products DROP COLUMN supplier_id');
            } catch (Throwable $e) {
                // sengaja dibiarkan: kolom lama tidak lagi dipakai aplikasi
            }
        }
    });

    /* Data yang sudah ada sebelum fitur FIFO dipakai: bangun lapisan sekali saja
       supaya halaman langsung menampilkan HPP awal / rata-rata dan HPP barang terjual. */
    /* Nama kunci diberi versi: kalau aturan FIFO diperbaiki, naikkan versinya supaya
       lapisan dihitung ulang sekali lagi dari riwayat dokumen. */
    if (function_exists('fifo_rebuild') && (int)db_scalar("SELECT COUNT(*) FROM counters WHERE k = 'fifo_built_v3'") === 0) {
        try {
            fifo_rebuild();
            db_run("INSERT OR REPLACE INTO counters (k, v) VALUES ('fifo_built_v3', 1)");
        } catch (Throwable $e) {
            /* dibiarkan: akan dicoba lagi pada request berikutnya */
        }
    }

    if ((int)db_scalar('SELECT COUNT(*) FROM users') === 0) {
        db_run(
            'INSERT INTO users (username, name, password_hash, role, active, created_at) VALUES (?,?,?,?,1,?)',
            ['admin', 'Administrator', password_hash('admin123', PASSWORD_DEFAULT), 'admin', now()]
        );
    }
}
