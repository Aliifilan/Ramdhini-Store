<?php
declare(strict_types=1);

/* ============================================================
 * Laporan email: barang terlaris + ringkasan penjualan + stok menipis.
 *
 * Pengiriman memakai layanan Brevo lewat HTTPS (port 443) karena server ini
 * memblokir SMTP biasa (25/465/587). Panggilan HTTP-nya dipisah ke satu fungsi
 * (report_transport_brevo) agar bisa digantikan saat pengujian.
 * ============================================================ */

/** Rentang tanggal laporan untuk satu jenis ('daily'|'weekly'|'monthly'). */
function report_period(string $type): array
{
    $today = new DateTimeImmutable(today());
    if ($type === 'daily') {
        if (setting('report_daily_period') === 'last7') {
            $from = $today->modify('-6 days');
            return [$from->format('Y-m-d'), $today->format('Y-m-d'), '7 hari terakhir'];
        }
        return [$today->format('Y-m-d'), $today->format('Y-m-d'), 'hari ini ' . fmt_date($today->format('Y-m-d'))];
    }
    if ($type === 'weekly') {
        if (setting('report_weekly_period') === 'last7') {
            $from = $today->modify('-6 days');
            return [$from->format('Y-m-d'), $today->format('Y-m-d'), '7 hari terakhir'];
        }
        /* minggu berjalan: Senin sampai hari ini */
        $from = $today->modify('monday this week');
        return [$from->format('Y-m-d'), $today->format('Y-m-d'),
            'minggu ini (' . fmt_date($from->format('Y-m-d')) . ' – ' . fmt_date($today->format('Y-m-d')) . ')'];
    }
    /* monthly */
    if (setting('report_monthly_period') === 'current') {
        $from = $today->modify('first day of this month');
        return [$from->format('Y-m-d'), $today->format('Y-m-d'), 'bulan ini sampai ' . fmt_date($today->format('Y-m-d'))];
    }
    $from = $today->modify('first day of last month');
    $to = $today->modify('last day of last month');
    return [$from->format('Y-m-d'), $to->format('Y-m-d'),
        'bulan ' . $from->format('F Y')];
}

/** Kunci periode: dipakai supaya laporan tidak terkirim dua kali untuk periode yang sama. */
function report_period_key(string $type, string $from, string $to): string
{
    if ($type === 'daily') return 'daily:' . $to;
    if ($type === 'weekly') {
        $d = new DateTimeImmutable($from);
        return 'weekly:' . $d->format('o-W');
    }
    $d = new DateTimeImmutable($from);
    return 'monthly:' . $d->format('Y-m');
}

/** Apakah laporan untuk kunci periode ini sudah pernah terkirim dengan sukses. */
function report_already_sent(string $type, string $periodKey): bool
{
    return (bool)db_scalar(
        "SELECT 1 FROM report_log WHERE type = ? AND period_key = ? AND status = 'sent' LIMIT 1",
        [$type, $periodKey]
    );
}

/** Waktu terjadwal untuk satu jenis laporan pada periode berjalan (null = tidak aktif). */
function report_scheduled_at(string $type): ?int
{
    if ($type === 'daily') {
        if (!setting_bool('report_daily_on')) return null;
        return strtotime(today() . ' ' . setting('report_daily_time', '21:00')) ?: null;
    }
    if ($type === 'weekly') {
        if (!setting_bool('report_weekly_on')) return null;
        $target = max(1, min(7, setting_int('report_weekly_day', 6)));
        $todayDow = (int)date('N');
        $diff = $target - $todayDow;
        $date = date('Y-m-d', strtotime(($diff >= 0 ? '+' : '') . $diff . ' days'));
        return strtotime($date . ' ' . setting('report_weekly_time', '21:00')) ?: null;
    }
    if ($type === 'monthly') {
        if (!setting_bool('report_monthly_on')) return null;
        $day = max(1, min(28, setting_int('report_monthly_day', 1)));
        return strtotime(date('Y-m-') . str_pad((string)$day, 2, '0', STR_PAD_LEFT) . ' ' . setting('report_monthly_time', '21:00')) ?: null;
    }
    return null;
}

/**
 * Jenis laporan yang sudah jatuh tempo tetapi belum terkirim.
 * @param int|null $now waktu acuan (untuk pengujian); null = sekarang
 */
function report_due_types(?int $now = null): array
{
    $now = $now ?? time();
    $due = [];
    foreach (['daily', 'weekly', 'monthly'] as $type) {
        $sched = report_scheduled_at($type);
        if ($sched === null || $now < $sched) continue;
        [$from, $to] = report_period($type);
        $key = report_period_key($type, $from, $to);
        if (report_already_sent($type, $key)) continue;
        $due[] = $type;
    }
    return $due;
}

/* ---------------- isi laporan ---------------- */

/** Data laporan: terlaris, ringkasan, stok menipis. */
function report_data(string $from, string $to): array
{
    $topN = max(1, min(50, setting_int('report_top_n', 10)));
    $lowN = max(1, min(100, setting_int('report_low_stock_n', 15)));

    /* Barang terlaris (dari dokumen barang keluar yang sudah diposting) */
    $top = db_all(
        "SELECT p.id, p.sku, p.unit, COALESCE(b.name,'-') AS brand,
                SUM(i.qty) AS qty, SUM(i.subtotal) AS revenue, SUM(i.cogs) AS cogs,
                COUNT(DISTINCT o.id) AS docs
           FROM outbound_items i
           JOIN outbounds o ON o.id = i.outbound_id
           JOIN products p ON p.id = i.product_id
           LEFT JOIN brands b ON b.id = p.brand_id
          WHERE o.status = 'posted' AND o.doc_date BETWEEN ? AND ?
          GROUP BY p.id
          ORDER BY qty DESC, revenue DESC
          LIMIT " . $topN,
        [$from, $to]
    );

    $summary = db_one(
        "SELECT COUNT(DISTINCT o.id) AS docs,
                COALESCE(SUM(i.qty),0) AS qty,
                COALESCE(SUM(i.subtotal),0) AS revenue,
                COALESCE(SUM(i.cogs),0) AS cogs,
                COUNT(DISTINCT i.product_id) AS skus
           FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
          WHERE o.status = 'posted' AND o.doc_date BETWEEN ? AND ?",
        [$from, $to]
    );

    $purchases = db_one(
        "SELECT COUNT(DISTINCT i.inbound_id) AS docs,
                COALESCE(SUM(i.qty),0) AS qty,
                COALESCE(SUM(COALESCE(NULLIF(i.subtotal_net,0), i.subtotal)),0) AS amount
           FROM inbound_items i JOIN inbounds o ON o.id = i.inbound_id
          WHERE o.status = 'posted' AND o.doc_date BETWEEN ? AND ?",
        [$from, $to]
    );

    $returns = db_all(
        "SELECT o.type, COALESCE(SUM(i.qty),0) AS qty, COALESCE(SUM(i.subtotal),0) AS amount
           FROM return_items i JOIN returns o ON o.id = i.return_id
          WHERE o.status = 'posted' AND o.doc_date BETWEEN ? AND ?
          GROUP BY o.type",
        [$from, $to]
    );

    $lowStock = db_all(
        "SELECT p.id, p.sku, p.unit, p.stock_qty, p.min_stock, COALESCE(b.name,'-') AS brand
           FROM products p LEFT JOIN brands b ON b.id = p.brand_id
          WHERE p.active = 1 AND p.stock_qty <= p.min_stock
          ORDER BY (p.stock_qty - p.min_stock), p.sku
          LIMIT " . $lowN
    );
    $lowCount = (int)db_scalar('SELECT COUNT(*) FROM products WHERE active = 1 AND stock_qty <= min_stock');

    $outOfStock = (int)db_scalar('SELECT COUNT(*) FROM products WHERE active = 1 AND stock_qty <= 0');

    return [
        'from' => $from, 'to' => $to,
        'top' => $top,
        'summary' => $summary,
        'purchases' => $purchases,
        'returns' => $returns,
        'low_stock' => $lowStock,
        'low_count' => $lowCount,
        'out_of_stock' => $outOfStock,
    ];
}

function report_type_label(string $type): string
{
    return ['daily' => 'Harian', 'weekly' => 'Mingguan', 'monthly' => 'Bulanan'][$type] ?? $type;
}

function report_subject(string $type, array $data): string
{
    $sold = (float)($data['summary']['qty'] ?? 0);
    return 'Inventori ' . APP_OWNER . ': Laporan ' . report_type_label($type) . ' '
        . fmt_date($data['from']) . ' – ' . fmt_date($data['to'])
        . ' (terjual ' . fmt_num($sold, 0) . ' unit, stok menipis ' . (int)$data['low_count'] . ')';
}

/* ---------------- versi teks & HTML ---------------- */

function report_text(string $type, array $d): string
{
    $s = $d['summary'];
    $revenue = (float)($s['revenue'] ?? 0);
    $cogs = (float)($s['cogs'] ?? 0);
    $lines = [];
    $lines[] = 'LAPORAN ' . strtoupper(report_type_label($type)) . ' INVENTORI — ' . APP_OWNER;
    $lines[] = 'Periode: ' . fmt_date($d['from']) . ' sampai ' . fmt_date($d['to']);
    $lines[] = str_repeat('=', 46);
    $lines[] = '';
    $lines[] = 'RINGKASAN PENJUALAN';
    $lines[] = '  Dokumen barang keluar : ' . fmt_num($s['docs'] ?? 0);
    $lines[] = '  Unit terjual          : ' . fmt_qty($s['qty'] ?? 0);
    $lines[] = '  Nilai penjualan       : ' . fmt_money($revenue);
    $lines[] = '  HPP (FIFO)            : ' . fmt_money($cogs);
    $lines[] = '  Laba kotor            : ' . fmt_money($revenue - $cogs);
    $lines[] = '  SKU terjual           : ' . fmt_num($s['skus'] ?? 0);
    $lines[] = '';
    $lines[] = 'PEMBELIAN';
    $lines[] = '  Dokumen barang masuk  : ' . fmt_num($d['purchases']['docs'] ?? 0);
    $lines[] = '  Unit masuk            : ' . fmt_qty($d['purchases']['qty'] ?? 0);
    $lines[] = '  Nilai pembelian       : ' . fmt_money($d['purchases']['amount'] ?? 0);
    if ($d['returns']) {
        $lines[] = '';
        $lines[] = 'RETUR';
        foreach ($d['returns'] as $r) {
            $lines[] = '  ' . ($r['type'] === 'supplier' ? 'Ke supplier' : 'Dari customer') . ': '
                . fmt_qty($r['qty']) . ' unit / ' . fmt_money($r['amount']);
        }
    }
    $lines[] = '';
    $lines[] = 'BARANG TERLARIS';
    if (!$d['top']) {
        $lines[] = '  (belum ada penjualan pada periode ini)';
    }
    $i = 0;
    foreach ($d['top'] as $t) {
        $i++;
        $lines[] = sprintf('  %2d. %-18s %s %s  %s unit  %s', $i, $t['sku'],
            $t['brand'] !== '-' ? '(' . $t['brand'] . ')' : '', '',
            fmt_qty($t['qty']), fmt_money($t['revenue']));
    }
    $lines[] = '';
    $lines[] = 'STOK MENIPIS (' . (int)$d['low_count'] . ' SKU, habis: ' . (int)$d['out_of_stock'] . ')';
    if (!$d['low_stock']) {
        $lines[] = '  (semua stok aman)';
    }
    foreach ($d['low_stock'] as $l) {
        $lines[] = sprintf('  %-18s sisa %s %s (min %s)', $l['sku'],
            fmt_qty($l['stock_qty']), $l['unit'], fmt_qty($l['min_stock']));
    }
    $lines[] = '';
    $lines[] = 'Dikirim otomatis oleh aplikasi Inventori.';
    return implode("\n", $lines);
}

function report_html(string $type, array $d): string
{
    $s = $d['summary'];
    $revenue = (float)($s['revenue'] ?? 0);
    $cogs = (float)($s['cogs'] ?? 0);
    $profit = $revenue - $cogs;

    $e = static fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    $th = 'padding:8px 10px;text-align:left;font-size:11px;letter-spacing:.04em;text-transform:uppercase;color:#635F82;border-bottom:1px solid #E7E4F5;';
    $td = 'padding:8px 10px;font-size:13px;border-bottom:1px solid #F1EEFA;';
    $num = $td . 'text-align:right;font-variant-numeric:tabular-nums;';
    $numH = $th . 'text-align:right;';
    $badge = 'display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;';

    $rows = '';
    $i = 0;
    foreach ($d['top'] as $t) {
        $i++;
        $medal = $i <= 3 ? '#' . $i . ' ' : $i . '. ';
        $rows .= '<tr>'
            . '<td style="' . $td . '">' . $medal . '<strong>' . $e($t['sku']) . '</strong>'
            . ($t['brand'] !== '-' ? '<br><span style="color:#8B87A6;font-size:11.5px">' . $e($t['brand']) . '</span>' : '')
            . '</td>'
            . '<td style="' . $num . '"><strong>' . fmt_qty($t['qty']) . '</strong> <span style="color:#8B87A6">' . $e($t['unit']) . '</span></td>'
            . '<td style="' . $num . '">' . fmt_money($t['revenue']) . '</td>'
            . '<td style="' . $num . '">' . fmt_money((float)$t['revenue'] - (float)$t['cogs']) . '</td>'
            . '<td style="' . $num . '">' . fmt_num($t['docs']) . '</td>'
            . '</tr>';
    }
    if (!$d['top']) {
        $rows = '<tr><td colspan="5" style="' . $td . 'color:#8B87A6">Belum ada penjualan pada periode ini.</td></tr>';
    }

    $lowRows = '';
    foreach ($d['low_stock'] as $l) {
        $habis = (float)$l['stock_qty'] <= 0;
        $lowRows .= '<tr>'
            . '<td style="' . $td . '"><strong>' . $e($l['sku']) . '</strong>'
            . ($l['brand'] !== '-' ? ' <span style="color:#8B87A6;font-size:11.5px">' . $e($l['brand']) . '</span>' : '')
            . '</td>'
            . '<td style="' . $num . ($habis ? 'color:#DC2626;font-weight:700' : 'color:#B45309;font-weight:600') . '">'
            . fmt_qty($l['stock_qty']) . ' ' . $e($l['unit']) . '</td>'
            . '<td style="' . $num . '">' . fmt_qty($l['min_stock']) . '</td>'
            . '<td style="' . $td . '">' . ($habis
                ? '<span style="' . $badge . 'background:rgba(220,38,38,.1);color:#DC2626">HABIS</span>'
                : '<span style="' . $badge . 'background:rgba(245,158,11,.16);color:#B45309">MENIPIS</span>') . '</td>'
            . '</tr>';
    }
    if (!$d['low_stock']) {
        $lowRows = '<tr><td colspan="4" style="' . $td . 'color:#059669">Semua stok aman. Tidak ada produk di bawah batas minimum.</td></tr>';
    }

    $returRows = '';
    foreach ($d['returns'] as $r) {
        $returRows .= '<tr><td style="' . $td . '">' . ($r['type'] === 'supplier' ? 'Ke supplier' : 'Dari customer') . '</td>'
            . '<td style="' . $num . '">' . fmt_qty($r['qty']) . '</td>'
            . '<td style="' . $num . '">' . fmt_money($r['amount']) . '</td></tr>';
    }

    $box = 'background:#FFFFFF;border:1px solid #E7E4F5;border-radius:12px;padding:16px 18px;margin:0 0 16px;';
    $statLabel = 'font-size:11px;letter-spacing:.05em;text-transform:uppercase;color:#635F82;font-weight:600;display:block;';
    $statValue = 'font-size:19px;font-weight:700;color:#1F1B3A;display:block;margin-top:2px;';

    return '<!DOCTYPE html><html><head><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width,initial-scale=1"></head>'
        . '<body style="margin:0;padding:18px;background:#F3F0FF;font-family:Inter,-apple-system,Segoe UI,Roboto,Arial,sans-serif;color:#1F1B3A;">'
        . '<div style="max-width:680px;margin:0 auto;">'
        . '<div style="background:linear-gradient(135deg,#4F46E5,#8B5CF6);border-radius:14px;padding:18px 20px;color:#fff;margin-bottom:16px;">'
        . '<div style="font-size:12px;letter-spacing:.06em;text-transform:uppercase;opacity:.9">' . $e(APP_OWNER) . ' Inventori</div>'
        . '<div style="font-size:19px;font-weight:700;margin-top:4px">Laporan ' . report_type_label($type) . ' Barang Terlaris</div>'
        . '<div style="font-size:13px;opacity:.95;margin-top:4px">Periode ' . fmt_date($d['from']) . ' &ndash; ' . fmt_date($d['to']) . '</div>'
        . '</div>'

        . '<div style="' . $box . '">'
        . '<table style="width:100%;border-collapse:collapse"><tr>'
        . '<td style="padding:0 8px 0 0;width:25%"><span style="' . $statLabel . '">Unit terjual</span><span style="' . $statValue . '">' . fmt_qty($s['qty'] ?? 0) . '</span></td>'
        . '<td style="padding:0 8px;width:25%"><span style="' . $statLabel . '">Nilai penjualan</span><span style="' . $statValue . '">' . fmt_money($revenue) . '</span></td>'
        . '<td style="padding:0 8px;width:25%"><span style="' . $statLabel . '">HPP (FIFO)</span><span style="' . $statValue . '">' . fmt_money($cogs) . '</span></td>'
        . '<td style="padding:0 0 0 8px;width:25%"><span style="' . $statLabel . '">Laba kotor</span><span style="' . $statValue . '">' . fmt_money($profit) . '</span></td>'
        . '</tr></table>'
        . '<div style="margin-top:10px;font-size:12px;color:#635F82">'
        . fmt_num($s['docs'] ?? 0) . ' dokumen barang keluar &middot; ' . fmt_num($s['skus'] ?? 0) . ' SKU terjual &middot; '
        . 'pembelian ' . fmt_money($d['purchases']['amount'] ?? 0) . ' (' . fmt_qty($d['purchases']['qty'] ?? 0) . ' unit masuk)'
        . '</div></div>'

        . '<div style="' . $box . '">'
        . '<div style="font-size:14px;font-weight:700;margin-bottom:10px">Barang Terlaris</div>'
        . '<table style="width:100%;border-collapse:collapse">'
        . '<thead><tr><th style="' . $th . '">SKU</th><th style="' . $numH . '">Terjual</th>'
        . '<th style="' . $numH . '">Nilai Jual</th><th style="' . $numH . '">Laba Kotor</th><th style="' . $numH . '">Dokumen</th></tr></thead>'
        . '<tbody>' . $rows . '</tbody></table></div>'

        . '<div style="' . $box . '">'
        . '<div style="font-size:14px;font-weight:700;margin-bottom:10px">Stok Menipis '
        . '<span style="font-weight:400;color:#635F82;font-size:12.5px">(' . (int)$d['low_count'] . ' SKU &middot; habis: ' . (int)$d['out_of_stock'] . ')</span></div>'
        . '<table style="width:100%;border-collapse:collapse">'
        . '<thead><tr><th style="' . $th . '">SKU</th><th style="' . $numH . '">Stok</th>'
        . '<th style="' . $numH . '">Minimum</th><th style="' . $th . '">Status</th></tr></thead>'
        . '<tbody>' . $lowRows . '</tbody></table></div>'

        . ($returRows !== '' ? '<div style="' . $box . '">'
            . '<div style="font-size:14px;font-weight:700;margin-bottom:10px">Retur</div>'
            . '<table style="width:100%;border-collapse:collapse">'
            . '<thead><tr><th style="' . $th . '">Jenis</th><th style="' . $numH . '">Qty</th><th style="' . $numH . '">Nilai</th></tr></thead>'
            . '<tbody>' . $returRows . '</tbody></table></div>' : '')

        . '<div style="font-size:11.5px;color:#8B87A6;text-align:center;padding:6px 0 2px">'
        . 'Email otomatis dari aplikasi Inventori ' . $e(APP_OWNER) . ' &middot; dikirim ' . e(now()) . ' WIB</div>'
        . '</div></body></html>';
}

/* ---------------- pengiriman ---------------- */

/**
 * Panggilan HTTPS ke API Brevo. Dipisah agar bisa diganti tiruan saat pengujian.
 * @return array{ok:bool, status:int, body:string, error:string}
 */
function report_transport_brevo(string $apiKey, array $payload): array
{
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    $ctx = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/json\r\naccept: application/json\r\napi-key: " . $apiKey . "\r\n",
            'content' => $json,
            'timeout' => 20,
            'ignore_errors' => true,
        ],
    ]);
    $body = @file_get_contents('https://api.brevo.com/v3/smtp/email', false, $ctx);
    $status = 0;
    if (isset($http_response_header) && is_array($http_response_header)) {
        foreach ($http_response_header as $h) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $h, $m)) $status = (int)$m[1];
        }
    }
    if ($body === false && $status === 0) {
        return ['ok' => false, 'status' => 0, 'body' => '', 'error' => 'Tidak bisa menghubungi Brevo (jaringan/timeout).'];
    }
    $ok = $status >= 200 && $status < 300;
    $err = '';
    if (!$ok) {
        $decoded = json_decode((string)$body, true);
        $err = is_array($decoded) && isset($decoded['message'])
            ? (string)$decoded['message']
            : ('HTTP ' . $status . ' dari Brevo.');
    }
    return ['ok' => $ok, 'status' => $status, 'body' => (string)$body, 'error' => $err];
}

/**
 * Kirim satu laporan.
 * @param callable|null $transport pengganti pengiriman (untuk pengujian)
 * @param bool $force kirim walau periode ini sudah pernah terkirim (tetap dicatat)
 * @return array{ok:bool, message:string, type:string, period:string, recipients:int}
 */
function report_send(string $type, bool $force = false, ?callable $transport = null): array
{
    $type = in_array($type, ['daily', 'weekly', 'monthly'], true) ? $type : 'daily';
    [$from, $to, $label] = report_period($type);
    $key = report_period_key($type, $from, $to);

    if (!$force && report_already_sent($type, $key)) {
        return ['ok' => false, 'message' => 'Laporan ' . $label . ' sudah pernah terkirim.', 'type' => $type, 'period' => $label, 'recipients' => 0];
    }

    $problems = report_readiness_problems();
    if ($problems) {
        $msg = 'Pengaturan laporan belum lengkap: ' . implode(' ', $problems);
        setting_save('report_last_error', $msg . ' (' . now() . ')');
        return ['ok' => false, 'message' => $msg, 'type' => $type, 'period' => $label, 'recipients' => 0];
    }

    $data = report_data($from, $to);
    $recipients = report_recipients();
    $payload = [
        'sender' => [
            'email' => (string)setting('report_sender_email'),
            'name' => (string)setting('report_sender_name', APP_OWNER),
        ],
        'to' => array_map(static fn($m) => ['email' => $m], $recipients),
        'subject' => report_subject($type, $data),
        'htmlContent' => report_html($type, $data),
        'textContent' => report_text($type, $data),
        'tags' => ['inventori', $type],
    ];
    /* balasan ke pengirim supaya staf bisa langsung membalas */
    if (filter_var((string)setting('report_sender_email'), FILTER_VALIDATE_EMAIL)) {
        $payload['replyTo'] = ['email' => (string)setting('report_sender_email')];
    }

    if ($transport === null) {
        $transport = static fn(array $p) => report_transport_brevo((string)setting('report_brevo_key'), $p);
    }
    $res = $transport($payload);

    db_run(
        'INSERT INTO report_log (type, period_key, period_from, period_to, period_label, status, recipients, detail, created_at)
         VALUES (?,?,?,?,?,?,?,?,?)',
        [$type, $key, $from, $to, $label, $res['ok'] ? 'sent' : 'failed', count($recipients),
         $res['ok'] ? ('terkirim ke ' . count($recipients) . ' alamat') : (string)$res['error'], now()]
    );

    if (!$res['ok']) {
        setting_save('report_last_error', $res['error'] . ' (' . now() . ')');
        return ['ok' => false, 'message' => 'Gagal mengirim: ' . $res['error'], 'type' => $type, 'period' => $label, 'recipients' => count($recipients)];
    }

    setting_save('report_last_error', '');
    log_activity('report', 'Kirim laporan ' . report_type_label($type) . ' ke ' . count($recipients) . ' alamat (' . $label . ')', 'report', $key);

    return [
        'ok' => true,
        'message' => 'Laporan ' . report_type_label($type) . ' terkirim ke ' . count($recipients) . ' alamat.',
        'type' => $type, 'period' => $label, 'recipients' => count($recipients),
    ];
}

/** Kirim semua laporan yang sudah jatuh tempo (dipakai pemeriksaan otomatis & cron). */
function report_send_due(?int $now = null): array
{
    $results = [];
    foreach (report_due_types($now) as $type) {
        $results[] = report_send($type);
    }
    return $results;
}

/**
 * Pemeriksaan otomatis pada saat aplikasi dibuka.
 * Karena server ini tidak punya penjadwal, ini yang membuat laporan tetap terkirim
 * walau cron tidak dipasang. Dibatasi sekali per 10 menit agar tidak membebani.
 */
function report_auto_check(): void
{
    if (!report_ready()) return;
    $last = (string)setting('report_last_check', '');
    if ($last !== '' && (time() - (int)strtotime($last)) < 600) return;
    setting_save('report_last_check', now());
    report_send_due();
}

/** Riwayat pengiriman terakhir. */
function report_history(int $limit = 25): array
{
    return db_all('SELECT * FROM report_log ORDER BY id DESC LIMIT ' . max(1, min(100, $limit)));
}
