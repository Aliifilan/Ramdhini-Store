<?php
declare(strict_types=1);

/* ============================================================
 * Pengaturan aplikasi (kunci-nilai) — dipakai fitur laporan email.
 * Nilai disimpan di tabel `settings` agar bisa diubah dari aplikasi.
 * ============================================================ */

function settings_defaults(): array
{
    return [
        // pengirim (harus alamat yang sudah diverifikasi di Brevo)
        'report_sender_email' => '',
        'report_sender_name' => APP_OWNER . ' Inventori',
        // kunci API Brevo (disimpan di database aplikasi, tidak pernah dikirim ke browser)
        'report_brevo_key' => '',
        // daftar penerima: satu alamat per baris
        'report_recipients' => '',
        // jenis laporan & jadwal
        'report_daily_on' => '1',
        'report_daily_time' => '21:00',
        'report_weekly_on' => '1',
        'report_weekly_day' => '6',   // 1=Senin ... 7=Minggu
        'report_weekly_time' => '21:00',
        'report_monthly_on' => '1',
        'report_monthly_day' => '1',
        'report_monthly_time' => '21:00',
        // periode yang dilaporkan
        'report_daily_period' => 'today',      // today | last7
        'report_weekly_period' => 'week',      // week (Senin–hari ini) | last7
        'report_monthly_period' => 'last',     // last (bulan lalu) | current (bulan berjalan)
        // isi laporan
        'report_top_n' => '10',
        'report_low_stock_n' => '15',
        // token rahasia untuk pemanggilan cron
        'report_cron_token' => '',
        // pemeriksaan otomatis terakhir (agar tidak diperiksa berulang pada tiap request)
        'report_last_check' => '',
        // catatan kegagalan terakhir (ditampilkan di halaman pengaturan)
        'report_last_error' => '',
    ];
}

/** Cache pengaturan dalam memori (satu kali baca per request). */
function settings_cache(bool $reload = false): array
{
    static $cache = null;
    if ($cache === null || $reload) {
        $cache = [];
        foreach (db_all('SELECT k, v FROM settings') as $row) {
            $cache[(string)$row['k']] = (string)$row['v'];
        }
    }
    return $cache;
}

function setting(string $key, $default = null)
{
    $cache = settings_cache();
    if (array_key_exists($key, $cache)) return $cache[$key];
    $defaults = settings_defaults();
    return $default ?? ($defaults[$key] ?? '');
}

function setting_bool(string $key): bool
{
    return setting($key, '0') === '1';
}

function setting_int(string $key, int $default = 0): int
{
    $v = setting($key, (string)$default);
    return is_numeric($v) ? (int)$v : $default;
}

function setting_save(string $key, string $value): void
{
    db_run(
        'INSERT INTO settings (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v',
        [$key, (string)$value]
    );
    settings_cache(true);   // muat ulang supaya perubahan langsung terpakai
}

/** Daftar penerima laporan (satu alamat per baris / dipisah koma), sudah divalidasi. */
function report_recipients(): array
{
    $raw = (string)setting('report_recipients', '');
    $out = [];
    foreach (preg_split('/[\r\n,;]+/', $raw) ?: [] as $line) {
        $email = trim($line);
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) continue;
        $out[strtolower($email)] = $email;
    }
    return array_values($out);
}

/** Alamat yang diketik tapi formatnya salah (ditampilkan sebagai peringatan). */
function report_invalid_recipients(): array
{
    $bad = [];
    foreach (preg_split('/[\r\n,;]+/', (string)setting('report_recipients', '')) ?: [] as $line) {
        $email = trim($line);
        if ($email === '') continue;
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $bad[] = $email;
    }
    return $bad;
}

/** Token rahasia untuk endpoint cron (dibuat otomatis bila belum ada / minta token baru). */
function report_cron_token(bool $regenerate = false): string
{
    $token = (string)setting('report_cron_token', '');
    if ($regenerate || strlen($token) < 32) {
        $token = bin2hex(random_bytes(20));
        setting_save('report_cron_token', $token);
    }
    return $token;
}

/** Apakah fitur laporan email sudah siap dipakai (kunci API + pengirim + penerima). */
function report_ready(): bool
{
    return trim((string)setting('report_brevo_key')) !== ''
        && filter_var((string)setting('report_sender_email'), FILTER_VALIDATE_EMAIL) !== false
        && count(report_recipients()) > 0;
}

/**
 * Hal-hal yang MEMBUAT laporan belum bisa dikirim (menghalangi pengiriman).
 * Catatan: alamat penerima yang salah format TIDAK menghalangi — alamat itu hanya
 * diabaikan sementara alamat lain tetap menerima laporan (lihat report_warnings()).
 */
function report_readiness_problems(): array
{
    $p = [];
    if (trim((string)setting('report_brevo_key')) === '') $p[] = 'Kunci API Brevo belum diisi.';
    if (!filter_var((string)setting('report_sender_email'), FILTER_VALIDATE_EMAIL)) $p[] = 'Email pengirim belum diisi / formatnya salah.';
    if (count(report_recipients()) === 0) $p[] = 'Belum ada alamat penerima yang valid.';
    return $p;
}

/** Catatan yang tidak menghalangi pengiriman, tapi perlu diketahui Admin. */
function report_warnings(): array
{
    $w = [];
    if ($bad = report_invalid_recipients()) {
        $w[] = 'Alamat berikut formatnya salah dan akan diabaikan: ' . implode(', ', $bad)
            . '. Laporan tetap dikirim ke alamat lain yang valid.';
    }
    if (setting_bool('report_brevo_key') && !report_ready()) {
        // tidak mungkin terjadi, penjaga tambahan
        $w[] = 'Pengaturan belum lengkap.';
    }
    return $w;
}
