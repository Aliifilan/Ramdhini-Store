<?php
declare(strict_types=1);

/* ============================================================
 * Export Excel (.xlsx) — dipakai oleh export.php
 * Nama kolom dibuat sama dengan template import supaya hasil
 * export bisa langsung dipakai ulang untuk import (round-trip).
 * ============================================================ */

function export_datasets(): array
{
    return [
        'products' => 'Produk Master',
        'brands' => 'Brand',
        'suppliers' => 'Supplier',
        'users' => 'Pengguna',
        'stock' => 'Stok Total + arus masuk/keluar',
        'sku_history' => 'Riwayat Inbound & Outbound per SKU',
        'stock_brand' => 'Stok per Brand',
        'daily_stock' => 'Daily Stock All Brand',
        'ledger' => 'Kartu Stok / Mutasi',
        'fifo_layers' => 'Lapisan Stok FIFO (sisa per penerimaan)',
        'layer_uses' => 'HPP FIFO Barang Terjual (rincian lapisan)',
        'inbound' => 'Barang Masuk (header)',
        'inbound_items' => 'Barang Masuk (detail item)',
        'outbound' => 'Barang Keluar (header)',
        'outbound_items' => 'Barang Keluar (detail item)',
        'adjustments' => 'Stok Adjustment (header)',
        'adjustment_items' => 'Stok Adjustment (detail item)',
        'opnames' => 'Stok Opname (header)',
        'opname_items' => 'Stok Opname (detail item)',
        'returns' => 'Retur (header)',
        'return_items' => 'Retur (detail item)',
        'activity' => 'Log Aktivitas',
        'rekap_ringkas' => 'Rekap Ringkas (semua angka utama)',
    ];
}

function export_templates(): array
{
    return [
        'brands' => ['code', 'name', 'description', 'active'],
        'suppliers' => ['code', 'name', 'contact_person', 'phone', 'email', 'address', 'active'],
        'products' => ['sku', 'brand_code', 'category', 'size', 'unit', 'cost_price', 'sell_price', 'min_stock', 'active'],
        'opening' => ['sku', 'qty', 'cost_price', 'move_date', 'note'],
        'inbound' => ['doc_no', 'doc_date', 'supplier_code', 'sku', 'qty', 'unit_cost', 'note', 'status', 'discount_type', 'discount_value'],
        'outbound' => ['doc_no', 'doc_date', 'destination', 'channel', 'sku', 'qty', 'unit_price', 'note', 'status'],
        'returns' => ['doc_no', 'doc_date', 'type', 'party', 'ref_doc_no', 'sku', 'qty', 'price', 'note', 'status'],
    ];
}

/**
 * Jalankan export: kirim header CSV langsung ke output.
 * $f = filter dari query string (from, to, q, status, brand_id, dst)
 */
function export_run(string $type, array $f): void
{
    if (str_starts_with($type, 'template_')) {
        $key = substr($type, 9);
        $tpl = export_templates()[$key] ?? null;
        if (!$tpl) {
            http_response_code(400);
            exit('Template tidak dikenal.');
        }
        xlsx_send('template_' . $key, $tpl, []);
        return;
    }

    $from = $f['from'] ?? date('Y-m-d', strtotime('-30 days'));
    $to = $f['to'] ?? date('Y-m-d');
    $status = $f['status'] ?? '';

    switch ($type) {
        case 'products':
            xlsx_send('produk-master-' . date('Ymd'),
                ['sku', 'brand_code', 'brand_name', 'category', 'size', 'unit', 'hpp_awal', 'hpp_rata_rata', 'sell_price', 'min_stock', 'stock_qty', 'stock_value', 'umur_hari', 'terdaftar_pada', 'active'],
                db_all("SELECT p.sku, b.code AS brand_code, b.name AS brand_name,
                               p.category, p.size, p.unit,
                               COALESCE(NULLIF(p.cost_price_initial,0), p.cost_price) AS hpp_awal,
                               p.cost_price AS hpp_rata_rata, p.sell_price, p.min_stock, p.stock_qty,
                               (p.stock_qty * p.cost_price) AS stock_value,
                               MAX(0, CAST(julianday('now') - julianday(p.created_at) AS INTEGER)) AS umur_hari,
                               substr(p.created_at, 1, 10) AS terdaftar_pada, p.active
                          FROM products p LEFT JOIN brands b ON b.id = p.brand_id
                         ORDER BY p.sku"));
            break;

        case 'brands':
            xlsx_send('brand-' . date('Ymd'),
                ['code', 'name', 'description', 'active', 'jumlah_produk', 'total_stok', 'nilai_stok'],
                db_all("SELECT b.code, b.name, b.description, b.active,
                               (SELECT COUNT(*) FROM products p WHERE p.brand_id = b.id) AS jumlah_produk,
                               (SELECT COALESCE(SUM(p.stock_qty),0) FROM products p WHERE p.brand_id = b.id) AS total_stok,
                               (SELECT COALESCE(SUM(p.stock_qty*p.cost_price),0) FROM products p WHERE p.brand_id = b.id) AS nilai_stok
                          FROM brands b ORDER BY b.name"));
            break;

        case 'suppliers':
            xlsx_send('supplier-' . date('Ymd'),
                ['code', 'name', 'contact_person', 'phone', 'email', 'address', 'active'],
                db_all('SELECT code, name, contact_person, phone, email, address, active FROM suppliers ORDER BY name'));
            break;

        case 'users':
            xlsx_send('pengguna-' . date('Ymd'),
                ['username', 'name', 'role', 'active', 'created_at'],
                db_all('SELECT username, name, role, active, created_at FROM users ORDER BY name'));
            break;

        case 'stock':
            xlsx_send('stok-total-' . date('Ymd'),
                ['sku', 'brand', 'category', 'size', 'unit', 'stock_qty', 'min_stock', 'hpp_awal', 'hpp_rata_rata', 'sell_price', 'stock_value',
                 'umur_hari', 'qty_masuk_total', 'qty_keluar_total', 'putaran_total', 'tercatat_sejak',
                 'qty_masuk_periode', 'qty_terjual_periode', 'nilai_terjual_periode', 'hpp_fifo_terjual', 'laba_kotor_periode', 'status'],
                db_all("SELECT p.sku, COALESCE(b.name,'-') AS brand, p.category, p.size, p.unit, p.stock_qty, p.min_stock,
                               COALESCE(NULLIF(p.cost_price_initial,0), p.cost_price) AS hpp_awal,
                               p.cost_price AS hpp_rata_rata, p.sell_price, (p.stock_qty*p.cost_price) AS stock_value,
                               MAX(0, CAST(julianday('now') - julianday(p.created_at) AS INTEGER)) AS umur_hari,
                               COALESCE(mt.qty_in,0) AS qty_masuk_total,
                               COALESCE(st.qty,0) AS qty_keluar_total,
                               (COALESCE(mt.qty_in,0) + COALESCE(st.qty,0)) AS putaran_total,
                               mt.first_in AS tercatat_sejak,
                               COALESCE(m.qty_in,0) AS qty_masuk_periode,
                               COALESCE(s.qty,0) AS qty_terjual_periode,
                               COALESCE(s.amount,0) AS nilai_terjual_periode,
                               COALESCE(s.cogs,0) AS hpp_fifo_terjual,
                               COALESCE(s.amount,0) - COALESCE(s.cogs,0) AS laba_kotor_periode,
                               CASE WHEN p.stock_qty <= p.min_stock THEN 'MENIPIS' ELSE 'AMAN' END AS status
                          FROM products p LEFT JOIN brands b ON b.id = p.brand_id
                          LEFT JOIN (SELECT l.product_id,
                                            SUM(CASE WHEN REPLACE(l.ref_type,'_void','') IN ('inbound','return_customer','opening') THEN l.qty_change ELSE 0 END) AS qty_in,
                                            MIN(CASE WHEN l.qty_change > 0 THEN l.move_date END) AS first_in
                                       FROM ledger l GROUP BY l.product_id) mt ON mt.product_id = p.id
                          LEFT JOIN (SELECT i.product_id, SUM(i.qty) AS qty
                                       FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
                                      WHERE o.status = 'posted' GROUP BY i.product_id) st ON st.product_id = p.id
                          LEFT JOIN (SELECT l.product_id,
                                            SUM(CASE WHEN REPLACE(l.ref_type,'_void','') IN ('inbound','return_customer','opening') THEN l.qty_change ELSE 0 END) AS qty_in
                                       FROM ledger l WHERE l.move_date BETWEEN ? AND ? GROUP BY l.product_id) m ON m.product_id = p.id
                          LEFT JOIN (SELECT i.product_id, SUM(i.qty) AS qty, SUM(i.subtotal) AS amount, SUM(i.cogs) AS cogs
                                       FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
                                      WHERE o.status = 'posted' AND o.doc_date BETWEEN ? AND ?
                                      GROUP BY i.product_id) s ON s.product_id = p.id
                          WHERE p.active = 1 ORDER BY p.sku", [$from, $to, $from, $to]));
            break;

        case 'sku_history':
            $pid = (int)($f['product_id'] ?? 0);
            if ($pid <= 0) {
                http_response_code(400);
                exit('Pilih SKU dulu (buka halaman Riwayat SKU lalu export dari sana).');
            }
            $prod = db_one("SELECT p.sku, COALESCE(b.name,'-') AS brand FROM products p LEFT JOIN brands b ON b.id = p.brand_id WHERE p.id = ?", [$pid]);
            if (!$prod) {
                http_response_code(404);
                exit('Produk tidak ditemukan.');
            }
            $inRows = db_all("SELECT o.doc_date, o.doc_no, COALESCE(s.name,'-') AS supplier, o.status,
                                     i.qty, i.unit_cost, i.discount_share, i.unit_cost_net, i.subtotal, i.subtotal_net
                                FROM inbound_items i JOIN inbounds o ON o.id = i.inbound_id
                                LEFT JOIN suppliers s ON s.id = o.supplier_id
                               WHERE i.product_id = ? AND o.doc_date BETWEEN ? AND ?
                               ORDER BY o.doc_date, i.id", [$pid, $from, $to]);
            $outRows = db_all("SELECT o.doc_date, o.doc_no, o.destination, o.channel, o.status,
                                      i.qty, i.unit_price, i.subtotal
                                 FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
                                WHERE i.product_id = ? AND o.doc_date BETWEEN ? AND ?
                                ORDER BY o.doc_date, i.id", [$pid, $from, $to]);
            $sumIn = db_one("SELECT COALESCE(SUM(i.qty),0) AS qty, COALESCE(SUM(COALESCE(NULLIF(i.subtotal_net,0), i.subtotal)),0) AS amount
                               FROM inbound_items i JOIN inbounds o ON o.id = i.inbound_id
                              WHERE i.product_id = ? AND o.status='posted' AND o.doc_date BETWEEN ? AND ?", [$pid, $from, $to]);
            $sumOut = db_one("SELECT COALESCE(SUM(i.qty),0) AS qty, COALESCE(SUM(i.subtotal),0) AS amount
                                FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
                               WHERE i.product_id = ? AND o.status='posted' AND o.doc_date BETWEEN ? AND ?", [$pid, $from, $to]);

            $inSheet = array_map(static fn($r) => [(string)$r['doc_date'], (string)$r['doc_no'], (string)$r['supplier'],
                (float)$r['qty'], (float)$r['unit_cost'], (float)$r['discount_share'],
                (float)($r['unit_cost_net'] ?: $r['unit_cost']),
                (float)($r['subtotal_net'] ?: $r['subtotal']), (string)$r['status']], $inRows);
            $inSheet[] = ['TOTAL MASUK (posted)', '', '', (float)$sumIn['qty'], '', (float)$sumIn['amount'], ''];

            $outSheet = array_map(static fn($r) => [(string)$r['doc_date'], (string)$r['doc_no'], (string)$r['destination'],
                (string)$r['channel'], (float)$r['qty'], (float)$r['unit_price'], (float)$r['subtotal'], (string)$r['status']], $outRows);
            $outSheet[] = ['TOTAL TERJUAL (posted)', '', '', '', (float)$sumOut['qty'], '', (float)$sumOut['amount'], ''];

            xlsx_send_multi('riwayat-sku-' . $prod['sku'] . '-' . $from . '_' . $to, [
                ['name' => 'Ringkasan', 'header' => ['keterangan', 'nilai'], 'rows' => [
                    ['SKU', $prod['sku']],
                    ['Brand', $prod['brand']],
                    ['Periode dari', $from],
                    ['Periode sampai', $to],
                    ['Total qty masuk (posted)', (float)$sumIn['qty']],
                    ['Nilai pembelian setelah diskon (posted)', (float)$sumIn['amount']],
                    ['Total qty terjual (posted)', (float)$sumOut['qty']],
                    ['Nilai penjualan (posted)', (float)$sumOut['amount']],
                ]],
                ['name' => 'Barang Masuk', 'header' => ['tanggal', 'doc_no', 'supplier', 'qty', 'harga_beli', 'diskon_bagian', 'harga_setelah_diskon', 'nilai_setelah_diskon', 'status'], 'rows' => $inSheet],
                ['name' => 'Barang Keluar', 'header' => ['tanggal', 'doc_no', 'tujuan', 'channel', 'qty', 'harga_jual', 'nilai', 'status'], 'rows' => $outSheet],
            ]);
            break;

        case 'stock_brand':
            xlsx_send('stok-per-brand-' . date('Ymd'),
                ['brand_code', 'brand', 'sku_aktif', 'total_stok', 'nilai_stok_hpp', 'potensi_jual', 'sku_menipis'],
                db_all("SELECT b.code AS brand_code, b.name AS brand,
                               COUNT(p.id) AS sku_aktif,
                               COALESCE(SUM(p.stock_qty),0) AS total_stok,
                               COALESCE(SUM(p.stock_qty*p.cost_price),0) AS nilai_stok_hpp,
                               COALESCE(SUM(p.stock_qty*p.sell_price),0) AS potensi_jual,
                               COALESCE(SUM(CASE WHEN p.stock_qty <= p.min_stock THEN 1 ELSE 0 END),0) AS sku_menipis
                          FROM brands b LEFT JOIN products p ON p.brand_id = b.id AND p.active = 1
                         GROUP BY b.id ORDER BY b.name"));
            break;

        case 'daily_stock':
            $data = daily_stock_matrix((string)$from, (string)$to);
            $brandNames = array_values($data['brands']);
            $header = array_merge(['tanggal'], $brandNames, ['total_unit', 'total_nilai_rp']);

            $unitRows = [];
            $rpRows = [];
            foreach ($data['dates'] as $d) {
                $u = [$d];
                $v = [$d];
                foreach ($data['brands'] as $bid => $bname) {
                    $u[] = (float)($data['matrix'][$d][$bid] ?? 0);
                    $v[] = (float)($data['vmatrix'][$d][$bid] ?? 0);
                }
                $u[] = (float)$data['totals'][$d];
                $u[] = (float)($data['vtotals'][$d] ?? 0);
                $v[] = (float)$data['totals'][$d];
                $v[] = (float)($data['vtotals'][$d] ?? 0);
                $unitRows[] = $u;
                $rpRows[] = $v;
            }
            if (!empty($data['truncated'])) {
                $note = 'CATATAN: data dibatasi ' . count($data['dates']) . ' hari pertama dari rentang yang dipilih (sisa '
                    . (int)$data['skipped_days'] . ' hari tidak disertakan). Persempit periode export untuk data lengkap.';
                $unitRows[] = array_merge([$note], array_fill(0, count($brandNames) + 2, ''));
                $rpRows[] = array_merge([$note], array_fill(0, count($brandNames) + 2, ''));
            }

            /* sheet barang keluar: pcs & nilai modal (HPP) per hari */
            $out = daily_outgoing((string)$from, (string)$to);
            $outRows = [];
            foreach ($out['dates'] as $d) {
                $outRows[] = [
                    $d,
                    (int)($out['docs'][$d] ?? 0),
                    (float)($out['qty'][$d] ?? 0),
                    (float)($out['cost'][$d] ?? 0),
                    (float)($out['sell'][$d] ?? 0),
                    (float)($out['margin'][$d] ?? 0),
                ];
            }
            $skuOutRows = [];
            foreach ($out['sku_rows'] as $r) {
                $skuOutRows[] = [
                    $r['sku'], $r['brand'], (float)$r['qty'], (float)$r['cost'], (float)$r['sell'],
                    (float)$r['sell'] - (float)$r['cost'],
                    (float)$r['qty'] > 0 ? (float)$r['cost'] / (float)$r['qty'] : 0,
                ];
            }

            /* sheet unit: jumlah stok; sheet rupiah: nominal HPP; sheet barang keluar: pcs + nilai modal */
            xlsx_send_multi('daily-stock-' . $from . '_' . $to, [
                ['name' => 'Unit', 'header' => $header, 'rows' => $unitRows],
                ['name' => 'Rupiah (HPP)', 'header' => $header, 'rows' => $rpRows],
                ['name' => 'Barang Keluar',
                 'header' => ['tanggal', 'jumlah_dokumen', 'pcs_keluar', 'nilai_modal_hpp', 'nilai_jual', 'laba_kotor'],
                 'rows' => $outRows],
                ['name' => 'Keluar per SKU',
                 'header' => ['sku', 'brand', 'pcs_keluar', 'nilai_modal_hpp', 'nilai_jual', 'laba_kotor', 'hpp_per_pcs'],
                 'rows' => $skuOutRows],
            ]);
            break;

        case 'fifo_layers':
            xlsx_send('lapisan-stok-fifo-' . date('Ymd'),
                ['sku', 'brand', 'tanggal_masuk', 'no_dokumen', 'sumber', 'qty_masuk', 'sisa', 'hpp_satuan', 'nilai_sisa'],
                db_all("SELECT p.sku, COALESCE(b.name,'-') AS brand, l.move_date, l.ref_no, l.ref_type,
                               l.qty_original, l.qty_remaining, l.unit_cost, (l.qty_remaining * l.unit_cost) AS nilai_sisa
                          FROM stock_layers l JOIN products p ON p.id = l.product_id
                          LEFT JOIN brands b ON b.id = p.brand_id
                         WHERE l.qty_remaining > 0 ORDER BY p.sku, l.move_date, l.id"));
            break;

        case 'layer_uses':
            xlsx_send('hpp-fifo-terjual-' . $from . '_' . $to,
                ['tanggal', 'ref_dokumen', 'sku', 'qty', 'hpp_satuan', 'nilai_hpp'],
                db_all("SELECT u.move_date, u.ref_no, p.sku, u.qty, u.unit_cost, u.total_cost
                          FROM layer_uses u JOIN products p ON p.id = u.product_id
                         WHERE u.move_date BETWEEN ? AND ? ORDER BY u.move_date, u.id", [$from, $to]));
            break;

        case 'ledger':
            $w = ['date(l.move_date) BETWEEN ? AND ?'];
            $p = [$from, $to];
            if (!empty($f['product_id'])) { $w[] = 'l.product_id = ?'; $p[] = (int)$f['product_id']; }
            if (!empty($f['ref_type'])) { $w[] = '(l.ref_type = ? OR l.ref_type = ?)'; $p[] = $f['ref_type']; $p[] = $f['ref_type'] . '_void'; }
            $wsql = 'WHERE ' . implode(' AND ', $w);
            xlsx_send('kartu-stok-' . date('Ymd'),
                ['tanggal', 'no_dokumen', 'jenis_mutasi', 'sku', 'masuk', 'keluar', 'saldo_stok', 'petugas', 'catatan'],
                array_map(static fn($r) => [
                    $r['move_date'], $r['ref_no'], doc_label((string)$r['ref_type']), $r['sku'],
                    (float)$r['qty_change'] > 0 ? $r['qty_change'] : '',
                    (float)$r['qty_change'] < 0 ? $r['qty_change'] : '',
                    $r['qty_after'], $r['user_name'] ?? '', $r['note'],
                ], db_all("SELECT l.*, p.sku, u.name AS user_name
                             FROM ledger l JOIN products p ON p.id = l.product_id LEFT JOIN users u ON u.id = l.user_id
                             $wsql ORDER BY l.id", $p)));
            break;

        case 'inbound':
            xlsx_send('barang-masuk-' . date('Ymd'),
                ['doc_no', 'doc_date', 'supplier', 'total_qty', 'subtotal', 'diskon_jenis', 'diskon_nilai', 'diskon_rupiah', 'total_dibayar', 'status', 'dibuat_oleh', 'dibuat_pada', 'catatan'],
                array_map(static fn($r) => [$r['doc_no'], $r['doc_date'], $r['supplier_name'] ?? '', $r['total_qty'],
                    $r['subtotal_amount'] ?? $r['total_amount'],
                    (string)($r['discount_type'] ?? 'percent') === 'percent' ? 'persen' : 'rupiah',
                    $r['discount_value'] ?? 0, $r['discount_amount'] ?? 0, $r['total_amount'],
                    $r['status'], $r['created_name'] ?? '', $r['created_at'], $r['note']],
                    db_all("SELECT i.*, s.name AS supplier_name, u.name AS created_name FROM inbounds i
                              LEFT JOIN suppliers s ON s.id=i.supplier_id LEFT JOIN users u ON u.id=i.created_by
                             WHERE date(i.doc_date) BETWEEN ? AND ? " . ($status !== '' ? 'AND i.status = ?' : '') . " ORDER BY i.doc_date",
                        $status !== '' ? [$from, $to, $status] : [$from, $to])));
            break;

        case 'inbound_items':
            xlsx_send('barang-masuk-item-' . date('Ymd'),
                ['doc_no', 'doc_date', 'supplier_code', 'sku', 'qty', 'unit_cost', 'subtotal', 'diskon_bagian', 'unit_cost_setelah_diskon', 'subtotal_setelah_diskon', 'note', 'status'],
                db_all('SELECT i.doc_no, i.doc_date, s.code AS supplier_code, p.sku, it.qty, it.unit_cost, it.subtotal,
                               it.discount_share, it.unit_cost_net, it.subtotal_net, i.note, i.status
                          FROM inbound_items it JOIN inbounds i ON i.id = it.inbound_id JOIN products p ON p.id = it.product_id
                          LEFT JOIN suppliers s ON s.id = i.supplier_id
                         WHERE date(i.doc_date) BETWEEN ? AND ? ORDER BY i.doc_date, i.id', [$from, $to]));
            break;

        case 'outbound':
            xlsx_send('barang-keluar-' . date('Ymd'),
                ['doc_no', 'doc_date', 'destination', 'channel', 'total_qty', 'nilai_jual', 'hpp_fifo', 'laba_kotor', 'status', 'dibuat_oleh', 'catatan'],
                array_map(static fn($r) => [
                    $r['doc_no'], $r['doc_date'], $r['destination'], $r['channel'], $r['total_qty'],
                    (float)$r['sell_total'], (float)$r['cogs_total'],
                    (float)$r['sell_total'] - (float)$r['cogs_total'],
                    $r['status'], $r['created_name'] ?? '', $r['note'],
                ], db_all("SELECT o.*, u.name AS created_name,
                               COALESCE((SELECT SUM(i.cogs) FROM outbound_items i WHERE i.outbound_id = o.id),0) AS cogs_total,
                               COALESCE((SELECT SUM(i.subtotal) FROM outbound_items i WHERE i.outbound_id = o.id),0) AS sell_total
                          FROM outbounds o LEFT JOIN users u ON u.id=o.created_by
                         WHERE date(o.doc_date) BETWEEN ? AND ? " . ($status !== '' ? 'AND o.status = ?' : '') . ' ORDER BY o.doc_date',
                    $status !== '' ? [$from, $to, $status] : [$from, $to])));
            break;

        case 'outbound_items':
            xlsx_send('barang-keluar-item-' . date('Ymd'),
                ['doc_no', 'doc_date', 'destination', 'channel', 'sku', 'qty', 'unit_price', 'subtotal', 'hpp_fifo_unit', 'hpp_fifo_total', 'laba_kotor', 'status'],
                db_all('SELECT o.doc_no, o.doc_date, o.destination, o.channel, p.sku, it.qty, it.unit_price, it.subtotal,
                               it.cogs_unit, it.cogs, it.subtotal - it.cogs AS laba, o.status
                          FROM outbound_items it JOIN outbounds o ON o.id = it.outbound_id JOIN products p ON p.id = it.product_id
                         WHERE date(o.doc_date) BETWEEN ? AND ? ORDER BY o.doc_date, o.id', [$from, $to]));
            break;

        case 'adjustments':
            xlsx_send('adjustment-' . date('Ymd'),
                ['doc_no', 'doc_date', 'reason', 'total_items', 'total_delta', 'status', 'dibuat_oleh', 'catatan', 'alasan_void'],
                db_all("SELECT a.*, u.name AS created_name FROM adjustments a LEFT JOIN users u ON u.id=a.created_by
                         WHERE date(a.doc_date) BETWEEN ? AND ? ORDER BY a.doc_date", [$from, $to]));
            break;

        case 'adjustment_items':
            xlsx_send('adjustment-item-' . date('Ymd'),
                ['doc_no', 'doc_date', 'sku', 'qty_before', 'qty_after', 'delta', 'status'],
                db_all('SELECT a.doc_no, a.doc_date, p.sku, it.qty_before, it.qty_after, it.delta, a.status
                          FROM adjustment_items it JOIN adjustments a ON a.id = it.adjustment_id JOIN products p ON p.id = it.product_id
                         WHERE date(a.doc_date) BETWEEN ? AND ? ORDER BY a.doc_date, it.id', [$from, $to]));
            break;

        case 'opnames':
            xlsx_send('opname-' . date('Ymd'),
                ['doc_no', 'doc_date', 'total_items', 'total_diff', 'status', 'petugas', 'catatan', 'alasan_void'],
                db_all("SELECT o.*, u.name AS created_name FROM opnames o LEFT JOIN users u ON u.id=o.created_by
                         WHERE date(o.doc_date) BETWEEN ? AND ? ORDER BY o.doc_date", [$from, $to]));
            break;

        case 'opname_items':
            xlsx_send('opname-item-' . date('Ymd'),
                ['doc_no', 'doc_date', 'sku', 'qty_system', 'qty_counted', 'diff', 'status'],
                db_all('SELECT o.doc_no, o.doc_date, p.sku, it.qty_system, it.qty_counted, it.diff, o.status
                          FROM opname_items it JOIN opnames o ON o.id = it.opname_id JOIN products p ON p.id = it.product_id
                         WHERE date(o.doc_date) BETWEEN ? AND ? ORDER BY o.doc_date, it.id', [$from, $to]));
            break;

        case 'returns':
            xlsx_send('retur-' . date('Ymd'),
                ['doc_no', 'doc_date', 'type', 'party', 'ref_doc_no', 'total_qty', 'total_amount', 'status', 'dibuat_oleh', 'catatan'],
                db_all("SELECT r.*, u.name AS created_name FROM returns r LEFT JOIN users u ON u.id=r.created_by
                         WHERE date(r.doc_date) BETWEEN ? AND ? ORDER BY r.doc_date", [$from, $to]));
            break;

        case 'return_items':
            xlsx_send('retur-item-' . date('Ymd'),
                ['doc_no', 'doc_date', 'type', 'party', 'ref_doc_no', 'sku', 'qty', 'price', 'subtotal', 'status', 'note'],
                db_all('SELECT r.doc_no, r.doc_date, r.type, r.party, r.ref_doc_no, p.sku, it.qty, it.unit_price, it.subtotal, r.status, r.note
                          FROM return_items it JOIN returns r ON r.id = it.return_id JOIN products p ON p.id = it.product_id
                         WHERE date(r.doc_date) BETWEEN ? AND ? ORDER BY r.doc_date, it.id', [$from, $to]));
            break;

        case 'activity':
            xlsx_send('log-aktivitas-' . date('Ymd'),
                ['waktu', 'username', 'aksi', 'keterangan', 'ref_no'],
                db_all('SELECT created_at, username, action, detail, ref_no FROM activity_log
                         WHERE date(created_at) BETWEEN ? AND ? ORDER BY id DESC', [$from, $to]));
            break;

        case 'rekap_ringkas':
            $rec = [
                ['Total SKU aktif', (int)db_scalar('SELECT COUNT(*) FROM products WHERE active=1')],
                ['Total unit stok', (float)(db_scalar('SELECT COALESCE(SUM(stock_qty),0) FROM products') ?? 0)],
                ['Nilai stok (HPP)', (float)(db_scalar('SELECT COALESCE(SUM(stock_qty*cost_price),0) FROM products') ?? 0)],
                ['Potensi nilai jual', (float)(db_scalar('SELECT COALESCE(SUM(stock_qty*sell_price),0) FROM products') ?? 0)],
                ['SKU stok menipis', (int)db_scalar('SELECT COUNT(*) FROM products WHERE active=1 AND stock_qty <= min_stock')],
                ['Jumlah brand', (int)db_scalar('SELECT COUNT(*) FROM brands')],
                ['Jumlah supplier', (int)db_scalar('SELECT COUNT(*) FROM suppliers')],
                ['Dokumen barang masuk posted', (int)db_scalar("SELECT COUNT(*) FROM inbounds WHERE status='posted'")],
                ['Dokumen barang keluar posted', (int)db_scalar("SELECT COUNT(*) FROM outbounds WHERE status='posted'")],
                ['Dokumen adjustment posted', (int)db_scalar("SELECT COUNT(*) FROM adjustments WHERE status='posted'")],
                ['Dokumen opname posted', (int)db_scalar("SELECT COUNT(*) FROM opnames WHERE status='posted'")],
                ['Dokumen retur posted', (int)db_scalar("SELECT COUNT(*) FROM returns WHERE status='posted'")],
                ['Periode laporan', $from . ' s/d ' . $to],
            ];
            xlsx_send('rekap-ringkas-' . date('Ymd'), ['indikator', 'nilai'], $rec);
            break;

        default:
            http_response_code(400);
            echo 'Jenis export tidak dikenal.';
    }
}
