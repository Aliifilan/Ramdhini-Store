<?php
declare(strict_types=1);

function nav_items(): array
{
    return [
        'Utama' => [
            ['dashboard', 'Dashboard', 'index.php', 'chart', 'inv.view'],
        ],
        'Master Data' => [
            ['products', 'Produk Master', 'products.php', 'box', 'master.view'],
            ['brands', 'Brand', 'brands.php', 'tag', 'master.view'],
            ['suppliers', 'Supplier', 'suppliers.php', 'truck', 'master.view'],
            ['users', 'Pengguna', 'users.php', 'user', 'master.view'],
        ],
        'Inventory' => [
            ['stock', 'Stok Total', 'stock.php', 'layers', 'inv.view'],
            ['stock_brand', 'Stok per Brand', 'stock_brand.php', 'tag', 'inv.view'],
            ['daily_stock', 'Daily Stock (All Brand)', 'daily_stock.php', 'calendar', 'inv.view'],
            ['ledger', 'Kartu Stok / Mutasi', 'ledger.php', 'list', 'inv.view'],
            ['adjustments', 'Stok Adjustment', 'adjustments.php', 'sliders', 'inv.view'],
            ['opnames', 'Stok Opname', 'opnames.php', 'clipboard', 'inv.view'],
        ],
        'Transaksi' => [
            ['inbound', 'Barang Masuk (Inbound)', 'inbound.php', 'download', 'tx.view'],
            ['outbound', 'Barang Keluar (Outbound)', 'outbound.php', 'upload', 'tx.view'],
            ['returns', 'Retur', 'returns.php', 'rotate', 'tx.view'],
        ],
        'Laporan & Data' => [
            ['reports', 'Laporan Ringkas', 'reports.php', 'report', 'report.view'],
            ['report_settings', 'Laporan Email', 'report_settings.php', 'import', 'settings.manage'],
            ['import', 'Import Data', 'import.php', 'import', 'data.import'],
            ['export', 'Export Data', 'export.php?page=1', 'export', 'data.export'],
            ['activity', 'Log Aktivitas', 'activity.php', 'shield', 'master.view'],
        ],
    ];
}

function icon(string $name): string
{
    $paths = [
        'chart' => '<path d="M4 19V5m0 14h16M8 15V9m4 6V6m4 9v-4"/>',
        'box' => '<path d="M21 8.5 12 3 3 8.5v7L12 21l9-5.5v-7Z"/><path d="M3 8.5 12 14l9-5.5M12 14v7"/>',
        'tag' => '<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8Z"/><circle cx="7.5" cy="7.5" r="1.4"/>',
        'truck' => '<path d="M3 6h11v10H3zM14 9h4l3 3v4h-7z"/><circle cx="7" cy="18" r="1.6"/><circle cx="17.5" cy="18" r="1.6"/>',
        'user' => '<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20c1.2-3.6 4-5.4 7.5-5.4S18.3 16.4 19.5 20"/>',
        'layers' => '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/>',
        'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
        'list' => '<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>',
        'sliders' => '<path d="M4 8h10M18 8h2M4 16h4M12 16h8"/><circle cx="16" cy="8" r="2"/><circle cx="10" cy="16" r="2"/>',
        'clipboard' => '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1M9 11h6M9 15h4"/>',
        'download' => '<path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M4 19h16"/>',
        'upload' => '<path d="M12 21V9m0 0 4 4m-4-4-4 4"/><path d="M4 5h16"/>',
        'rotate' => '<path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v5h-5"/>',
        'report' => '<path d="M6 3h9l4 4v14H6z"/><path d="M9 12h6M9 16h6M14 3v4h4"/>',
        'import' => '<path d="M12 15V3m0 0 4 4m-4-4-4 4"/><path d="M4 15v4h16v-4"/>',
        'export' => '<path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M4 15v4h16v-4"/>',
        'shield' => '<path d="M12 3l8 3v6c0 4.5-3.2 7.8-8 9-4.8-1.2-8-4.5-8-9V6l8-3Z"/><path d="m9 12 2 2 4-4"/>',
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'check' => '<path d="m5 13 4 4L19 7"/>',
        'x' => '<path d="M6 6l12 12M18 6 6 18"/>',
        'ban' => '<circle cx="12" cy="12" r="9"/><path d="m6 6 12 12"/>',
        'print' => '<path d="M7 9V4h10v5M7 19H5v-6h14v6h-2"/><rect x="7" y="14" width="10" height="7"/>',
        'arrow-left' => '<path d="M19 12H5m0 0 6-6m-6 6 6 6"/>',
        'edit' => '<path d="M4 20h4L20 8l-4-4L4 16Z"/><path d="m14 6 4 4"/>',
    ];
    $p = $paths[$name] ?? $paths['box'];
    return '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
}

function page_start(string $title, string $active = ''): void
{
    $u = current_user();
    $flashes = take_flashes();
    ?><!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> &middot; <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= e(asset_url('assets/app.css')) ?>">
</head>
<body>
<div class="app">
  <aside class="sidebar" id="sidebar">
    <div class="brand">
      <span class="brand-mark"><?= icon('box') ?></span>
      <span class="brand-text">
        <strong><?= e(APP_NAME) ?></strong>
        <small><?= e(APP_OWNER) ?></small>
      </span>
    </div>
    <nav class="nav">
      <?php foreach (nav_items() as $section => $items): ?>
        <?php
          $visible = array_filter($items, static fn($it) => can($it[4]));
          if (!$visible) continue;
        ?>
        <div class="nav-section"><?= e($section) ?></div>
        <?php foreach ($visible as [$key, $label, $href, $ic, $perm]): ?>
          <a class="nav-link<?= $active === $key ? ' active' : '' ?>" href="<?= e($href) ?>">
            <?= icon($ic) ?><span><?= e($label) ?></span>
          </a>
        <?php endforeach; ?>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
      <a class="nav-link" href="profile.php"><?= icon('user') ?><span>Akun Saya</span></a>
      <a class="nav-link" href="logout.php"><?= icon('x') ?><span>Keluar</span></a>
    </div>
  </aside>

  <div class="main">
    <header class="topbar">
      <button class="hamburger" type="button" onclick="document.body.classList.toggle('nav-open')" aria-label="Menu">&#9776;</button>
      <div class="topbar-title">
        <h1><?= e($title) ?></h1>
      </div>
      <div class="topbar-user">
        <div class="who">
          <strong><?= e($u['name'] ?? '') ?></strong>
          <small><?= e(ROLES[$u['role'] ?? ''] ?? '') ?></small>
        </div>
        <div class="avatar"><?= e(strtoupper(substr((string)($u['name'] ?? 'U'), 0, 1))) ?></div>
      </div>
    </header>

    <main class="content">
      <?php foreach ($flashes as $f): ?>
        <div class="alert alert-<?= e($f['type']) ?>"><?= $f['msg'] ?></div>
      <?php endforeach; ?>
<?php
}

function page_end(): void
{
    ?>
    </main>
    <footer class="foot"><?= e(APP_NAME) ?> &middot; <?= e(APP_OWNER) ?> &middot; <?= date('Y') ?></footer>
  </div>
</div>
<div class="backdrop" onclick="document.body.classList.remove('nav-open')"></div>
<script src="<?= e(asset_url('assets/app.js')) ?>"></script>
</body>
</html><?php
}

function card_start(string $title, string $sub = '', string $actions = ''): void
{
    ?>
    <section class="card">
      <div class="card-head">
        <div>
          <h2><?= e($title) ?></h2>
          <?php if ($sub !== ''): ?><p class="muted"><?= e($sub) ?></p><?php endif; ?>
        </div>
        <?php if ($actions !== ''): ?><div class="card-actions"><?= $actions ?></div><?php endif; ?>
      </div>
      <div class="card-body">
<?php
}

function card_end(): void
{
    ?>
      </div>
    </section>
<?php
}

function empty_state(string $msg): string
{
    return '<div class="empty">' . e($msg) . '</div>';
}

/**
 * Peralatan scan/ketik SKU yang dipakai semua form transaksi.
 *
 * $opts:
 *   mode        : 'items' (baris dokumen: qty + harga) | 'count' (opname/adjustment: fokus kolom hitung fisik)
 *   priceLabel  : label kolom harga (mis. "Harga Beli")
 *   canCreate   : boleh membuat produk baru langsung dari kolom scan
 *   brands      : daftar brand untuk panel buat cepat
 *   focusField  : selector kolom yang difokus setelah scan pada mode 'count' (default .count-field)
 *   hint        : kalimat bantuan singkat
 */
function sku_scan_tools(array $opts): void
{
    $mode = $opts['mode'] ?? 'items';
    $canCreate = !empty($opts['canCreate']);
    $brands = $opts['brands'] ?? [];
    $focusField = $opts['focusField'] ?? '.count-field';
    $priceLabel = $opts['priceLabel'] ?? 'Harga';
    $priceKey = $opts['priceKey'] ?? 'cost_price';
    $hint = $opts['hint'] ?? '';
    $listId = (string)($opts['list'] ?? '');
    /* autofokus kolom scan: default aktif (memudahkan scanner), bisa dimatikan di halaman
       yang punya kolom pencarian sendiri supaya keyboard HP tidak muncul sendiri. */
    $autofocus = array_key_exists('autofocus', $opts) ? (bool)$opts['autofocus'] : true;
    $uid = 'scan' . bin2hex(random_bytes(3));
    ?>
    <div class="scan-bar" id="<?= $uid ?>"
         data-scan-tools
         data-mode="<?= e($mode) ?>"
         data-can-create="<?= $canCreate ? '1' : '0' ?>"
         data-focus-field="<?= e($focusField) ?>"
         data-price-label="<?= e($priceLabel) ?>"
         data-price-key="<?= e($priceKey) ?>"
         data-body="<?= e((string)($opts['body'] ?? 'itemBody')) ?>"
         data-tpl="<?= e((string)($opts['tpl'] ?? 'itemTpl')) ?>"
         data-table="<?= e((string)($opts['table'] ?? 'itemTable')) ?>"
         data-list="<?= e($listId) ?>"
         data-target="<?= e((string)($opts['target'] ?? '')) ?>"
         data-context="<?= e((string)($opts['context'] ?? 'new')) ?>"
         data-current-id="<?= e((string)($opts['currentId'] ?? '0')) ?>"
         data-csrf="<?= e((string)($opts['csrf'] ?? csrf_token())) ?>"
         data-autofocus="<?= $autofocus ? '1' : '0' ?>">
      <div class="scan-main">
        <label for="<?= $uid ?>-input"><?= $mode === 'field' ? 'Scan QR / barcode untuk mengisi kolom SKU'
            : ($mode === 'search' ? 'Scan QR / barcode produk untuk mencari' : 'Scan / ketik SKU') ?></label>
        <div class="scan-row">
          <input type="text" id="<?= $uid ?>-input" class="scan-input" data-scan-input
                 placeholder="Scan barcode/QR di sini, atau ketik SKU lalu Enter"
                 autocomplete="off" autocapitalize="characters" spellcheck="false">
          <button class="btn" type="button" data-scan-camera title="Scan lewat kamera HP (Android/Chrome)"><?= icon('tag') ?> Kamera</button>
          <?php if ($mode === 'items'): ?>
            <button class="btn" type="button" data-scan-add><?= icon('plus') ?> Baris kosong</button>
          <?php endif; ?>
          <?php if ($mode === 'search'): ?>
            <button class="btn btn-primary" type="button" data-scan-submit>Cari</button>
          <?php endif; ?>
        </div>
        <p class="help scan-help">
          <?= e($hint !== '' ? $hint : ($mode === 'field'
              ? 'Scan QR/barcode produk dengan scanner USB/Bluetooth, atau lewat kamera HP. SKU yang sudah terdaftar akan diberi peringatan supaya tidak dibuat dobel.'
              : ($mode === 'search'
                  ? 'Scan QR/barcode atau ketik SKU untuk mencari. Setelah terbaca, kamera menutup sendiri dan hasil pencarian langsung tampil.'
                  : 'Scanner barcode/QR USB maupun Bluetooth (mode keyboard) langsung bekerja di kolom ini — pastikan scannernya mengirim akhiran Enter.'))) ?>
        </p>
      </div>
      <div class="scan-status" data-scan-status aria-live="polite"></div>

      <div class="scan-notfound" data-scan-notfound hidden>

        <div class="scan-notfound-head">
          <strong>SKU <span data-scan-notfound-sku></span> belum terdaftar</strong>
          <button class="btn btn-sm btn-ghost" type="button" data-scan-notfound-close>Tutup</button>
        </div>
        <?php if ($mode === 'field'): ?>
          <p class="help">Periksa kolom SKU. Kalau SKU ini sudah terdaftar, buka produk yang ada agar tidak dobel.</p>
        <?php elseif ($canCreate): ?>
          <p class="help">Daftarkan sekarang tanpa keluar dari halaman ini, lalu barangnya langsung masuk ke daftar.</p>
          <div class="qc-grid">
            <div><label>SKU</label><input type="text" data-qc="sku" readonly></div>
            <div><label>Brand</label>
              <select data-qc="brand_id">
                <option value="0">- tanpa brand -</option>
                <?php foreach ($brands as $b): ?>
                  <option value="<?= (int)$b['id'] ?>"><?= e($b['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div><label>Kategori</label><input type="text" data-qc="category" placeholder="cth: Skincare"></div>
            <div><label>Ukuran</label>
              <select data-qc="size">
                <option value="">- tanpa ukuran -</option>
                <?php foreach (product_sizes() as $sz): ?>
                  <option value="<?= e($sz) ?>"><?= e($sz) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div><label>Satuan</label><input type="text" data-qc="unit" value="pcs"></div>
            <div><label>HPP</label><input type="text" data-qc="cost_price" placeholder="isi harga"></div>
            <div><label>Harga Jual</label><input type="text" data-qc="sell_price" placeholder="isi harga"></div>
            <div><label>Stok Minimum</label><input type="text" data-qc="min_stock" placeholder="0"></div>
            <div class="qc-actions">
              <button class="btn btn-primary" type="button" data-qc-submit><?= icon('plus') ?> Buat &amp; Tambahkan</button>
            </div>
          </div>
          <p class="help">Stok awal produk baru = 0. Isi stoknya lewat Stok Adjustment atau Stok Awal supaya tercatat di kartu stok.</p>
        <?php else: ?>
          <p class="help">Role Anda tidak boleh menambah produk. Minta Admin mendaftarkan SKU ini di menu Produk Master.</p>
        <?php endif; ?>
      </div>
    </div>

    <div class="cam-overlay" data-cam-overlay hidden>
      <div class="cam-box">
        <div class="cam-head">
          <strong>Scan kamera</strong>
          <button class="btn btn-sm btn-ghost" type="button" data-cam-close>Tutup</button>
        </div>
        <div class="cam-stage">
          <video data-cam-video playsinline muted></video>
          <div class="cam-frame"></div>
        </div>
        <p class="cam-status" data-cam-status>Arahkan kamera ke barcode / QR produk.</p>
      </div>
    </div>
    <?php
}

/**
 * Judul kolom tabel yang bisa diklik untuk mengurutkan (▲ naik / ▼ turun).
 * Tautannya membawa seluruh filter yang sedang aktif; halaman kembali ke 1
 * supaya hasil urutan terlihat dari baris pertama.
 */
function sort_link(string $label, string $key, string $curKey, string $curDir): string
{
    $active = $curKey === $key;
    $next = ($active && $curDir === 'asc') ? 'desc' : 'asc';
    $ind = $active ? ($curDir === 'asc' ? '▲' : '▼') : '⇅';
    $url = '?' . qs(['sort' => $key, 'dir' => $next, 'page' => null]);
    return '<a class="th-sort' . ($active ? ' active' : '') . '" href="' . e($url) . '"'
        . ' title="Urutkan menurut ' . e($label) . ' (' . ($next === 'asc' ? 'naik' : 'turun') . ')"'
        . ' data-sort-key="' . e($key) . '">'
        . e($label) . '<span class="sort-ind" aria-hidden="true">' . $ind . '</span></a>';
}

/**
 * Kolom jumlah (qty) dengan tombol kurang/tambah di kedua sisinya.
 * Dipakai form barang masuk, barang keluar, dan retur.
 *
 * @param string $value     nilai awal (angka)
 * @param bool   $editable  false = hanya tampil angka (dokumen sudah diposting/void)
 * @param string $tabindex  urutan tab (opsional)
 */
function qty_stepper(string $value, bool $editable = true, int $tabindex = 0): string
{
    $shown = e(fmt_qty($value));
    if (!$editable) {
        return '<span class="qty-plain">' . $shown . '</span>';
    }
    $tab = $tabindex > 0 ? ' tabindex="' . $tabindex . '"' : '';
    return '<div class="qty-stepper">'
        . '<button class="qty-btn" type="button" data-qty-step="-1" aria-label="Kurangi jumlah" title="Kurangi">&minus;</button>'
        . '<input class="qty-input" type="text" name="item_qty[]" value="' . $shown . '"'
        . ' inputmode="numeric" autocomplete="off" spellcheck="false" oninput="rowRecalc()"' . $tab . '>'
        . '<button class="qty-btn" type="button" data-qty-step="1" aria-label="Tambah jumlah" title="Tambah">+</button>'
        . '</div>';
}

/** Data produk untuk JS (harga & stok) — dipakai form transaksi. */
function product_js_maps(array $products, string $priceKey): string
{
    $stock = [];
    $price = [];
    foreach ($products as $p) {
        $stock[(string)$p['id']] = (float)$p['stock_qty'];
        $price[(string)$p['id']] = (float)($p[$priceKey] ?? 0);
    }
    return 'window.PRODUCT_STOCK = ' . json_encode($stock) . ";\n"
        . 'window.PRODUCT_PRICE = ' . json_encode($price) . ";\n";
}
