<?php
declare(strict_types=1);

/**
 * Matriks stok akhir hari per brand.
 * Dihitung dengan replay kartu stok (ledger) sampai tanggal akhir,
 * jadi angka tiap hari adalah posisi stok pada penutupan hari itu.
 *
 * Nilai rupiah (vmatrix/vtotals) memakai HPP produk saat ini, karena hanya harga itulah
 * yang tersimpan di aplikasi.
 *
 * @param int $maxDays batas jumlah hari agar rentang tanggal tidak tak terbatas
 * @return array{dates:string[], brands:array<int,string>, matrix:array<string,array<int,float>>, totals:array<string,float>, vmatrix:array<string,array<int,float>>, vtotals:array<string,float>, sku_rows:array<string,array>, truncated:bool, skipped_days:int}
 */
function daily_stock_matrix(string $from, string $to, int $maxDays = 1000): array
{
    $dates = [];
    $cur = strtotime($from);
    $end = strtotime($to);
    $empty = ['dates' => [], 'brands' => [], 'matrix' => [], 'totals' => [], 'truncated' => false, 'skipped_days' => 0];
    if ($cur === false || $end === false) return $empty;
    if ($cur > $end) return $empty;
    $truncated = false;
    $skipped = 0;
    $guard = 0;
    while ($cur <= $end) {
        if ($guard >= $maxDays) {
            $truncated = true;
            $skipped++;
            $cur = strtotime('+1 day', $cur);
            continue;
        }
        $dates[] = date('Y-m-d', $cur);
        $cur = strtotime('+1 day', $cur);
        $guard++;
    }

    $brandRows = db_all('SELECT id, name FROM brands ORDER BY name');
    $brands = [];
    foreach ($brandRows as $b) $brands[(int)$b['id']] = (string)$b['name'];

    $prodBrand = [];
    $prodSku = [];
    $prodCost = [];
    foreach (db_all('SELECT id, brand_id, sku, cost_price FROM products') as $p) {
        $prodBrand[(int)$p['id']] = $p['brand_id'] === null ? 0 : (int)$p['brand_id'];
        $prodSku[(int)$p['id']] = (string)$p['sku'];
        $prodCost[(int)$p['id']] = (float)$p['cost_price'];
    }
    $perSku = [];

    $rows = db_all(
        'SELECT product_id, move_date, SUM(qty_change) AS q
           FROM ledger
          WHERE move_date <= ?
          GROUP BY product_id, move_date
          ORDER BY product_id, move_date',
        [$to]
    );

    $byProduct = [];
    foreach ($rows as $r) {
        $pid = (int)$r['product_id'];
        $byProduct[$pid][] = ['d' => (string)$r['move_date'], 'q' => (float)$r['q']];
    }

    $matrix = [];
    $totals = [];
    $vmatrix = [];        // nilai rupiah (HPP) per brand per tanggal
    $vtotals = [];
    foreach ($dates as $d) { $matrix[$d] = []; $totals[$d] = 0.0; $vmatrix[$d] = []; $vtotals[$d] = 0.0; }
    foreach ($brands as $bid => $bname) {
        foreach ($dates as $d) $matrix[$d][$bid] = 0.0;
    }

    foreach ($byProduct as $pid => $moves) {
        $brandId = $prodBrand[$pid] ?? 0;
        $sku = $prodSku[$pid] ?? '';
        $cost = $prodCost[$pid] ?? 0.0;
        $qty = 0.0;
        $i = 0;
        $n = count($moves);
        foreach ($dates as $d) {
            while ($i < $n && $moves[$i]['d'] <= $d) {
                $qty += $moves[$i]['q'];
                $i++;
            }
            if (!isset($matrix[$d][$brandId])) $matrix[$d][$brandId] = 0.0;
            $matrix[$d][$brandId] += $qty;
            $totals[$d] += $qty;
            /* nilai dihitung dari HPP produk saat ini (satu-satunya harga modal yang tersimpan) */
            $val = $qty * $cost;
            if (!isset($vmatrix[$d][$brandId])) $vmatrix[$d][$brandId] = 0.0;
            $vmatrix[$d][$brandId] += $val;
            $vtotals[$d] += $val;
            if (!isset($perSku[$sku])) {
                $perSku[$sku] = ['sku' => $sku, 'brand' => $brands[$brandId] ?? '-', 'matrix' => [], 'totals' => []];
            }
            $perSku[$sku]['matrix'][$d] = $qty;
            $perSku[$sku]['totals'][$d] = $val;
        }
    }

    return ['dates' => $dates, 'brands' => $brands, 'matrix' => $matrix, 'totals' => $totals,
            'vmatrix' => $vmatrix, 'vtotals' => $vtotals, 'sku_rows' => $perSku ?? [],
            'truncated' => $truncated, 'skipped_days' => $skipped];
}

/**
 * Barang KELUAR per hari: jumlah pcs dan nilai modalnya (HPP).
 *
 * Nilai modal memakai HPP FIFO yang benar-benar dipakai barang itu keluar
 * (`outbound_items.cogs`, dihitung fifo_rebuild()). Untuk data lama yang belum
 * punya cogs, dipakai cadangan `qty × products.cost_price` (HPP rata-rata saat ini)
 * supaya angka tetap terisi dan tidak menampilkan nol yang menyesatkan.
 *
 * Hanya dokumen berstatus `posted` yang dihitung (draft/void tidak mengubah stok).
 *
 * @return array{dates:array<int,string>,qty:array<string,float>,cost:array<string,float>,
 *               sell:array<string,float>,margin:array<string,float>,docs:array<string,int>,
 *               brand_qty:array<string,array<int,float>>,brand_cost:array<string,array<int,float>>,
 *               brands:array<int,string>,sku_rows:array<int,array<string,mixed>>}
 */
function daily_outgoing(string $from, string $to): array
{
    $out = [
        'dates' => [], 'qty' => [], 'cost' => [], 'sell' => [], 'margin' => [], 'docs' => [],
        'brand_qty' => [], 'brand_cost' => [], 'brands' => [], 'sku_rows' => [],
    ];
    if ($from === '' || $to === '' || $from > $to) return $out;

    $dates = [];
    for ($t = strtotime($from), $end = strtotime($to); $t !== false && $t <= $end; $t = strtotime('+1 day', $t)) {
        $dates[] = date('Y-m-d', $t);
    }
    $out['dates'] = $dates;
    foreach ($dates as $d) {
        $out['qty'][$d] = 0.0;
        $out['cost'][$d] = 0.0;
        $out['sell'][$d] = 0.0;
        $out['margin'][$d] = 0.0;
        $out['docs'][$d] = 0;
        $out['brand_qty'][$d] = [];
        $out['brand_cost'][$d] = [];
    }

    $brands = [];
    foreach (db_all('SELECT id, name FROM brands ORDER BY name') as $b) $brands[(int)$b['id']] = (string)$b['name'];
    $out['brands'] = $brands;

    $rows = db_all(
        "SELECT o.doc_date AS d, o.id AS doc_id, oi.product_id, p.sku, p.brand_id, p.cost_price,
                SUM(oi.qty) AS qty, SUM(oi.subtotal) AS sell, SUM(COALESCE(oi.cogs,0)) AS cogs
           FROM outbound_items oi
           JOIN outbounds o ON o.id = oi.outbound_id
           JOIN products p ON p.id = oi.product_id
          WHERE o.status = 'posted' AND date(o.doc_date) BETWEEN ? AND ?
          GROUP BY o.doc_date, o.id, oi.product_id
          ORDER BY o.doc_date, o.id",
        [$from, $to]
    );

    $docSeen = [];
    $skuAgg = [];
    foreach ($rows as $r) {
        $d = (string)$r['d'];
        if (!isset($out['qty'][$d])) {
            /* tanggal di luar daftar (format tanggal aneh) — lewati agar tidak membuat kunci liar */
            continue;
        }
        $qty = (float)$r['qty'];
        $cost = (float)$r['cogs'];
        if ($cost <= 0) $cost = $qty * (float)$r['cost_price'];
        $sell = (float)$r['sell'];
        $bid = $r['brand_id'] === null ? 0 : (int)$r['brand_id'];
        $sku = (string)$r['sku'];

        $out['qty'][$d] += $qty;
        $out['cost'][$d] += $cost;
        $out['sell'][$d] += $sell;
        $out['brand_qty'][$d][$bid] = ($out['brand_qty'][$d][$bid] ?? 0) + $qty;
        $out['brand_cost'][$d][$bid] = ($out['brand_cost'][$d][$bid] ?? 0) + $cost;
        $key = $d . ':' . (int)$r['doc_id'];
        if (!isset($docSeen[$key])) { $docSeen[$key] = true; $out['docs'][$d]++; }

        if (!isset($skuAgg[$sku])) {
            $skuAgg[$sku] = [
                'sku' => $sku,
                'brand' => $brands[$bid] ?? '-',
                'brand_id' => $bid,
                'qty' => 0.0, 'cost' => 0.0, 'sell' => 0.0,
            ];
        }
        $skuAgg[$sku]['qty'] += $qty;
        $skuAgg[$sku]['cost'] += $cost;
        $skuAgg[$sku]['sell'] += $sell;
    }
    foreach ($out['dates'] as $d) {
        $out['margin'][$d] = $out['sell'][$d] - $out['cost'][$d];
    }
    usort($skuAgg, static fn($a, $b) => $b['cost'] <=> $a['cost']);
    $out['sku_rows'] = $skuAgg;

    return $out;
}

/** Rekap stok per brand (posisi saat ini). */
function stock_by_brand_rows(): array
{
    return db_all(
        "SELECT b.id, b.code, b.name, b.active,
                COUNT(p.id) AS sku_count,
                COALESCE(SUM(p.stock_qty),0) AS stock_qty,
                COALESCE(SUM(p.stock_qty * p.cost_price),0) AS stock_value,
                COALESCE(SUM(p.stock_qty * p.sell_price),0) AS sell_value,
                COALESCE(SUM(CASE WHEN p.stock_qty <= p.min_stock THEN 1 ELSE 0 END),0) AS low_count
           FROM brands b LEFT JOIN products p ON p.brand_id = b.id AND p.active = 1
          GROUP BY b.id ORDER BY b.name"
    );
}

/**
 * Baris data untuk diagram lingkaran: brand berstok saja, diurutkan dari yang
 * terbesar, lalu sisanya digabung menjadi satu potongan "Brand lain" supaya
 * potongan tipis tidak menumpuk jadi tidak terbaca (ada 28 brand terdaftar).
 * Setiap potongan membawa $href supaya bisa diklik ke data terkait.
 *
 * @return array<int,array{label:string,value:float,display:string,href:string,meta:string}>
 */
function brand_pie_rows(array $rows, ?array $noBrand, string $key, callable $display, int $max = 8): array
{
    $data = [];
    foreach ($rows as $r) {
        $v = (float)$r[$key];
        if ($v <= 0) continue;
        $id = (int)$r['id'];
        $data[] = [
            'label' => (string)$r['name'],
            'value' => $v,
            'href' => 'products.php?brand_id=' . $id,
            'meta' => fmt_num((int)$r['sku_count']) . ' SKU aktif',
            '_id' => $id,
        ];
    }
    if ($noBrand && (int)$noBrand['c'] > 0) {
        $v = $key === 'stock_qty' ? (float)$noBrand['q'] : (float)$noBrand['v'];
        if ($v > 0) {
            $data[] = [
                'label' => 'Tanpa brand',
                'value' => $v,
                'href' => 'products.php?brand_id=0&status=aktif',
                'meta' => fmt_num((int)$noBrand['c']) . ' produk tanpa brand',
                '_id' => 0,
            ];
        }
    }
    usort($data, static fn($a, $b) => $b['value'] <=> $a['value']);

    $out = [];
    $restVal = 0.0;
    $restCount = 0;
    foreach ($data as $d) {
        if (count($out) < $max - 1) {
            $out[] = [
                'label' => $d['label'],
                'value' => $d['value'],
                'display' => $display($d['value']),
                'href' => $d['href'],
                'meta' => $d['meta'],
            ];
        } else {
            $restVal += $d['value'];
            $restCount++;
        }
    }
    if ($restCount > 0) {
        $out[] = [
            'label' => 'Brand lain (' . $restCount . ')',
            'value' => $restVal,
            'display' => $display($restVal),
            'href' => '',
            'meta' => 'gabungan ' . $restCount . ' brand dengan porsi terkecil — rinciannya ada di tabel bawah',
        ];
    }
    return $out;
}

/** Daftar produk untuk form/opname: id, sku, name, brand, satuan, stok, min_stock. */
function product_picker(int $brandId = 0): array
{
    $wsql = 'WHERE p.active = 1';
    $params = [];
    if ($brandId > 0) { $wsql .= ' AND p.brand_id = ?'; $params[] = $brandId; }
    return db_all(
        "SELECT p.id, p.sku, p.unit, p.stock_qty, p.min_stock, p.cost_price, p.sell_price,
                b.name AS brand_name
           FROM products p LEFT JOIN brands b ON b.id = p.brand_id
           $wsql ORDER BY p.sku",
        $params
    );
}
