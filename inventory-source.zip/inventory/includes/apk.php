<?php
declare(strict_types=1);

/**
 * Info aplikasi Android (APK) yang tersedia untuk diunduh.
 *
 * Isi berkas apk_version.php ditulis otomatis oleh androidapp/build.sh setiap kali
 * APK dibangun ulang, sehingga halaman Akun Saya selalu menampilkan versi terbaru
 * tanpa perlu diubah manual.
 */
function apk_info(): ?array
{
    $file = __DIR__ . '/apk_version.php';
    if (!is_file($file)) {
        return null;   // APK belum pernah dibangun
    }
    $info = require $file;
    if (!is_array($info) || empty($info['file'])) {
        return null;
    }
    $path = dirname(__DIR__) . '/download/' . basename((string)$info['file']);
    $info['exists'] = is_file($path);
    $info['size_real'] = $info['exists'] ? (int)filesize($path) : 0;
    $info['url'] = 'download/' . rawurlencode((string)$info['file']);
    $info['size_label'] = $info['size_real'] > 0
        ? (number_format($info['size_real'] / 1024, 0, ',', '.') . ' KB')
        : '-';
    return $info;
}

/** Ukuran berkas dalam satuan yang mudah dibaca. */
function human_size(int $bytes): string
{
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 1, ',', '.') . ' MB';
    if ($bytes >= 1024) return number_format($bytes / 1024, 0, ',', '.') . ' KB';
    return $bytes . ' B';
}
