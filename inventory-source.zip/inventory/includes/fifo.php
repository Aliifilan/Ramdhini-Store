<?php
declare(strict_types=1);

/* ============================================================
 * FIFO (First In First Out)
 *
 * Setiap penerimaan barang membentuk satu "lapisan" (layer) dengan
 * harga satuannya sendiri. Barang keluar mengambil dari lapisan
 * TERTUA lebih dulu, sehingga bisa diketahui harga HPP berapa yang
 * sebenarnya terjual/keluar — bukan sekadar satu harga modal rata.
 *
 * Pendekatan yang dipakai: **penelusuran ulang (replay)** seluruh
 * pergerakan stok sebuah produk setiap kali ada posting/void. Cara ini
 * dipilih supaya koreksi (void) selalu konsisten: dokumen yang di-void
 * tidak ikut dihitung, jadi lapisan & HPP-nya otomatis hilang dan angka
 * kembali seperti sebelum dokumen itu ada.
 * ============================================================ */

/** Jenis pergerakan yang MENAMBAH stok (membentuk lapisan baru). */
function fifo_in_types(): array
{
    return ['inbound', 'opening', 'return_customer', 'adjustment', 'opname'];
}

/** Jenis pergerakan yang MENGURANGI stok (memakai lapisan tertua). */
function fifo_out_types(): array
{
    return ['outbound', 'return_supplier', 'adjustment', 'opname'];
}

/** Harga satuan tiap baris dokumen masuk/keluar, untuk keperluan FIFO. */
function fifo_cost_maps(): array
{
    $maps = ['inbound' => [], 'return' => []];
    foreach (db_all('SELECT inbound_id, product_id, unit_cost, unit_cost_net FROM inbound_items') as $r) {
        $net = (float)$r['unit_cost_net'];
        if ($net <= 0) $net = (float)$r['unit_cost'];
        $maps['inbound'][(int)$r['inbound_id'] . ':' . (int)$r['product_id']] = $net;
    }
    foreach (db_all('SELECT return_id, product_id, unit_price FROM return_items') as $r) {
        $maps['return'][(int)$r['return_id'] . ':' . (int)$r['product_id']] = (float)$r['unit_price'];
    }
    return $maps;
}

/** Kumpulan id dokumen yang berstatus void (pergerakan void tidak dihitung ulang). */
function fifo_voided_ids(): array
{
    $out = ['inbound' => [], 'outbound' => [], 'return' => [], 'adjustment' => [], 'opname' => []];
    foreach (['inbound' => 'inbounds', 'outbound' => 'outbounds', 'return' => 'returns',
              'adjustment' => 'adjustments', 'opname' => 'opnames'] as $key => $table) {
        foreach (db_all("SELECT id FROM $table WHERE status = 'void'") as $r) {
            $out[$key][(int)$r['id']] = true;
        }
    }
    return $out;
}

/**
 * Harga satuan sebuah pergerakan masuk, dengan urutan prioritas:
 *   1. harga yang tersimpan di baris dokumen sumber (inbound net / retur / penyesuaian)
 *   2. harga yang tersimpan di kartu stok (ledger.unit_cost)
 *   3. HPP produk saat ini sebagai cadangan terakhir
 */
function fifo_unit_cost(array $row, array $maps, float $fallback): float
{
    $type = (string)$row['ref_type'];
    $refId = (int)($row['ref_id'] ?? 0);
    $pid = (int)$row['product_id'];
    $ledgerCost = (float)($row['unit_cost'] ?? 0);

    if ($type === 'inbound') {
        $c = $maps['inbound'][$refId . ':' . $pid] ?? 0.0;
        if ($c > 0) return $c;
    }
    if ($type === 'return_customer') {
        $c = $maps['return'][$refId . ':' . $pid] ?? 0.0;
        if ($c > 0) return $c;
    }
    if ($ledgerCost > 0) return $ledgerCost;
    return $fallback;
}

/**
 * Susun ulang lapisan FIFO + HPP untuk satu atau semua produk.
 *
 * Setelah selesai:
 *   - stock_layers   = lapisan stok yang masih tersisa beserta harganya
 *   - layer_uses     = rincian HPP setiap barang keluar (per dokumen)
 *   - products.cost_price         = HPP rata-rata tertimbang sisa stok
 *   - products.cost_price_initial = harga penerimaan pertama (HPP awal)
 *   - outbound_items.cogs/_cogs_unit = HPP FIFO tiap baris barang keluar
 *   - ledger.unit_cost = harga satuan pergerakan (untuk masuk: harga beli,
 *     untuk keluar: HPP FIFO hasil perhitungan)
 *
 * @param array<int,int>|null $productIds null = semua produk
 * @param bool $inTransaction dipanggil dari dalam transaksi yang sudah berjalan?
 * @return array{products:int, layers:int, uses:int, unlayered:float}
 */
function fifo_rebuild(?array $productIds = null, bool $inTransaction = false): array
{
    $run = function () use ($productIds): array {
        $maps = fifo_cost_maps();
        $voided = fifo_voided_ids();

        if ($productIds === null) {
            $ids = array_map(static fn($r) => (int)$r['id'], db_all('SELECT id FROM products ORDER BY id'));
        } else {
            $ids = array_values(array_unique(array_map('intval', $productIds)));
        }
        if (!$ids) return ['products' => 0, 'layers' => 0, 'uses' => 0, 'unlayered' => 0.0];

        $stat = ['products' => 0, 'layers' => 0, 'uses' => 0, 'unlayered' => 0.0];

        foreach ($ids as $pid) {
            $product = db_one('SELECT id, sku, cost_price, cost_price_initial FROM products WHERE id = ?', [$pid]);
            if (!$product) continue;

            /* mulai dari kertas kosong untuk produk ini */
            db_run('DELETE FROM layer_uses WHERE product_id = ?', [$pid]);
            db_run('DELETE FROM stock_layers WHERE product_id = ?', [$pid]);

            /* Urutan penelusuran: tanggal, lalu barang MASUK lebih dulu pada tanggal yang sama,
               baru barang keluar. Tanpa aturan ini, barang keluar yang tercatat lebih dulu
               (id lebih kecil) akan "memakai" lapisan yang sebenarnya baru masuk belakangan
               pada hari yang sama — mis. setelah void lalu input ulang dokumen koreksi. */
            $rows = db_all(
                "SELECT id, move_date, product_id, qty_change, unit_cost, ref_type, ref_id, ref_no
                   FROM ledger WHERE product_id = ?
                  ORDER BY move_date,
                           CASE WHEN qty_change > 0 THEN 0 ELSE 1 END,
                           id",
                [$pid]
            );

            $queue = [];            // daftar lapisan aktif: ['id','qty','cost']
            $remainingByLayer = []; // id lapisan => sisa (termasuk 0 untuk yang habis)
            $inQty = 0.0;           // total qty semua penerimaan
            $inValue = 0.0;         // total nilai semua penerimaan
            $runQty = 0.0;          // sisa & nilai berjalan (untuk rata-rata berjalan)
            $runVal = 0.0;
            $firstCost = 0.0;       // harga penerimaan pertama (HPP awal)
            $usesBatch = [];
            $cogsByRef = [];        // ['outbound:12' => total HPP]
            $cogsQtyByRef = [];
            $ledgerCostUpdates = [];
            $fallback = (float)$product['cost_price_initial'] > 0
                ? (float)$product['cost_price_initial']
                : (float)$product['cost_price'];

            foreach ($rows as $row) {
                $pid2 = (int)$row['product_id'];
                $type = (string)$row['ref_type'];
                $delta = (float)$row['qty_change'];
                $refKey = '';
                $base = $type;
                if (str_ends_with($type, '_void')) {
                    /* baris pembatalan: dokumen aslinya sudah dikecualikan di bawah */
                    $base = substr($type, 0, -5);
                    $refKey = ($base === 'return_supplier' || $base === 'return_customer') ? 'return' : $base;
                } else {
                    $refKey = ($type === 'return_supplier' || $type === 'return_customer') ? 'return' : $type;
                }

                /* dokumen yang di-void: baris asli maupun pembatalannya tidak dihitung */
                if (isset($voided[$refKey][(int)($row['ref_id'] ?? 0)])) {
                    continue;
                }

                if (abs($delta) < 0.0000001) {
                    /* pergerakan nol (mis. produk didaftarkan): tetap catat untuk jejak */
                    continue;
                }

                if ($delta > 0) {
                    /* Harga lapisan:
                       - barang masuk (inbound) & stok awal: harga pembelian dokumen tersebut
                       - barang kembali dari customer / penyesuaian naik: rata-rata HPP saat itu
                         (barang kembali bukan pembelian baru, jadi tidak boleh memakai harga jual) */
                    if (in_array($base, ['inbound', 'opening'], true)) {
                        $cost = fifo_unit_cost($row, $maps, $fallback);
                    } else {
                        $cost = $runQty > 0 ? ($runVal / $runQty) : $fallback;
                    }
                    if ($cost <= 0) $cost = $fallback;
                    if ($firstCost <= 0.0) $firstCost = $cost;

                    db_run(
                        'INSERT INTO stock_layers (product_id, move_date, ledger_id, ref_type, ref_id, ref_no, qty_original, qty_remaining, unit_cost, created_at)
                         VALUES (?,?,?,?,?,?,?,?,?,?)',
                        [$pid2, (string)$row['move_date'], (int)$row['id'], $base, (int)($row['ref_id'] ?? 0),
                         (string)($row['ref_no'] ?? ''), $delta, $delta, $cost, now()]
                    );
                    $layerId = (int)db()->lastInsertId();
                    $queue[] = ['id' => $layerId, 'qty' => $delta, 'cost' => $cost];
                    $remainingByLayer[$layerId] = $delta;
                    $inQty += $delta;
                    $inValue += $delta * $cost;
                    $runQty += $delta;
                    $runVal += $delta * $cost;
                    $stat['layers']++;
                    $ledgerCostUpdates[(int)$row['id']] = $cost;
                    continue;
                }

                /* pergerakan keluar: ambil dari lapisan tertua */
                $need = -$delta;
                $takenCost = 0.0;
                $takenQty = 0.0;
                while ($need > 0.0000001 && $queue) {
                    $idx = array_key_first($queue);
                    $take = min($need, $queue[$idx]['qty']);
                    if ($take <= 0) { array_shift($queue); continue; }
                    $queue[$idx]['qty'] -= $take;
                    $remainingByLayer[$queue[$idx]['id']] = $queue[$idx]['qty'];
                    $need -= $take;
                    $takenQty += $take;
                    $takenCost += $take * $queue[$idx]['cost'];
                    $runQty -= $take;
                    $runVal -= $take * $queue[$idx]['cost'];
                    if ($runQty < 0.0000001) { $runQty = 0.0; if ($runVal < 0.01) $runVal = 0.0; }

                    $usesBatch[] = [
                        'layer_id' => $queue[$idx]['id'], 'pid' => $pid2, 'ledger_id' => (int)$row['id'],
                        'move_date' => (string)$row['move_date'], 'ref_type' => $base,
                        'ref_id' => (int)($row['ref_id'] ?? 0), 'ref_no' => (string)($row['ref_no'] ?? ''),
                        'qty' => $take, 'unit_cost' => $queue[$idx]['cost'], 'total_cost' => $take * $queue[$idx]['cost'],
                    ];

                    if ($queue[$idx]['qty'] <= 0.0000001) array_shift($queue);
                }

                if ($takenQty > 0) {
                    $unitFifo = $takenCost / $takenQty;
                    $ledgerCostUpdates[(int)$row['id']] = $unitFifo;
                    $stat['uses']++;
                    $key = $base . ':' . (int)($row['ref_id'] ?? 0);
                    $cogsByRef[$key] = ($cogsByRef[$key] ?? 0.0) + $takenCost;
                    $cogsQtyByRef[$key] = ($cogsQtyByRef[$key] ?? 0.0) + $takenQty;
                }
                if ($need > 0.0000001) {
                    /* stok keluar melebihi lapisan yang ada (data lama/migrasi) */
                    $stat['unlayered'] += $need;
                }
            }

            /* simpan pemakaian lapisan */
            foreach ($usesBatch as $u) {
                db_run(
                    'INSERT INTO layer_uses (layer_id, product_id, ledger_id, move_date, ref_type, ref_id, ref_no, qty, unit_cost, total_cost, created_at)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                    [$u['layer_id'], $u['pid'], $u['ledger_id'], $u['move_date'], $u['ref_type'], $u['ref_id'],
                     $u['ref_no'], $u['qty'], $u['unit_cost'], $u['total_cost'], now()]
                );
            }

            /* Perbarui sisa SEMUA lapisan — termasuk yang sudah habis (harus jadi 0).
               Kalau lapisan yang habis dibiarkan, HPP rata-rata ikut menghitung stok
               yang sebenarnya sudah tidak ada. */
            foreach ($remainingByLayer as $layerId => $qty) {
                db_run('UPDATE stock_layers SET qty_remaining = ? WHERE id = ?',
                    [abs($qty) < 0.0000001 ? 0.0 : $qty, $layerId]);
            }

            /* harga satuan di kartu stok */
            foreach ($ledgerCostUpdates as $lid => $c) {
                db_run('UPDATE ledger SET unit_cost = ? WHERE id = ?', [round($c, 2), $lid]);
            }

            /* HPP rata-rata = nilai lapisan sisa / jumlah sisa */
            $remainingQty = 0.0;
            $remainingVal = 0.0;
            foreach (db_all('SELECT qty_remaining, unit_cost FROM stock_layers WHERE product_id = ?', [$pid]) as $l) {
                $q = (float)$l['qty_remaining'];
                if ($q <= 0) continue;
                $remainingQty += $q;
                $remainingVal += $q * (float)$l['unit_cost'];
            }
            if ($remainingQty > 0) {
                $avg = round($remainingVal / $remainingQty, 2);
            } elseif ($inQty > 0) {
                /* stok habis (atau minus karena void setelah barang terjual):
                   HPP rata-rata tetap diisi rata-rata tertimbang seluruh pembelian
                   supaya angkanya tidak menyesatkan (bukan harga pembelian terakhir). */
                $avg = round($inValue / $inQty, 2);
            } else {
                $avg = (float)$product['cost_price'];
            }
            /* HPP awal: dari penerimaan pertama. Bila belum ada penerimaan sama sekali,
               pakai nilai HPP awal yang sudah tersimpan; kalau itu pun kosong (produk lama),
               pakai HPP rata-rata supaya tidak pernah tampil Rp 0. */
            if ($firstCost > 0) {
                $initial = round($firstCost, 2);
            } elseif ((float)$product['cost_price_initial'] > 0) {
                $initial = (float)$product['cost_price_initial'];
            } else {
                $initial = $avg;
            }
            db_run('UPDATE products SET cost_price = ?, cost_price_initial = ?, updated_at = ? WHERE id = ?',
                [$avg, $initial, now(), $pid]);

            /* HPP FIFO tiap baris barang keluar */
            foreach ($cogsByRef as $key => $total) {
                [$type, $refId] = explode(':', $key);
                if ($type !== 'outbound') continue;
                $total = round($total, 2);
                $qty = (float)($cogsQtyByRef[$key] ?? 0);
                $unit = $qty > 0 ? round($total / $qty, 2) : 0.0;
                $items = db_all('SELECT id, qty FROM outbound_items WHERE outbound_id = ? AND product_id = ? ORDER BY id', [(int)$refId, $pid]);
                $sumQty = 0.0;
                foreach ($items as $it) $sumQty += (float)$it['qty'];
                $allocated = 0.0;
                $lastItemId = null;
                foreach ($items as $it) {
                    $lastItemId = (int)$it['id'];
                    /* satu produk bisa muncul di lebih dari satu baris: bagi sesuai qty */
                    if ($sumQty > 0 && count($items) > 1) {
                        $share = round($total * ((float)$it['qty'] / $sumQty), 2);
                    } else {
                        $share = $total;
                    }
                    db_run('UPDATE outbound_items SET cogs = ?, cogs_unit = ? WHERE id = ?',
                        [$share, (float)$it['qty'] > 0 ? round($share / (float)$it['qty'], 2) : 0.0, (int)$it['id']]);
                    $allocated += $share;
                }
                /* sisa pembulatan ke baris terakhir */
                if ($lastItemId !== null && count($items) > 1) {
                    $diff = round($total - $allocated, 2);
                    if (abs($diff) >= 0.01) {
                        $row = db_one('SELECT cogs, qty FROM outbound_items WHERE id = ?', [$lastItemId]);
                        if ($row) {
                            $newTotal = round((float)$row['cogs'] + $diff, 2);
                            db_run('UPDATE outbound_items SET cogs = ?, cogs_unit = ? WHERE id = ?',
                                [$newTotal, (float)$row['qty'] > 0 ? round($newTotal / (float)$row['qty'], 2) : 0.0, $lastItemId]);
                        }
                    }
                }
            }
            /* dokumen keluar yang tidak (lagi) posted -> HPP-nya dikosongkan */
            db_run("UPDATE outbound_items SET cogs = 0, cogs_unit = 0
                     WHERE product_id = ? AND outbound_id IN (SELECT id FROM outbounds WHERE status <> 'posted')", [$pid]);

            $stat['products']++;
        }

        return $stat;
    };

    return $inTransaction ? $run() : db_tx($run);
}
