<?php
declare(strict_types=1);

/* ============================================================
 * Dokumen & pergerakan stok
 * Semua pergerakan stok lewat apply_move() supaya kartu stok
 * (ledger) selalu konsisten dengan products.stock_qty.
 * ============================================================ */

function next_doc_no(string $key, string $prefix, string $date): string
{
    $d = date('Ymd', strtotime($date) ?: time());
    $ck = $key . ':' . $d;
    db_run('INSERT OR IGNORE INTO counters (k, v) VALUES (?, 0)', [$ck]);
    db_run('UPDATE counters SET v = v + 1 WHERE k = ?', [$ck]);
    $n = (int)db_scalar('SELECT v FROM counters WHERE k = ?', [$ck]);
    return $prefix . '-' . $d . '-' . str_pad((string)$n, 4, '0', STR_PAD_LEFT);
}

function product_stock(int $productId): float
{
    return (float)(db_scalar('SELECT stock_qty FROM products WHERE id = ?', [$productId]) ?? 0);
}

function apply_move(int $productId, float $qtyChange, string $moveDate, string $refType, int $refId, string $refNo, string $note = '', ?int $userId = null, float $unitCost = 0.0): float
{
    $u = current_user();
    $uid = $userId ?? ($u ? (int)$u['id'] : null);
    $current = product_stock($productId);
    $after = $current + $qtyChange;
    db_run('UPDATE products SET stock_qty = ?, updated_at = ? WHERE id = ?', [$after, now(), $productId]);
    db_run(
        'INSERT INTO ledger (move_date, product_id, qty_change, qty_after, unit_cost, ref_type, ref_id, ref_no, note, user_id, created_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)',
        [$moveDate, $productId, $qtyChange, $after, $unitCost, $refType, $refId, $refNo, $note, $uid, now()]
    );
    return $after;
}

function doc_label(string $refType): string
{
    $map = [
        'inbound' => 'Barang Masuk',
        'outbound' => 'Barang Keluar',
        'adjustment' => 'Penyesuaian Stok',
        'opname' => 'Stok Opname',
        'return_supplier' => 'Retur ke Supplier',
        'return_customer' => 'Retur dari Customer',
    ];
    $base = $refType;
    $suffix = '';
    if (str_ends_with($refType, '_void')) {
        $base = substr($refType, 0, -5);
        $suffix = ' (pembatalan)';
    }
    if (str_starts_with($base, 'opening')) {
        return 'Stok Awal';
    }
    return ($map[$base] ?? $base) . $suffix;
}

/* ---------------- pengambilan item ---------------- */

function doc_items(string $type, int $id): array
{
    $map = [
        'inbound' => ['inbound_items', 'inbound_id', 'unit_cost'],
        'outbound' => ['outbound_items', 'outbound_id', 'unit_price'],
        'adjustment' => ['adjustment_items', 'adjustment_id', 'qty_after'],
        'opname' => ['opname_items', 'opname_id', 'qty_counted'],
        'return' => ['return_items', 'return_id', 'unit_price'],
    ];
    [$table, $fk, $priceCol] = $map[$type] ?? [null, null, null];
    if (!$table) return [];
    return db_all(
        "SELECT i.*, p.sku, p.unit
           FROM $table i JOIN products p ON p.id = i.product_id
          WHERE i.$fk = ?
          ORDER BY i.id",
        [$id]
    );
}

/**
 * Daftar SKU (beserta qty) untuk sekumpulan dokumen — dipakai daftar Barang Masuk
 * dan Barang Keluar supaya terlihat dokumen mana memuat SKU apa, dan supaya
 * pencarian per SKU hasilnya bisa diperiksa langsung di tabel.
 *
 * Satu query untuk semua dokumen di halaman (bukan satu query per baris).
 *
 * @param string $type 'inbound' | 'outbound' | 'return'
 * @param int[]  $ids  id dokumen
 * @return array<int,array<int,array{sku:string,qty:float}>>
 */
function doc_sku_map(string $type, array $ids): array
{
    $map = [
        'inbound' => ['inbound_items', 'inbound_id'],
        'outbound' => ['outbound_items', 'outbound_id'],
        'return' => ['return_items', 'return_id'],
    ];
    [$table, $fk] = $map[$type] ?? [null, null];
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn($v) => $v > 0)));
    if (!$table || !$ids) return [];

    $ph = implode(',', array_fill(0, count($ids), '?'));
    $rows = db_all(
        "SELECT i.$fk AS doc_id, p.sku, i.qty
           FROM $table i JOIN products p ON p.id = i.product_id
          WHERE i.$fk IN ($ph)
          ORDER BY i.$fk, i.id",
        $ids
    );
    $out = [];
    foreach ($rows as $r) {
        $out[(int)$r['doc_id']][] = ['sku' => (string)$r['sku'], 'qty' => (float)$r['qty']];
    }
    return $out;
}

/**
 * Teks ringkas daftar SKU satu dokumen: "SKU1 ×2, SKU2" (maksimal $limit SKU).
 * Teks lengkapnya dipakai sebagai tooltip supaya semua SKU tetap bisa dilihat.
 *
 * @return array{short:string,full:string,count:int}
 */
function doc_sku_summary(array $skus, int $limit = 3): array
{
    $fmtOne = static fn(array $s): string => $s['sku'] . ((float)$s['qty'] > 1 ? ' ×' . fmt_qty($s['qty']) : '');
    $full = implode(', ', array_map($fmtOne, $skus));
    $short = implode(', ', array_map($fmtOne, array_slice($skus, 0, $limit)));
    $more = count($skus) - min($limit, count($skus));
    if ($more > 0) $short .= ' +' . $more . ' SKU';
    return ['short' => $short, 'full' => $full, 'count' => count($skus)];
}

function recalc_doc_totals(string $type, int $id): void
{
    if ($type === 'inbound') {
        $r = db_one('SELECT COALESCE(SUM(qty),0) q, COALESCE(SUM(subtotal),0) a FROM inbound_items WHERE inbound_id = ?', [$id]);
        $doc = db_one('SELECT discount_type, discount_value FROM inbounds WHERE id = ?', [$id]);
        $gross = (float)$r['a'];
        $disc = inbound_discount_amount($gross, (string)($doc['discount_type'] ?? 'percent'), (float)($doc['discount_value'] ?? 0));
        db_run(
            'UPDATE inbounds SET total_qty = ?, subtotal_amount = ?, discount_amount = ?, total_amount = ? WHERE id = ?',
            [(float)$r['q'], $gross, $disc, round($gross - $disc, 2), $id]
        );
    } elseif ($type === 'outbound') {
        $r = db_one('SELECT COALESCE(SUM(qty),0) q, COALESCE(SUM(subtotal),0) a FROM outbound_items WHERE outbound_id = ?', [$id]);
        db_run('UPDATE outbounds SET total_qty = ?, total_amount = ? WHERE id = ?', [(float)$r['q'], (float)$r['a'], $id]);
    } elseif ($type === 'adjustment') {
        $r = db_one('SELECT COUNT(*) c, COALESCE(SUM(delta),0) d FROM adjustment_items WHERE adjustment_id = ?', [$id]);
        db_run('UPDATE adjustments SET total_items = ?, total_delta = ? WHERE id = ?', [(int)$r['c'], (float)$r['d'], $id]);
    } elseif ($type === 'opname') {
        $r = db_one('SELECT COUNT(*) c, COALESCE(SUM(diff),0) d FROM opname_items WHERE opname_id = ?', [$id]);
        db_run('UPDATE opnames SET total_items = ?, total_diff = ? WHERE id = ?', [(int)$r['c'], (float)$r['d'], $id]);
    } elseif ($type === 'return') {
        $r = db_one('SELECT COALESCE(SUM(qty),0) q, COALESCE(SUM(subtotal),0) a FROM return_items WHERE return_id = ?', [$id]);
        db_run('UPDATE returns SET total_qty = ?, total_amount = ? WHERE id = ?', [(float)$r['q'], (float)$r['a'], $id]);
    }
}

/* ---------------- posting ---------------- */

function post_document(string $type, int $id): array
{
    try {
        return db_tx(function () use ($type, $id) {
            $u = current_user();
            $uid = $u ? (int)$u['id'] : null;
            $plan = [];
            $docNo = '';
            $moveDate = today();
            $refType = $type === 'return' ? '' : $type;

            if ($type === 'inbound') {
                $d = db_one('SELECT * FROM inbounds WHERE id = ?', [$id]);
                if (!$d) throw new RuntimeException('Dokumen tidak ditemukan.');
                if ($d['status'] !== 'draft') throw new RuntimeException('Dokumen ini sudah tidak berstatus draft.');
                $docNo = (string)$d['doc_no'];
                $moveDate = (string)$d['doc_date'];
                $refType = 'inbound';
                foreach (doc_items('inbound', $id) as $it) {
                    /* harga satuan setelah diskon dipakai sebagai harga lapisan FIFO */
                    $net = (float)($it['unit_cost_net'] ?? 0);
                    if ($net <= 0) $net = (float)($it['unit_cost'] ?? 0);
                    $plan[] = [(int)$it['product_id'], (float)$it['qty'], $net];
                }
            } elseif ($type === 'outbound') {
                $d = db_one('SELECT * FROM outbounds WHERE id = ?', [$id]);
                if (!$d) throw new RuntimeException('Dokumen tidak ditemukan.');
                if ($d['status'] !== 'draft') throw new RuntimeException('Dokumen ini sudah tidak berstatus draft.');
                $docNo = (string)$d['doc_no'];
                $moveDate = (string)$d['doc_date'];
                $refType = 'outbound';
                $short = [];
                foreach (doc_items('outbound', $id) as $it) {
                    $qty = (float)$it['qty'];
                    $have = product_stock((int)$it['product_id']);
                    if ($qty > $have + 0.00001) {
                        $short[] = $it['sku'] . ' (butuh ' . fmt_qty($qty) . ', tersedia ' . fmt_qty($have) . ')';
                    }
                    $plan[] = [(int)$it['product_id'], -$qty, (float)$it['unit_price']];
                }
                if ($short) {
                    throw new RuntimeException('Stok tidak cukup untuk: ' . implode('; ', $short));
                }
            } elseif ($type === 'adjustment') {
                $d = db_one('SELECT * FROM adjustments WHERE id = ?', [$id]);
                if (!$d) throw new RuntimeException('Dokumen tidak ditemukan.');
                if ($d['status'] !== 'draft') throw new RuntimeException('Dokumen ini sudah tidak berstatus draft.');
                $docNo = (string)$d['doc_no'];
                $moveDate = (string)$d['doc_date'];
                $refType = 'adjustment';
                foreach (doc_items('adjustment', $id) as $it) {
                    $pid = (int)$it['product_id'];
                    $before = product_stock($pid);
                    $after = (float)$it['qty_after'];
                    db_run('UPDATE adjustment_items SET qty_before = ?, delta = ? WHERE id = ?', [$before, $after - $before, (int)$it['id']]);
                    $plan[] = [$pid, $after - $before, 0.0];
                }
            } elseif ($type === 'opname') {
                $d = db_one('SELECT * FROM opnames WHERE id = ?', [$id]);
                if (!$d) throw new RuntimeException('Dokumen tidak ditemukan.');
                if ($d['status'] !== 'draft') throw new RuntimeException('Dokumen ini sudah tidak berstatus draft.');
                $docNo = (string)$d['doc_no'];
                $moveDate = (string)$d['doc_date'];
                $refType = 'opname';
                foreach (doc_items('opname', $id) as $it) {
                    $pid = (int)$it['product_id'];
                    $before = product_stock($pid);
                    $counted = (float)$it['qty_counted'];
                    db_run('UPDATE opname_items SET qty_system = ?, diff = ? WHERE id = ?', [$before, $counted - $before, (int)$it['id']]);
                    $plan[] = [$pid, $counted - $before, 0.0];
                }
            } elseif ($type === 'return') {
                $d = db_one('SELECT * FROM returns WHERE id = ?', [$id]);
                if (!$d) throw new RuntimeException('Dokumen tidak ditemukan.');
                if ($d['status'] !== 'draft') throw new RuntimeException('Dokumen ini sudah tidak berstatus draft.');
                $docNo = (string)$d['doc_no'];
                $moveDate = (string)$d['doc_date'];
                $refType = $d['type'] === 'supplier' ? 'return_supplier' : 'return_customer';
                $sign = $d['type'] === 'supplier' ? -1 : 1;
                if ($sign < 0) {
                    $short = [];
                    foreach (doc_items('return', $id) as $it) {
                        $have = product_stock((int)$it['product_id']);
                        if ((float)$it['qty'] > $have + 0.00001) {
                            $short[] = $it['sku'] . ' (butuh ' . fmt_qty($it['qty']) . ', tersedia ' . fmt_qty($have) . ')';
                        }
                    }
                    if ($short) throw new RuntimeException('Stok tidak cukup untuk retur: ' . implode('; ', $short));
                }
                foreach (doc_items('return', $id) as $it) {
                    $plan[] = [(int)$it['product_id'], $sign * (float)$it['qty'], (float)$it['unit_price']];
                }
            } else {
                throw new RuntimeException('Jenis dokumen tidak dikenal.');
            }

            if (!$plan) throw new RuntimeException('Dokumen belum memiliki item.');

            foreach ($plan as [$pid, $delta, $cost]) {
                if (abs($delta) < 0.0000001) continue;
                apply_move($pid, $delta, $moveDate, $refType, $id, $docNo, '', $uid, (float)$cost);
            }

            $tbl = ['inbound' => 'inbounds', 'outbound' => 'outbounds', 'adjustment' => 'adjustments', 'opname' => 'opnames', 'return' => 'returns'][$type];
            db_run("UPDATE $tbl SET status = 'posted', posted_by = ?, posted_at = ? WHERE id = ?", [$uid, now(), $id]);
            recalc_doc_totals($type, $id);

            /* susun ulang FIFO: HPP rata-rata, HPP awal, dan HPP tiap barang keluar */
            $touched = array_values(array_unique(array_map(static fn($r) => (int)$r[0], $plan)));
            fifo_rebuild($touched, true);

            log_activity('posting', 'Posting dokumen ' . doc_label($refType) . ' ' . $docNo, $refType, $docNo);
            return ['ok' => true, 'errors' => [], 'doc_no' => $docNo];
        });
    } catch (Throwable $ex) {
        return ['ok' => false, 'errors' => [$ex->getMessage()], 'doc_no' => ''];
    }
}

function void_document(string $type, int $id, string $reason): array
{
    try {
        return db_tx(function () use ($type, $id, $reason) {
            $u = current_user();
            $uid = $u ? (int)$u['id'] : null;
            $tbl = ['inbound' => 'inbounds', 'outbound' => 'outbounds', 'adjustment' => 'adjustments', 'opname' => 'opnames', 'return' => 'returns'][$type] ?? null;
            if (!$tbl) throw new RuntimeException('Jenis dokumen tidak dikenal.');
            $d = db_one("SELECT * FROM $tbl WHERE id = ?", [$id]);
            if (!$d) throw new RuntimeException('Dokumen tidak ditemukan.');
            if ($d['status'] !== 'posted') throw new RuntimeException('Hanya dokumen berstatus Posted yang bisa di-void.');

            if ($type === 'return') {
                $refType = $d['type'] === 'supplier' ? 'return_supplier' : 'return_customer';
            } else {
                $refType = $type;
            }

            $rows = db_all(
                'SELECT * FROM ledger WHERE ref_type = ? AND ref_id = ? AND qty_change <> 0 ORDER BY id DESC',
                [$refType, $id]
            );
            if (!$rows) throw new RuntimeException('Tidak ada pergerakan stok yang tercatat untuk dokumen ini.');

            $touched = [];
            foreach ($rows as $r) {
                apply_move(
                    (int)$r['product_id'],
                    -(float)$r['qty_change'],
                    (string)$r['move_date'],
                    $refType . '_void',
                    $id,
                    (string)$d['doc_no'],
                    'Pembatalan: ' . $reason,
                    $uid,
                    (float)($r['unit_cost'] ?? 0)
                );
                $touched[] = (int)$r['product_id'];
            }

            /* Status diubah lebih dulu: penelusuran ulang FIFO mengabaikan dokumen void,
               sehingga lapisan (layer) dari dokumen ini hilang dan HPP kembali seperti semula. */
            db_run("UPDATE $tbl SET status = 'void', void_reason = ?, voided_by = ?, voided_at = ? WHERE id = ?", [$reason, $uid, now(), $id]);
            if ($touched) fifo_rebuild(array_values(array_unique($touched)), true);
            log_activity('void', 'Void dokumen ' . doc_label($refType) . ' ' . $d['doc_no'] . ' — alasan: ' . $reason, $refType, (string)$d['doc_no']);

            /* beri tahu bila ada stok yang menjadi minus akibat void ini */
            $minus = [];
            foreach (array_unique($touched) as $pid) {
                $stok = product_stock((int)$pid);
                if ($stok < -0.0000001) {
                    $sku = (string)(db_scalar('SELECT sku FROM products WHERE id = ?', [(int)$pid]) ?? ('#' . $pid));
                    $minus[] = $sku . ' = ' . fmt_qty($stok);
                }
            }
            $warning = $minus
                ? 'PERHATIAN: stok berikut menjadi minus karena dokumen ini di-void: ' . e(implode(', ', $minus))
                  . '. Isi dokumen masuk pengganti atau lakukan Stok Adjustment supaya stok kembali benar.'
                : '';

            return ['ok' => true, 'errors' => [], 'doc_no' => (string)$d['doc_no'], 'warning' => $warning];
        });
    } catch (Throwable $ex) {
        return ['ok' => false, 'errors' => [$ex->getMessage()], 'doc_no' => ''];
    }
}

/**
 * Buka dokumen yang SUDAH DIPOSTING supaya bisa dikoreksi/diedit.
 *
 * Kenapa perlu fungsi khusus: dokumen posted sudah mengubah stok & lapisan FIFO.
 * Kalau isinya diedit begitu saja, stok dan HPP menjadi tidak cocok. Alur di sini:
 *   1. pergerakan stok lama dibalik lewat apply_move() → stok kembali seperti sebelum posting
 *      (baris pembatalan sementara itu langsung dihapus lagi, jadi kartu stok tidak dipenuhi
 *      baris bolak-balik setiap kali dokumen dikoreksi),
 *   2. baris kartu stok lama dokumen ini dihapus, sehingga FIFO/HPP dihitung ulang HANYA
 *      dari isi dokumen yang baru,
 *   3. status dokumen kembali 'draft' agar pemanggil bisa menyimpan isi baru lalu
 *      memposting ulang lewat post_document().
 * Nilai lama dicatat di Log Aktivitas (siapa, kapan, isi sebelum & sesudah) supaya
 * jejak audit tetap ada.
 *
 * WAJIB dipanggil di dalam transaksi (db_tx) bersama penyimpanan isi barunya,
 * supaya kegagalan posting ulang membatalkan seluruh koreksi (dokumen kembali utuh).
 *
 * @param array<int,array<string,mixed>> $oldItems baris dokumen lama untuk jejak audit
 * @return array{ok:bool,doc_no:string,touched:int[]}
 */
function reopen_posted_document(string $type, int $id, string $reason, array $oldItems = []): array
{
    $tbl = ['inbound' => 'inbounds', 'outbound' => 'outbounds', 'adjustment' => 'adjustments',
            'opname' => 'opnames', 'return' => 'returns'][$type] ?? null;
    if (!$tbl) throw new RuntimeException('Jenis dokumen tidak dikenal.');

    $d = db_one("SELECT * FROM $tbl WHERE id = ?", [$id]);
    if (!$d) throw new RuntimeException('Dokumen tidak ditemukan.');
    if ((string)$d['status'] !== 'posted') {
        throw new RuntimeException('Hanya dokumen berstatus Posted yang perlu dibuka ulang.');
    }

    $refType = $type === 'return'
        ? ((string)$d['type'] === 'supplier' ? 'return_supplier' : 'return_customer')
        : $type;

    $rows = db_all(
        'SELECT * FROM ledger WHERE ref_type = ? AND ref_id = ? AND qty_change <> 0 ORDER BY id DESC',
        [$refType, $id]
    );
    if (!$rows) throw new RuntimeException('Tidak ada pergerakan stok yang tercatat untuk dokumen ini.');

    $u = current_user();
    $uid = $u ? (int)$u['id'] : null;
    $docNo = (string)$d['doc_no'];
    $touched = [];

    foreach ($rows as $r) {
        $pid = (int)$r['product_id'];
        /* balik pergerakan stok lama (via apply_move supaya cache stok tetap lewat jalur resmi) */
        apply_move($pid, -(float)$r['qty_change'], (string)$r['move_date'], $refType . '_void', $id, $docNo,
            'Koreksi dokumen: ' . $reason, $uid, (float)($r['unit_cost'] ?? 0));
        /* baris pembatalan sementara tidak perlu disimpan: isi dokumen akan diganti */
        db_run('DELETE FROM ledger WHERE id = ?', [(int)db()->lastInsertId()]);
        $touched[] = $pid;
    }
    /* hapus jejak kartu stok versi lama; nilainya sudah dicatat di Log Aktivitas */
    db_run('DELETE FROM ledger WHERE ref_type = ? AND ref_id = ?', [$refType, $id]);

    db_run("UPDATE $tbl SET status = 'draft', posted_by = NULL, posted_at = NULL WHERE id = ?", [$id]);

    /* ringkas isi lama untuk jejak audit */
    $before = [];
    foreach ($oldItems as $it) {
        $before[] = (string)($it['sku'] ?? ('#' . (int)($it['product_id'] ?? 0)))
            . ' ×' . fmt_qty($it['qty'] ?? 0);
    }
    log_activity('edit', 'Koreksi dokumen ' . doc_label($refType) . ' ' . $docNo
        . ($before ? ' (sebelum dikoreksi: ' . implode(', ', $before) . ')' : '')
        . ' — alasan: ' . $reason, $refType, $docNo);

    $touched = array_values(array_unique($touched));
    fifo_rebuild($touched, true);

    return ['ok' => true, 'doc_no' => $docNo, 'touched' => $touched];
}

/**
 * Peringatan bila setelah posting/koreksi ada stok yang menjadi minus.
 * Stok minus bisa terjadi saat dokumen masuk dikoreksi/di-void setelah barangnya terjual.
 *
 * @param int[] $productIds
 */
function stock_negative_warning(array $productIds): string
{
    $minus = [];
    foreach (array_values(array_unique(array_map('intval', $productIds))) as $pid) {
        $stok = product_stock($pid);
        if ($stok < -0.0000001) {
            $sku = (string)(db_scalar('SELECT sku FROM products WHERE id = ?', [$pid]) ?? ('#' . $pid));
            $minus[] = $sku . ' = ' . fmt_qty($stok);
        }
    }
    if (!$minus) return '';
    return 'PERHATIAN: stok berikut menjadi minus setelah perubahan ini: ' . e(implode(', ', $minus))
        . '. Isi dokumen masuk pengganti atau lakukan Stok Adjustment supaya stok kembali benar.';
}

/**
 * Perkiraan dampak void terhadap stok untuk banyak dokumen sekaligus.
 * Dipakai halaman daftar supaya peringatan bisa muncul SEBELUM dokumen di-void —
 * void pada dokumen masuk akan mengurangi stok, dan kalau barangnya sudah terjual
 * stok bisa menjadi minus. Kejadian itu harus terlihat, bukan tersembunyi.
 *
 * @param array<int,array{0:string,1:int}> $refs  contoh: [['inbound', 12], ['outbound', 4]]
 * @return array<string,array<int,array{sku:string,qty:float,after:float}>> kunci "jenis:id"
 */
function void_impacts(array $refs): array
{
    $out = [];
    if (!$refs) return $out;

    $byType = [];
    foreach ($refs as $r) {
        $type = (string)($r[0] ?? '');
        $id = (int)($r[1] ?? 0);
        if ($id <= 0 || !in_array($type, ['inbound', 'outbound', 'adjustment', 'opname', 'return'], true)) continue;
        $byType[$type][] = $id;
        $out[$type . ':' . $id] = [];
    }
    if (!$byType) return $out;

    /* retur: jenis ref_type-nya tergantung tipe retur */
    $returRef = [];
    if (!empty($byType['return'])) {
        foreach (db_all('SELECT id, type FROM returns WHERE id IN (' . implode(',', array_fill(0, count($byType['return']), '?')) . ')', $byType['return']) as $r) {
            $returRef[(int)$r['id']] = $r['type'] === 'supplier' ? 'return_supplier' : 'return_customer';
        }
    }

    foreach ($byType as $type => $ids) {
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $rows = db_all(
            "SELECT ref_id, ref_type, product_id, SUM(qty_change) AS q
               FROM ledger WHERE ref_type IN ('$type', '{$type}_void') AND ref_id IN ($ph)
              GROUP BY ref_id, ref_type, product_id",
            $ids
        );
        /* buang baris pembatalan: yang dihitung hanya pergerakan dokumen aslinya */
        foreach ($rows as $row) {
            if (str_ends_with((string)$row['ref_type'], '_void')) continue;
            $refId = (int)$row['ref_id'];
            if ($type === 'return') {
                $want = $returRef[$refId] ?? '';
                if ($want !== (string)$row['ref_type']) continue;
            }
            $delta = -(float)$row['q'];            // void membalik arah pergerakan
            if ($delta >= -0.0000001) continue;    // hanya yang akan MENGURANGI stok
            $pid = (int)$row['product_id'];
            $sku = (string)(db_scalar('SELECT sku FROM products WHERE id = ?', [$pid]) ?? ('#' . $pid));
            $out[$type . ':' . $refId][] = [
                'sku' => $sku,
                'qty' => abs($delta),
                'after' => product_stock($pid) + $delta,
            ];
        }
    }
    return $out;
}

/** Kalimat konfirmasi void, lengkap dengan peringatan bila stok akan minus. */
function void_confirm_text(string $type, int $id, string $docNo, ?array $impact = null): string
{
    $label = [
        'inbound' => 'barang masuk', 'outbound' => 'barang keluar',
        'adjustment' => 'penyesuaian stok', 'opname' => 'stok opname', 'return' => 'retur',
    ][$type] ?? 'dokumen';
    $msg = 'Void dokumen ' . $label . ' ' . $docNo . '?';
    if ($impact === null) {
        $impacts = void_impacts([[$type, $id]]);
        $impact = $impacts[$type . ':' . $id] ?? [];
    }
    $minus = array_values(array_filter($impact, static fn($x) => (float)$x['after'] < -0.0000001));
    if ($minus) {
        $list = [];
        foreach ($minus as $x) {
            $list[] = $x['sku'] . ' (stok menjadi ' . fmt_qty($x['after']) . ')';
        }
        return $msg . ' PERHATIAN: stok akan menjadi MINUS untuk ' . implode(', ', $list)
            . '. Sebaiknya isi dokumen masuk penggantinya lebih dulu. Lanjutkan void?';
    }
    return $msg . ' Stok akan dikembalikan seperti sebelum dokumen ini dibuat.';
}

function doc_ledger_rows(string $refType, int $id): array
{
    return db_all(
        'SELECT l.*, p.sku FROM ledger l JOIN products p ON p.id = l.product_id
          WHERE l.ref_id = ? AND (l.ref_type = ? OR l.ref_type = ?) ORDER BY l.id',
        [$id, $refType, $refType . '_void']
    );
}

/* ---------------- diskon dokumen barang masuk ---------------- */

/**
 * Hitung nilai diskon dokumen dari tipe ('percent' | 'amount') dan nilainya.
 * Persen dibatasi 0-100, rupiah dibatasi maksimum sebesar subtotal (tidak boleh minus).
 */
function inbound_discount_amount(float $subtotal, string $type, float $value): float
{
    if ($subtotal <= 0 || $value <= 0) return 0.0;
    if ($type === 'percent') {
        return round($subtotal * min(100.0, $value) / 100, 2);
    }
    return round(min($subtotal, $value), 2);
}

/**
 * Bagikan diskon dokumen secara proporsional ke setiap baris, lalu simpan harga satuan
 * setelah diskon (unit_cost_net). Contoh: 2 pcs @50.000 (100.000) dengan diskon 10%
 * -> tiap baris dapat diskon 5.000 per pcs sehingga harga satunya jadi 45.000.
 * Sisa pembulatan diberikan ke baris terakhir supaya total diskon tetap pas.
 */
function apply_inbound_discount(int $docId): void
{
    $doc = db_one('SELECT discount_type, discount_value FROM inbounds WHERE id = ?', [$docId]);
    $items = db_all('SELECT id, qty, subtotal FROM inbound_items WHERE inbound_id = ? ORDER BY id', [$docId]);
    if (!$doc || !$items) return;

    $gross = 0.0;
    foreach ($items as $it) $gross += (float)$it['subtotal'];
    $disc = inbound_discount_amount($gross, (string)($doc['discount_type'] ?? 'percent'), (float)($doc['discount_value'] ?? 0));

    $allocated = 0.0;
    $last = count($items) - 1;
    foreach ($items as $idx => $it) {
        $sub = (float)$it['subtotal'];
        $qty = (float)$it['qty'];
        if ($disc <= 0 || $gross <= 0) {
            $share = 0.0;
        } elseif ($idx === $last) {
            $share = round($disc - $allocated, 2);
        } else {
            $share = round($disc * $sub / $gross, 2);
            $allocated += $share;
        }
        $net = round($sub - $share, 2);
        $unitNet = $qty > 0 ? round($net / $qty, 2) : 0.0;
        db_run(
            'UPDATE inbound_items SET discount_share = ?, unit_cost_net = ?, subtotal_net = ? WHERE id = ?',
            [$share, $unitNet, $net, (int)$it['id']]
        );
    }
}

/**
 * Susun daftar item "yang sedang diisi" dari input form (belum disimpan).
 * Dipakai saat validasi gagal: datanya dikembalikan ke halaman supaya tidak hilang,
 * jadi pengguna tidak perlu memindai ulang seluruh barang hanya karena lupa satu kolom.
 *
 * @return array<int,array<string,mixed>> bentuknya sama dengan doc_items('inbound')
 */
function draft_inbound_items(array $skus, array $qtys, array $costs, string $discType = 'percent', float $discValue = 0.0): array
{
    $resolved = resolve_skus($skus);
    $items = [];
    foreach ($skus as $i => $rawSku) {
        $pid = $resolved['ids'][$i] ?? null;
        if (!$pid) continue;
        $p = db_one('SELECT p.sku, p.unit, p.cost_price FROM products p WHERE p.id = ?', [(int)$pid]);
        if (!$p) continue;
        $qty = parse_qty($qtys[$i] ?? 0);
        $cost = parse_num($costs[$i] ?? 0);
        if ($qty <= 0) $qty = 1;                 // baris tetap tampil walau jumlah belum diisi
        $items[] = [
            'product_id' => (int)$pid,
            'sku' => (string)$p['sku'],
            'unit' => (string)$p['unit'],
            'qty' => $qty,
            'unit_cost' => $cost,
            'subtotal' => $qty * $cost,
            'discount_share' => 0.0,
            'unit_cost_net' => $cost,
            'subtotal_net' => $qty * $cost,
        ];
    }
    /* tampilkan angka setelah diskon agar sama seperti yang dilihat pengguna sebelum gagal simpan */
    if ($items && $discValue > 0) {
        $gross = 0.0;
        foreach ($items as $it) $gross += (float)$it['subtotal'];
        $disc = inbound_discount_amount($gross, $discType, $discValue);
        $alloc = 0.0;
        $last = count($items) - 1;
        foreach ($items as $idx => $it) {
            $share = 0.0;
            if ($disc > 0 && $gross > 0) {
                $share = $idx === $last ? round($disc - $alloc, 2) : round($disc * (float)$it['subtotal'] / $gross, 2);
                if ($idx !== $last) $alloc += $share;
            }
            $net = round((float)$it['subtotal'] - $share, 2);
            $items[$idx]['discount_share'] = $share;
            $items[$idx]['subtotal_net'] = $net;
            $items[$idx]['unit_cost_net'] = (float)$it['qty'] > 0 ? round($net / (float)$it['qty'], 2) : 0.0;
        }
    }
    return $items;
}

/* ---------------- penyimpanan item ---------------- */

function product_exists(int $pid): bool
{
    return (bool)db_scalar('SELECT 1 FROM products WHERE id = ?', [$pid]);
}

/** Cari produk berdasarkan SKU (tidak peka huruf besar/kecil). */
function product_by_sku(string $sku): ?array
{
    $sku = strtoupper(trim($sku));
    if ($sku === '') return null;
    $row = db_one(
        "SELECT p.*, b.name AS brand_name FROM products p LEFT JOIN brands b ON b.id = p.brand_id
          WHERE UPPER(p.sku) = ?",
        [$sku]
    );
    return $row ?: null;
}

/**
 * Terjemahkan daftar SKU (hasil scan/ketik) menjadi id produk.
 * Indeks hasil sejajar dengan indeks input supaya bisa dipakai per baris.
 *
 * @return array{ids:array<int,int|null>, unknown:array<int,string>}
 */
function resolve_skus(array $skus): array
{
    $ids = [];
    $unknown = [];
    foreach ($skus as $i => $raw) {
        $sku = strtoupper(trim((string)$raw));
        if ($sku === '') { $ids[$i] = null; continue; }
        $p = product_by_sku($sku);
        if ($p && (int)$p['active'] === 1) {
            $ids[$i] = (int)$p['id'];
        } else {
            $ids[$i] = null;
            $unknown[] = $sku . ($p ? ' (nonaktif)' : '');
        }
    }
    return ['ids' => $ids, 'unknown' => array_values(array_unique($unknown))];
}

/** Rangkum SKU yang tidak dikenali menjadi satu pesan singkat. */
function unknown_sku_message(array $unknown, int $limit = 8): string
{
    $list = array_slice($unknown, 0, $limit);
    $more = count($unknown) - count($list);
    return 'SKU berikut tidak terdaftar dan barisnya dilewati: <strong>' . e(implode(', ', $list)) . '</strong>'
        . ($more > 0 ? ' (dan ' . $more . ' SKU lainnya)' : '')
        . '. Daftarkan dulu di Produk Master.';
}

/**
 * Buat produk baru. Produk diidentifikasi hanya dengan SKU (tanpa nama produk).
 * Kolom lama products.name (bila masih ada di database versi lama) diisi SKU
 * supaya constraint NOT NULL tidak dilanggar.
 */
function product_create(string $sku, ?int $brandId, ?int $supplierId, string $category, string $unit, float $cost, float $sell, float $minStock, int $active, string $size = ''): int
{
    /* $supplierId hanya demi kompatibilitas pemanggil lama; supplier ditentukan di dokumen inbound. */
    /* HPP awal = harga yang diketik saat produk dibuat. Ini yang dipakai sebagai default
       harga di form barang masuk (bukan HPP rata-rata hasil FIFO). */
    $size = normalize_size($size);
    if (products_has_name_column()) {
        db_run(
            'INSERT INTO products (sku, name, brand_id, category, size, unit, cost_price, cost_price_initial, sell_price, min_stock, stock_qty, active, created_at, updated_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,0,?,?,?)',
            [$sku, $sku, $brandId, $category, $size, $unit, $cost, $cost, $sell, $minStock, $active, now(), now()]
        );
    } else {
        db_run(
            'INSERT INTO products (sku, brand_id, category, size, unit, cost_price, cost_price_initial, sell_price, min_stock, stock_qty, active, created_at, updated_at)
             VALUES (?,?,?,?,?,?,?,?,?,0,?,?,?)',
            [$sku, $brandId, $category, $size, $unit, $cost, $cost, $sell, $minStock, $active, now(), now()]
        );
    }
    return (int)db()->lastInsertId();
}

function save_inbound_items(int $docId, array $pids, array $qtys, array $costs): void
{
    db_run('DELETE FROM inbound_items WHERE inbound_id = ?', [$docId]);
    foreach ($pids as $i => $pidRaw) {
        $pid = (int)$pidRaw;
        $qty = parse_qty($qtys[$i] ?? 0);
        if ($pid <= 0 || $qty <= 0 || !product_exists($pid)) continue;
        $cost = parse_num($costs[$i] ?? 0);
        db_run(
            'INSERT INTO inbound_items (inbound_id, product_id, qty, unit_cost, subtotal, discount_share, unit_cost_net, subtotal_net)
             VALUES (?,?,?,?,?,0,?,?)',
            [$docId, $pid, $qty, $cost, $qty * $cost, $cost, $qty * $cost]
        );
    }
}

function save_outbound_items(int $docId, array $pids, array $qtys, array $prices): void
{
    db_run('DELETE FROM outbound_items WHERE outbound_id = ?', [$docId]);
    foreach ($pids as $i => $pidRaw) {
        $pid = (int)$pidRaw;
        $qty = parse_qty($qtys[$i] ?? 0);
        if ($pid <= 0 || $qty <= 0 || !product_exists($pid)) continue;
        $price = parse_num($prices[$i] ?? 0);
        db_run(
            'INSERT INTO outbound_items (outbound_id, product_id, qty, unit_price, subtotal) VALUES (?,?,?,?,?)',
            [$docId, $pid, $qty, $price, $qty * $price]
        );
    }
}

function save_return_items(int $docId, array $pids, array $qtys, array $prices): void
{
    db_run('DELETE FROM return_items WHERE return_id = ?', [$docId]);
    foreach ($pids as $i => $pidRaw) {
        $pid = (int)$pidRaw;
        $qty = parse_qty($qtys[$i] ?? 0);
        if ($pid <= 0 || $qty <= 0 || !product_exists($pid)) continue;
        $price = parse_num($prices[$i] ?? 0);
        db_run(
            'INSERT INTO return_items (return_id, product_id, qty, unit_price, subtotal) VALUES (?,?,?,?,?)',
            [$docId, $pid, $qty, $price, $qty * $price]
        );
    }
}

/** qty_after = hasil hitung fisik yang dimasukkan user (0 tetap valid) */
function save_adjustment_items(int $docId, array $pids, array $afters): void
{
    db_run('DELETE FROM adjustment_items WHERE adjustment_id = ?', [$docId]);
    $seen = [];
    foreach ($pids as $i => $pidRaw) {
        $pid = (int)$pidRaw;
        if ($pid <= 0 || isset($seen[$pid]) || !product_exists($pid)) continue;
        $raw = $afters[$i] ?? '';
        if (trim((string)$raw) === '') continue;
        $seen[$pid] = true;
        $after = parse_qty($raw);
        $before = product_stock($pid);
        db_run(
            'INSERT INTO adjustment_items (adjustment_id, product_id, qty_before, qty_after, delta) VALUES (?,?,?,?,?)',
            [$docId, $pid, $before, $after, $after - $before]
        );
    }
}

function save_opname_items(int $docId, array $pids, array $counteds): void
{
    db_run('DELETE FROM opname_items WHERE opname_id = ?', [$docId]);
    $seen = [];
    foreach ($pids as $i => $pidRaw) {
        $pid = (int)$pidRaw;
        if ($pid <= 0 || isset($seen[$pid]) || !product_exists($pid)) continue;
        $raw = $counteds[$i] ?? '';
        if (trim((string)$raw) === '') continue;
        $seen[$pid] = true;
        $counted = parse_qty($raw);
        $sys = product_stock($pid);
        db_run(
            'INSERT INTO opname_items (opname_id, product_id, qty_system, qty_counted, diff) VALUES (?,?,?,?,?)',
            [$docId, $pid, $sys, $counted, $counted - $sys]
        );
    }
}
