<?php
require_once __DIR__ . '/includes/init.php';
require_perm('inv.view');

$q = (string)get('q');
$brandF = (int)get('brand_id');
$catF = (string)get('category');
$onlyLow = get('low') === '1';
$sizeF = normalize_size(get('size'));
/* periode untuk kolom arus masuk/keluar; kosong = tidak dihitung */
$pFrom = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)get('from')) ? (string)get('from') : '';
$pTo = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)get('to')) ? (string)get('to') : '';
$usePeriod = $pFrom !== '' && $pTo !== '';
if ($usePeriod && $pFrom > $pTo) { $t = $pFrom; $pFrom = $pTo; $pTo = $t; }
/* ---- pengurutan: klik judul kolom (▲ naik / ▼ turun) ---- */
$sort = (string)get('sort', 'sku');
$dir = strtolower((string)get('dir')) === 'desc' ? 'desc' : 'asc';
/* nilai lama tetap diterima supaya tautan/bookmark & uji yang sudah ada tidak rusak */
$legacySort = ['stock_desc' => ['stock', 'desc'], 'stock_asc' => ['stock', 'asc'], 'value_desc' => ['value', 'desc']];
if (isset($legacySort[$sort])) { $dir = $legacySort[$sort][1]; $sort = $legacySort[$sort][0]; }
$sortCols = [
    'sku' => 'p.sku',
    'brand' => "COALESCE(b.name,'zzz')",
    'category' => "COALESCE(NULLIF(p.category,''),'zzz')",
    'size' => "COALESCE(NULLIF(p.size,''),'zzz')",
    'unit' => 'p.unit',
    'stock' => 'p.stock_qty',
    'min' => 'p.min_stock',
    'hpp_initial' => 'COALESCE(NULLIF(p.cost_price_initial,0), p.cost_price)',
    'hpp_avg' => 'p.cost_price',
    'value' => 'stock_value',
    'age' => "(julianday('now') - julianday(p.created_at))",
    'qty_in' => 'COALESCE(m.qty_in,0)',
    'qty_out' => 'COALESCE(s.qty,0)',
    'sold_value' => 'COALESCE(s.amount,0)',
    /* total seumur artikel (sejak pertama tercatat di kartu stok) */
    'in_total' => 'COALESCE(mt.qty_in,0)',
    'out_total' => 'COALESCE(st.qty,0)',
    'rotation' => '(COALESCE(mt.qty_in,0) + COALESCE(st.qty,0))',
    'status' => 'CASE WHEN p.stock_qty <= p.min_stock THEN 1 ELSE 0 END',
];
/* kolom arus hanya ada saat periode diisi; kalau tidak, kembali ke urutan SKU */
if (in_array($sort, ['qty_in', 'qty_out', 'sold_value'], true) && !$usePeriod) { $sort = 'sku'; $dir = 'asc'; }
if (!isset($sortCols[$sort])) { $sort = 'sku'; $dir = 'asc'; }

$where = ['p.active = 1'];
$params = [];
if ($q !== '') { $where[] = '(p.sku LIKE ? OR p.category LIKE ? OR p.size LIKE ?)'; $params[] = "%$q%"; $params[] = "%$q%"; $params[] = "%$q%"; }
if ($brandF > 0) { $where[] = 'p.brand_id = ?'; $params[] = $brandF; }
if ($catF !== '') { $where[] = 'p.category = ?'; $params[] = $catF; }
if ($sizeF !== '') { $where[] = 'p.size = ?'; $params[] = $sizeF; }
if ($onlyLow) { $where[] = 'p.stock_qty <= p.min_stock'; }
$wsql = 'WHERE ' . implode(' AND ', $where);
/* kolom kedua sebagai penentu urutan bila nilainya sama (mis. stok 0 semua) */
$order = $sortCols[$sort] . ' ' . strtoupper($dir) . ($sort === 'sku' ? '' : ', p.sku ASC');

$total = (int)db_scalar("SELECT COUNT(*) FROM products p $wsql", $params);
$pg = pager($total, 30);

/* ---- Agregat SEUMUR ARTIKEL (selalu dihitung, tanpa batas tanggal) ----
   "Masuk" = barang masuk + retur dari customer + stok awal (pembatalan ikut mengurangi,
   karena baris `*_void` tetap bertanda negatif). "Keluar" = barang keluar berstatus posted.
   Hasilnya: berapa pcs artikel ini sudah berputar sejak pertama tercatat. */
$lifetime = "LEFT JOIN (SELECT l.product_id,
                    SUM(CASE WHEN REPLACE(l.ref_type,'_void','') IN ('inbound','return_customer','opening')
                             THEN l.qty_change ELSE 0 END) AS qty_in,
                    MIN(CASE WHEN l.qty_change > 0 THEN l.move_date END) AS first_in
               FROM ledger l GROUP BY l.product_id) mt ON mt.product_id = p.id
          LEFT JOIN (SELECT i.product_id, SUM(i.qty) AS qty
                       FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
                      WHERE o.status = 'posted' GROUP BY i.product_id) st ON st.product_id = p.id";

if ($usePeriod) {
    $rows = db_all(
        "SELECT p.*, b.name AS brand_name, (p.stock_qty * p.cost_price) AS stock_value,
                MAX(0, CAST(julianday('now') - julianday(p.created_at) AS INTEGER)) AS umur_hari,
                COALESCE(m.qty_in,0) AS qty_in, COALESCE(s.qty,0) AS qty_out,
                COALESCE(s.amount,0) AS sold_amount, COALESCE(s.docs,0) AS sold_docs,
                COALESCE(mt.qty_in,0) AS in_total, COALESCE(st.qty,0) AS out_total,
                (COALESCE(mt.qty_in,0) + COALESCE(st.qty,0)) AS rotation, mt.first_in
           FROM products p LEFT JOIN brands b ON b.id = p.brand_id
           $lifetime
           LEFT JOIN (SELECT l.product_id,
                             SUM(CASE WHEN REPLACE(l.ref_type,'_void','') IN ('inbound','return_customer','opening') THEN l.qty_change ELSE 0 END) AS qty_in
                        FROM ledger l WHERE l.move_date BETWEEN ? AND ? GROUP BY l.product_id) m ON m.product_id = p.id
           LEFT JOIN (SELECT i.product_id, SUM(i.qty) AS qty, SUM(i.subtotal) AS amount, COUNT(DISTINCT o.id) AS docs
                        FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
                       WHERE o.status = 'posted' AND o.doc_date BETWEEN ? AND ?
                       GROUP BY i.product_id) s ON s.product_id = p.id
           $wsql ORDER BY $order LIMIT {$pg['per']} OFFSET {$pg['offset']}",
        array_merge([$pFrom, $pTo, $pFrom, $pTo], $params)
    );
} else {
    $rows = db_all(
        "SELECT p.*, b.name AS brand_name, (p.stock_qty * p.cost_price) AS stock_value,
                MAX(0, CAST(julianday('now') - julianday(p.created_at) AS INTEGER)) AS umur_hari,
                NULL AS qty_in, NULL AS qty_out, NULL AS sold_amount, NULL AS sold_docs,
                COALESCE(mt.qty_in,0) AS in_total, COALESCE(st.qty,0) AS out_total,
                (COALESCE(mt.qty_in,0) + COALESCE(st.qty,0)) AS rotation, mt.first_in
           FROM products p LEFT JOIN brands b ON b.id = p.brand_id
           $lifetime
           $wsql ORDER BY $order LIMIT {$pg['per']} OFFSET {$pg['offset']}",
        $params
    );
}
$sumQty = (float)(db_scalar("SELECT COALESCE(SUM(p.stock_qty),0) FROM products p $wsql", $params) ?? 0);
$sumVal = (float)(db_scalar("SELECT COALESCE(SUM(p.stock_qty * p.cost_price),0) FROM products p $wsql", $params) ?? 0);
$sumSell = (float)(db_scalar("SELECT COALESCE(SUM(p.stock_qty * p.sell_price),0) FROM products p $wsql", $params) ?? 0);
$lowCount = (int)db_scalar("SELECT COUNT(*) FROM products p $wsql AND p.stock_qty <= p.min_stock", $params);
/* Total putaran seluruh SKU yang sedang difilter (seumur artikel) */
$sumInTotal = (float)(db_scalar(
    "SELECT COALESCE(SUM(CASE WHEN REPLACE(l.ref_type,'_void','') IN ('inbound','return_customer','opening')
                              THEN l.qty_change ELSE 0 END),0)
       FROM ledger l JOIN products p ON p.id = l.product_id $wsql",
    $params
) ?? 0);
$sumOutTotal = (float)(db_scalar(
    "SELECT COALESCE(SUM(i.qty),0)
       FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
       JOIN products p ON p.id = i.product_id
      WHERE o.status = 'posted' AND " . substr($wsql, 6),
    $params
) ?? 0);
$cats = db_all("SELECT DISTINCT category FROM products WHERE category <> '' ORDER BY category");
$brands = db_all('SELECT id, name FROM brands ORDER BY name');

$minusList = db_all('SELECT id, sku, stock_qty, unit, min_stock FROM products WHERE active = 1 AND stock_qty < 0 ORDER BY stock_qty');

page_start('Stok Total', 'stock');
?>
<?php if ($minusList): ?>
<div class="alert alert-error">
  <strong>Perhatian: ada <?= fmt_num(count($minusList)) ?> SKU dengan stok minus.</strong>
  <ul style="margin:8px 0 0;padding-left:18px">
    <?php foreach ($minusList as $m): ?>
      <li><a href="sku_detail.php?id=<?= (int)$m['id'] ?>"><strong><?= e($m['sku']) ?></strong></a>
        — stok tercatat <?= fmt_qty($m['stock_qty']) ?> <?= e($m['unit']) ?>.
        Penyebab paling umum: <em>dokumen barang masuk di-void padahal barangnya sudah keluar</em>.</li>
    <?php endforeach; ?>
  </ul>
  <p style="margin:8px 0 0">Cara membetulkan: isi <a href="inbound_form.php"><strong>dokumen barang masuk</strong></a> pengganti
    dengan jumlah yang sesuai (cara paling rapi, jejaknya jelas), atau pakai
    <a href="adjustment_form.php"><strong>Stok Adjustment</strong></a> dengan alasan &ldquo;Koreksi Salah Input&rdquo;.</p>
</div>
<?php endif; ?>
<div class="grid grid-4">
  <div class="card stat"><span class="label">Jumlah SKU</span><span class="value"><?= fmt_num($total) ?></span><span class="hint">sesuai filter</span></div>
  <div class="card stat"><span class="label">Total Unit Stok</span><span class="value"><?= fmt_qty($sumQty) ?></span></div>
  <div class="card stat"><span class="label">Nilai Stok (HPP)</span><span class="value" style="font-size:20px"><?= fmt_money($sumVal) ?></span></div>
  <div class="card stat"><span class="label">Potensi Nilai Jual</span><span class="value" style="font-size:20px"><?= fmt_money($sumSell) ?></span><span class="hint"><?= fmt_num($lowCount) ?> SKU stok menipis</span></div>
</div>

<section class="card">
  <?php sku_scan_tools([
      'mode' => 'search',
      'target' => '#stock-search',
      'csrf' => csrf_token(),
      /* halaman ini punya kolom cari sendiri: jangan buka keyboard otomatis */
      'autofocus' => false,
      'hint' => 'Scan QR/barcode produk (kamera HP atau scanner USB/Bluetooth) atau ketik SKU lalu Enter. Kamera menutup sendiri setelah berhasil membaca, dan hasil pencarian langsung tampil.',
  ]); ?>
</section>

<section class="card">
  <?php card_start('Daftar Stok Produk', 'Angka stok dihitung dari seluruh mutasi (inbound, outbound, adjustment, opname, retur).',
      '<a class="btn btn-sm" href="ledger.php">' . icon('list') . ' Kartu Stok</a>'
      . '<a class="btn btn-sm" href="export.php?type=stock&from=' . e($usePeriod ? $pFrom : date('Y-m-01')) . '&to=' . e($usePeriod ? $pTo : today()) . '">' . icon('export') . ' Export Excel</a>'); ?>
      <p class="help" style="margin-bottom:14px">
        Kolom <strong>Masuk (total)</strong>, <strong>Keluar (total)</strong>, dan <strong>Putaran</strong> menghitung
        <strong>seluruh riwayat artikel</strong> sejak pertama tercatat di kartu stok (tidak tergantung periode) &mdash;
        jadi Anda bisa tahu satu SKU sudah berputar berapa pcs di inventory: masuk berapa, keluar berapa.
        <em>Putaran</em> = masuk + keluar. Tanggal kecil di bawah angka masuk menunjukkan kapan artikel itu mulai tercatat.
      </p>
      <p class="help" style="margin-bottom:14px">
        Total putaran untuk <strong>semua SKU pada filter ini</strong>:
        masuk <strong style="color:var(--ok)">+<?= fmt_qty($sumInTotal) ?></strong> pcs &middot;
        keluar <strong style="color:var(--danger)"><?= fmt_qty($sumOutTotal) ?></strong> pcs &middot;
        putaran <strong><?= fmt_qty($sumInTotal + $sumOutTotal) ?></strong> pcs
        (stok sekarang <?= fmt_qty($sumQty) ?> pcs).
      </p>
      <?php if (!$usePeriod): ?>
        <p class="help" style="margin-bottom:14px">Isi <strong>Periode</strong> di filter untuk melihat tambahan kolom Masuk, Terjual, dan Nilai Terjual
          pada periode itu (misalnya 1 &ndash; <?= e(fmt_date(today())) ?>). Klik SKU untuk membuka seluruh data inbound &amp; outbound-nya.</p>
      <?php else: ?>
        <p class="help" style="margin-bottom:14px">Kolom Masuk (periode) / Terjual (periode) / Nilai Terjual (periode) dihitung untuk
          <strong><?= e(fmt_date($pFrom)) ?> &ndash; <?= e(fmt_date($pTo)) ?></strong> (hanya dokumen berstatus Posted).
          Klik SKU untuk melihat seluruh data inbound &amp; outbound-nya.</p>
      <?php endif; ?>
      <p class="help" style="margin-bottom:14px">Klik <strong>judul kolom</strong> (SKU, Brand, Stok, &hellip; sampai Status) untuk mengurutkan:
        klik sekali = naik (▲), klik lagi = turun (▼). Contoh: klik <strong>Stok</strong> untuk melihat stok paling banyak.</p>
    <form class="filters" method="get" style="margin-bottom:18px">
      <div class="f-item" style="min-width:200px"><label>Cari produk</label><input type="text" name="q" id="stock-search" value="<?= e($q) ?>" placeholder="SKU / kategori / ukuran" autocomplete="off" spellcheck="false">
        <p class="help" style="margin-top:4px">Hasil langsung tampil saat Anda mengetik (tanpa memuat ulang halaman,
          jadi keyboard tidak tertutup). Tekan <strong>Enter</strong> untuk mencari ke seluruh data (semua halaman).</p>
      </div>
      <div class="f-item"><label>Brand</label>
        <select name="brand_id"><option value="0">Semua brand</option>
          <?php foreach ($brands as $b): ?><option value="<?= (int)$b['id'] ?>" <?= $brandF === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="f-item"><label>Kategori</label>
        <select name="category"><option value="">Semua kategori</option>
          <?php foreach ($cats as $c): ?><option value="<?= e($c['category']) ?>" <?= $catF === $c['category'] ? 'selected' : '' ?>><?= e($c['category']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="f-item"><label>Ukuran</label>
        <select name="size">
          <option value="">Semua ukuran</option>
          <?php foreach (product_sizes() as $sz): ?>
            <option value="<?= e($sz) ?>" <?= normalize_size(get('size')) === $sz ? 'selected' : '' ?>><?= e($sz) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <input type="hidden" name="sort" value="<?= e($sort) ?>">
      <input type="hidden" name="dir" value="<?= e($dir) ?>">
      <div class="f-item"><label>Periode dari</label><input type="date" name="from" value="<?= e($pFrom) ?>"></div>
      <div class="f-item"><label>Periode sampai</label><input type="date" name="to" value="<?= e($pTo) ?>"></div>
      <div class="f-item"><label>Filter</label>
        <label style="font-weight:500;display:flex;gap:8px;align-items:center;padding-top:6px">
          <input type="checkbox" name="low" value="1" style="width:auto" <?= $onlyLow ? 'checked' : '' ?>> Hanya stok menipis
        </label>
      </div>
      <button class="btn btn-primary" type="submit">Terapkan</button>
      <a class="btn" href="stock.php">Reset</a>
    </form>

    <div class="table-wrap">
      <table id="stockTable">
        <thead><tr>
          <th><?= sort_link('SKU', 'sku', $sort, $dir) ?></th>
          <th><?= sort_link('Brand', 'brand', $sort, $dir) ?></th>
          <th><?= sort_link('Kategori', 'category', $sort, $dir) ?></th>
          <th><?= sort_link('Ukuran', 'size', $sort, $dir) ?></th>
          <th><?= sort_link('Satuan', 'unit', $sort, $dir) ?></th>
          <th class="num"><?= sort_link('Stok', 'stock', $sort, $dir) ?></th>
          <th class="num"><?= sort_link('Min', 'min', $sort, $dir) ?></th>
          <th class="num"><?= sort_link('HPP Awal', 'hpp_initial', $sort, $dir) ?></th>
          <th class="num"><?= sort_link('HPP Rata-rata', 'hpp_avg', $sort, $dir) ?></th>
          <th class="num"><?= sort_link('Nilai Stok', 'value', $sort, $dir) ?></th>
          <th class="num"><?= sort_link('Umur', 'age', $sort, $dir) ?></th>
          <th class="num" title="Total barang masuk (termasuk retur dari customer & stok awal) sejak artikel pertama tercatat"><?= sort_link('Masuk (total)', 'in_total', $sort, $dir) ?></th>
          <th class="num" title="Total barang keluar terjual (dokumen posted) sejak artikel pertama tercatat"><?= sort_link('Keluar (total)', 'out_total', $sort, $dir) ?></th>
          <th class="num" title="Putaran = total masuk + total keluar (berapa pcs artikel ini sudah berputar di inventory)"><?= sort_link('Putaran', 'rotation', $sort, $dir) ?></th>
          <th class="num"><?= $usePeriod ? sort_link('Masuk (periode)', 'qty_in', $sort, $dir) : 'Masuk (periode)' ?></th>
          <th class="num"><?= $usePeriod ? sort_link('Terjual (periode)', 'qty_out', $sort, $dir) : 'Terjual (periode)' ?></th>
          <th class="num"><?= $usePeriod ? sort_link('Nilai Terjual (periode)', 'sold_value', $sort, $dir) : 'Nilai Terjual (periode)' ?></th>
          <th><?= sort_link('Status', 'status', $sort, $dir) ?></th>
          <th></th>
        </tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="19"><?= empty_state('Tidak ada produk dengan stok sesuai filter.') ?></td></tr><?php endif; ?>
        <?php foreach ($rows as $r): $low = (float)$r['stock_qty'] <= (float)$r['min_stock']; ?>
          <tr>
            <td class="mono"><a href="sku_detail.php?id=<?= (int)$r['id'] ?><?= $usePeriod ? '&from=' . e($pFrom) . '&to=' . e($pTo) : '' ?>"><?= e($r['sku']) ?></a></td>
            <td><?= e($r['brand_name'] ?? '-') ?></td>
            <td><?= e($r['category'] ?: '-') ?></td>
            <td><?= (string)($r['size'] ?? '') !== '' ? '<span class="badge badge-info">' . e($r['size']) . '</span>' : '<span class="muted">-</span>' ?></td>
            <td><?= e($r['unit']) ?></td>
            <td class="num"><strong><?= fmt_qty($r['stock_qty']) ?></strong></td>
            <td class="num"><?= fmt_qty($r['min_stock']) ?></td>
            <td class="num"><?= fmt_money($r['cost_price_initial'] ?: $r['cost_price']) ?></td>
            <td class="num"><strong><?= fmt_money($r['cost_price']) ?></strong></td>
            <td class="num"><?= fmt_money($r['stock_value']) ?></td>
            <td class="num"><?= fmt_num($r['umur_hari']) ?> <span class="muted">h</span></td>
            <?php $inTot = (float)($r['in_total'] ?? 0); $outTot = (float)($r['out_total'] ?? 0); $rot = $inTot + $outTot; ?>
            <td class="num">
              <?php if ($inTot > 0): ?>
                <span style="color:var(--ok)">+<?= fmt_qty($inTot) ?></span>
                <?php if (!empty($r['first_in'])): ?><div class="small muted">sejak <?= e(fmt_date($r['first_in'])) ?></div><?php endif; ?>
              <?php else: ?><span class="muted">-</span><?php endif; ?>
            </td>
            <td class="num">
              <?php if ($outTot > 0): ?>
                <strong style="color:var(--danger)"><?= fmt_qty($outTot) ?></strong>
              <?php else: ?><span class="muted">0</span><?php endif; ?>
            </td>
            <td class="num">
              <?php if ($rot > 0): ?>
                <strong><?= fmt_qty($rot) ?></strong> <span class="muted"><?= e($r['unit']) ?></span>
              <?php else: ?><span class="muted">-</span><?php endif; ?>
            </td>
            <td class="num"><?= $usePeriod ? (($r['qty_in'] !== null) ? '+' . fmt_qty($r['qty_in']) : '-') : '<span class="muted">-</span>' ?></td>
            <td class="num"><?= $usePeriod ? '<strong>' . fmt_qty($r['qty_out']) . '</strong>' : '<span class="muted">-</span>' ?></td>
            <td class="num"><?= $usePeriod ? fmt_money($r['sold_amount']) : '<span class="muted">-</span>' ?></td>
            <td><?= $low ? '<span class="badge badge-warn">Menipis</span>' : '<span class="badge badge-ok">Aman</span>' ?></td>
            <td class="nowrap">
              <a class="btn btn-sm" href="sku_detail.php?id=<?= (int)$r['id'] ?>">Riwayat</a>
              <a class="btn btn-sm" href="ledger.php?product_id=<?= (int)$r['id'] ?>">Kartu Stok</a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?= render_pager($pg) ?>
  <?php card_end(); ?>
</section>
<script src="<?= e(asset_url('assets/sku.js')) ?>"></script>
<script>
/* Pencarian langsung: baris tabel disaring SAAT MENGETIK tanpa memuat ulang halaman.
   JANGAN dikembalikan ke pola "auto-submit" (dulu: setTimeout 400 ms lalu form.submit()):
   di HP setiap muat ulang menutup lalu membuka keyboard lagi, sehingga ketikan terasa
   "dimulai dari awal" dan huruf yang diketik saat halaman berganti bisa hilang.
   Enter / tombol Terapkan tetap dipakai untuk pencarian ke SELURUH data (semua halaman). */
(function () {
  var inp = document.getElementById('stock-search');
  var table = document.getElementById('stockTable');
  if (!inp || !table) return;

  var tbody = table.tBodies[0];
  if (!tbody) return;
  var allRows = Array.prototype.slice.call(tbody.rows).filter(function (tr) {
    /* lewati baris "tidak ada produk" (satu sel dengan colspan) */
    return !(tr.cells.length === 1 && tr.cells[0].hasAttribute('colspan'));
  });
  allRows.forEach(function (tr) { tr.dataset.filterText = (tr.textContent || '').toLowerCase(); });

  var noticeId = 'stock-filter-note';
  function notice(msg) {
    var el = document.getElementById(noticeId);
    if (!msg) { if (el) el.remove(); return; }
    if (!el) {
      el = document.createElement('div');
      el.id = noticeId;
      el.className = 'alert alert-warn';
      el.style.marginBottom = '12px';
      table.parentNode.parentNode.insertBefore(el, table.parentNode);
    }
    el.innerHTML = msg;
  }

  function applyFilter() {
    var term = inp.value.trim().toLowerCase();
    if (term === '') {
      allRows.forEach(function (tr) { tr.style.display = ''; });
      notice('');
      return;
    }
    var shown = 0;
    allRows.forEach(function (tr) {
      var hit = (tr.dataset.filterText || '').indexOf(term) !== -1;
      tr.style.display = hit ? '' : 'none';
      if (hit) shown++;
    });
    if (shown === 0) {
      notice('<strong>Tidak ada yang cocok di halaman ini.</strong> Tekan <strong>Enter</strong> untuk mencari '
        + 'ke seluruh data (semua halaman), atau hapus sebagian ketikan.');
    } else {
      notice('');
    }
  }

  inp.addEventListener('input', applyFilter);
  /* saat pindah halaman / hasil pencarian server, kolom cari dikosongkan dr filter layar */
  inp.addEventListener('search', applyFilter);
  applyFilter();
  /* Catatan: bila halaman dibuka dengan ?q=… (mis. hasil scan), baris sudah disaring server;
     filter layar bekerja di atas hasil itu. Tombol Reset mengembalikan daftar penuh. */
})();
</script>
<?php page_end(); ?>
