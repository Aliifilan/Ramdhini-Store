<?php
require_once __DIR__ . '/includes/init.php';
require_perm('inv.view');

$productId = (int)get('product_id');
$to = input_date('to', today());
$from = input_date('from', date('Y-m-d', strtotime($to . ' -29 days')));
$refF = (string)get('ref_type');
$q = (string)get('q');

$where = ['date(l.move_date) BETWEEN ? AND ?'];
$params = [$from, $to];
if ($productId > 0) { $where[] = 'l.product_id = ?'; $params[] = $productId; }
if ($refF !== '') { $where[] = '(l.ref_type = ? OR l.ref_type = ?)'; $params[] = $refF; $params[] = $refF . '_void'; }
if ($q !== '') { $where[] = '(p.sku LIKE ? OR l.ref_no LIKE ? OR l.note LIKE ?)'; array_push($params, "%$q%", "%$q%", "%$q%"); }
$wsql = 'WHERE ' . implode(' AND ', $where);

$total = (int)db_scalar("SELECT COUNT(*) FROM ledger l JOIN products p ON p.id = l.product_id $wsql", $params);
$pg = pager($total, 50);
$rows = db_all(
    "SELECT l.*, p.sku, p.unit, u.name AS user_name
       FROM ledger l JOIN products p ON p.id = l.product_id
       LEFT JOIN users u ON u.id = l.user_id
       $wsql ORDER BY l.id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}",
    $params
);
$sumIn = (float)(db_scalar("SELECT COALESCE(SUM(l.qty_change),0) FROM ledger l JOIN products p ON p.id=l.product_id $wsql AND l.qty_change > 0", $params) ?? 0);
$sumOut = (float)(db_scalar("SELECT COALESCE(SUM(l.qty_change),0) FROM ledger l JOIN products p ON p.id=l.product_id $wsql AND l.qty_change < 0", $params) ?? 0);

$products = db_all('SELECT id, sku FROM products ORDER BY sku');
$selProduct = $productId > 0 ? db_one('SELECT * FROM products WHERE id = ?', [$productId]) : null;
$stockNow = $selProduct ? (float)$selProduct['stock_qty'] : null;
$refTypes = ['inbound' => 'Barang Masuk', 'outbound' => 'Barang Keluar', 'adjustment' => 'Penyesuaian Stok', 'opname' => 'Stok Opname', 'return_supplier' => 'Retur ke Supplier', 'return_customer' => 'Retur dari Customer'];

page_start('Kartu Stok / Mutasi', 'ledger');
?>
<div class="grid grid-4">
  <div class="card stat"><span class="label">Jumlah Mutasi</span><span class="value"><?= fmt_num($total) ?></span><span class="hint">baris pada periode</span></div>
  <div class="card stat"><span class="label">Total Masuk</span><span class="value" style="color:var(--ok)">+<?= fmt_qty($sumIn) ?></span></div>
  <div class="card stat"><span class="label">Total Keluar</span><span class="value" style="color:var(--danger)"><?= fmt_qty($sumOut) ?></span></div>
  <div class="card stat"><span class="label"><?= $selProduct ? 'Stok Saat Ini' : 'Stok Saat Ini (Semua Produk)' ?></span>
    <span class="value"><?= fmt_qty($stockNow !== null ? $stockNow : (float)(db_scalar('SELECT COALESCE(SUM(stock_qty),0) FROM products') ?? 0)) ?></span>
    <span class="hint"><?= $selProduct ? e($selProduct['sku']) : 'total semua produk' ?></span>
  </div>
</div>

<section class="card">
  <?php card_start('Riwayat Pergerakan Stok', 'Setiap baris menampilkan stok setelah mutasi (saldo berjalan).',
      '<a class="btn btn-sm" href="export.php?type=ledger&' . e(qs(['page' => null])) . '">' . icon('export') . ' Export Excel</a>'); ?>
    <form class="filters" method="get" style="margin-bottom:18px">
      <div class="f-item" style="min-width:230px"><label>Produk</label>
        <select name="product_id">
          <option value="0">Semua produk</option>
          <?php foreach ($products as $p): ?>
            <option value="<?= (int)$p['id'] ?>" <?= $productId === (int)$p['id'] ? 'selected' : '' ?>><?= e($p['sku']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="f-item"><label>Dari</label><input type="date" name="from" value="<?= e($from) ?>"></div>
      <div class="f-item"><label>Sampai</label><input type="date" name="to" value="<?= e($to) ?>"></div>
      <div class="f-item"><label>Jenis Mutasi</label>
        <select name="ref_type">
          <option value="">Semua jenis</option>
          <?php foreach ($refTypes as $k => $v): ?><option value="<?= e($k) ?>" <?= $refF === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="f-item"><label>Cari</label><input type="text" name="q" value="<?= e($q) ?>" placeholder="SKU / no dokumen / catatan"></div>
      <button class="btn btn-primary" type="submit">Terapkan</button>
      <a class="btn" href="ledger.php">Reset</a>
    </form>

    <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal &middot; Jam</th><th>No. Dokumen</th><th>Jenis</th><th>SKU</th><th class="num">Masuk</th><th class="num">Keluar</th><th class="num">Saldo Stok</th><th>Petugas</th><th>Catatan</th></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="9"><?= empty_state('Tidak ada mutasi stok pada periode ini.') ?></td></tr><?php endif; ?>
        <?php foreach ($rows as $r): $ch = (float)$r['qty_change']; ?>
          <tr>
            <td class="nowrap"><?= e(fmt_date($r['move_date'])) ?>
              <?php if (!empty($r['created_at'])): ?><div class="muted small"><?= e(fmt_time($r['created_at'])) ?></div><?php endif; ?></td>
            <td class="mono"><?= e($r['ref_no'] ?: '-') ?></td>
            <td><?= e(doc_label((string)$r['ref_type'])) ?></td>
            <td class="mono"><a href="sku_detail.php?id=<?= (int)$r['product_id'] ?>&from=<?= e($from) ?>&to=<?= e($to) ?>"><?= e($r['sku']) ?></a></td>
            <td class="num"><?= $ch > 0 ? '<span style="color:var(--ok)">+' . fmt_qty($ch) . '</span>' : '-' ?></td>
            <td class="num"><?= $ch < 0 ? '<span style="color:var(--danger)">' . fmt_qty($ch) . '</span>' : '-' ?></td>
            <td class="num"><strong><?= fmt_qty($r['qty_after']) ?></strong> <span class="muted"><?= e($r['unit']) ?></span></td>
            <td><?= e($r['user_name'] ?? '-') ?></td>
            <td class="small"><?= e($r['note'] ?: '-') ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?= render_pager($pg) ?>
  <?php card_end(); ?>
</section>
<?php page_end(); ?>
