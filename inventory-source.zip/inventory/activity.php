<?php
require_once __DIR__ . '/includes/init.php';
require_perm('master.view');

$from = input_date('from', date('Y-m-d', strtotime('-30 days')));
$to = input_date('to', today());
$userF = (int)get('user_id');
$q = (string)get('q');

$where = ['date(created_at) BETWEEN ? AND ?'];
$params = [$from, $to];
if ($userF > 0) { $where[] = 'user_id = ?'; $params[] = $userF; }
if ($q !== '') { $where[] = '(action LIKE ? OR detail LIKE ? OR ref_no LIKE ?)'; array_push($params, "%$q%", "%$q%", "%$q%"); }
$wsql = 'WHERE ' . implode(' AND ', $where);

$total = (int)db_scalar("SELECT COUNT(*) FROM activity_log $wsql", $params);
$pg = pager($total, 40);
$rows = db_all("SELECT * FROM activity_log $wsql ORDER BY id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params);
$users = db_all('SELECT id, name, username FROM users ORDER BY name');

page_start('Log Aktivitas', 'activity');
?>
<section class="card">
  <?php card_start('Jejak Aktivitas Pengguna', 'Semua aksi input, posting, void, dan perubahan master tercatat di sini.',
      '<a class="btn btn-sm" href="export.php?type=activity&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Export Excel</a>'); ?>
    <form class="filters" method="get" style="margin-bottom:18px">
      <div class="f-item"><label>Dari</label><input type="date" name="from" value="<?= e($from) ?>"></div>
      <div class="f-item"><label>Sampai</label><input type="date" name="to" value="<?= e($to) ?>"></div>
      <div class="f-item"><label>Pengguna</label>
        <select name="user_id"><option value="0">Semua pengguna</option>
          <?php foreach ($users as $u): ?><option value="<?= (int)$u['id'] ?>" <?= $userF === (int)$u['id'] ? 'selected' : '' ?>><?= e($u['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="f-item"><label>Cari</label><input type="text" name="q" value="<?= e($q) ?>" placeholder="aksi / keterangan / no dokumen"></div>
      <button class="btn btn-primary" type="submit">Terapkan</button>
      <a class="btn" href="activity.php">Reset</a>
    </form>

    <div class="table-wrap">
      <table>
        <thead><tr><th>Waktu (tgl &middot; jam)</th><th>Pengguna</th><th>Aksi</th><th>Keterangan</th><th>Referensi</th></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="5"><?= empty_state('Tidak ada aktivitas pada periode ini.') ?></td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td class="nowrap"><?= e(fmt_dt($r['created_at'])) ?></td>
            <td><?= e($r['username']) ?></td>
            <td><span class="badge badge-info"><?= e($r['action']) ?></span></td>
            <td><?= e($r['detail']) ?></td>
            <td class="mono"><?= e($r['ref_no'] ?: '-') ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?= render_pager($pg) ?>
  <?php card_end(); ?>
</section>
<?php page_end(); ?>
