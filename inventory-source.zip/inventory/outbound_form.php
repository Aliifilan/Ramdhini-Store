<?php
require_once __DIR__ . '/includes/init.php';
require_perm('tx.view');

$id = (int)get('id');
const OUT_CHANNELS = ['Shopee', 'Tokopedia', 'TikTok Shop', 'Lazada', 'WhatsApp', 'Offline / Toko', 'Marketplace Lain', 'Lainnya'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $op = (string)post('op');
    $did = (int)post('id');

    if ($op === 'void') {
        if (!is_admin()) {
            flash('Hanya Admin yang boleh melakukan void dokumen.', 'error');
        } else {
            $reason = (string)post('void_reason');
            $res = void_document('outbound', $did, $reason !== '' ? $reason : 'tanpa alasan');
            if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil di-void; stok dikembalikan.');
            if (!empty($res['warning'])) flash($res['warning'], 'warn');
            else flash('Gagal void: ' . e(implode(' ', $res['errors'])), 'error');
        }
        redirect('outbound_form.php?id=' . $did);
    }

    if ($op === 'post_id') {
        $res = post_document('outbound', $did);
        if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil diposting; stok berkurang.');
        else flash('Gagal posting: ' . e(implode(' ', $res['errors'])), 'error');
        redirect('outbound_form.php?id=' . $did);
    }

    if ($op === 'save' || $op === 'save_post') {
        /* Dokumen posted boleh dikoreksi semua user; membuat dokumen baru tetap butuh tx.create. */
        $existing = $did > 0 ? db_one('SELECT id, status FROM outbounds WHERE id = ?', [$did]) : null;
        if ($existing && (string)$existing['status'] === 'void') {
            flash('Dokumen yang sudah di-void tidak bisa diubah.', 'error');
            redirect('outbound_form.php?id=' . $did);
        }
        $editingPosted = $existing && (string)$existing['status'] === 'posted';
        if ($editingPosted ? !can('tx.edit_posted') : !can('tx.create')) {
            flash($editingPosted
                ? 'Role Anda tidak boleh mengoreksi dokumen yang sudah diposting.'
                : 'Role Anda tidak boleh membuat transaksi.', 'error');
            redirect($did ? 'outbound_form.php?id=' . $did : 'outbound.php');
        }
        $docDate = (string)post('doc_date');
        $destination = (string)post('destination');
        $channel = (string)post('channel');
        $note = (string)post('note');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $docDate)) $docDate = today();

        $skus = (array)post('item_sku', []);
        $qtys = (array)post('item_qty', []);
        $prices = (array)post('item_price', []);
        $resolved = resolve_skus($skus);
        $pids = $resolved['ids'];
        $rowsOk = 0;
        foreach ($skus as $i => $sku) {
            if (!empty($pids[$i]) && parse_qty($qtys[$i] ?? 0) > 0) $rowsOk++;
        }
        if ($resolved['unknown']) {
            flash(unknown_sku_message($resolved['unknown']), 'warn');
        }
        if ($rowsOk === 0) {
            flash('Scan atau ketik minimal satu SKU yang terdaftar dengan jumlah lebih dari 0.', 'error');
            redirect('outbound_form.php' . ($did ? '?id=' . $did : ''));
        }

        $me = current_user();
        $wasPosted = (bool)$editingPosted;
        if ($wasPosted && $op === 'save' && !can('tx.create')) {
            flash('Role Anda hanya boleh menyimpan koreksi dengan tombol <strong>Simpan &amp; Posting Ulang</strong>.', 'error');
            redirect('outbound_form.php?id=' . $did);
        }
        try {
            $did = db_tx(function () use ($did, $docDate, $destination, $channel, $note, $pids, $qtys, $prices, $me, $op, $wasPosted) {
                if ($did > 0) {
                    $doc = db_one('SELECT * FROM outbounds WHERE id = ?', [$did]);
                    if (!$doc) throw new RuntimeException('Dokumen tidak ditemukan.');
                    if ((string)$doc['status'] === 'void') throw new RuntimeException('Dokumen yang sudah di-void tidak bisa diubah.');
                    if ((string)$doc['status'] === 'posted') {
                        if (!can('tx.edit_posted')) throw new RuntimeException('Role Anda tidak boleh mengoreksi dokumen yang sudah diposting.');
                        /* stok lama dikembalikan, kartu stok lama dihapus, HPP disusun ulang */
                        reopen_posted_document('outbound', $did, 'isi dokumen dikoreksi', doc_items('outbound', $did));
                    }
                    db_run('UPDATE outbounds SET doc_date=?, destination=?, channel=?, note=? WHERE id=?', [$docDate, $destination, $channel, $note, $did]);
                } else {
                    $docNo = next_doc_no('outbound', 'OUT', $docDate);
                    db_run('INSERT INTO outbounds (doc_no, doc_date, destination, channel, note, status, created_by, created_at) VALUES (?,?,?,?,?,?,?,?)',
                        [$docNo, $docDate, $destination, $channel, $note, 'draft', (int)$me['id'], now()]);
                    $did = (int)db()->lastInsertId();
                }
                save_outbound_items($did, $pids, $qtys, $prices);
                recalc_doc_totals('outbound', $did);
                /* posting di dalam transaksi: kalau stok tidak cukup, seluruh koreksi dibatalkan
                   sehingga dokumen kembali persis seperti sebelum diedit. */
                if ($op === 'save_post') {
                    $res = post_document('outbound', $did);
                    if (!$res['ok']) throw new RuntimeException(implode(' ', $res['errors']));
                }
                return $did;
            });
        } catch (Throwable $ex) {
            flash('Gagal menyimpan: ' . e($ex->getMessage()), 'error');
            redirect('outbound_form.php' . ($did ? '?id=' . $did : ''));
        }

        $docNo = (string)db_scalar('SELECT doc_no FROM outbounds WHERE id = ?', [$did]);
        log_activity('save', ($wasPosted ? 'Koreksi' : 'Simpan') . ' barang keluar ' . $docNo, 'outbound', $docNo);
        $warn = stock_negative_warning(array_values(array_filter(array_map('intval', $pids))));
        if ($warn !== '') flash($warn, 'warn');

        if ($op === 'save_post') {
            flash('Dokumen <strong>' . e($docNo) . '</strong> berhasil diposting; stok sudah berkurang.'
                . ($wasPosted ? ' Isi lama sudah dibalik dan diganti isi yang baru (HPP dihitung ulang).' : ''));
            redirect('outbound_form.php?id=' . $did);
        }
        if ($wasPosted) {
            flash('Perubahan pada dokumen <strong>' . e($docNo) . '</strong> disimpan sebagai <strong>draft</strong>. '
                . 'Stok dari dokumen ini sudah dikembalikan sementara &mdash; klik <strong>Simpan &amp; Posting Ulang</strong> '
                . 'kalau perbaikannya sudah selesai.', 'warn');
            redirect('outbound_form.php?id=' . $did);
        }
        flash('Dokumen <strong>' . e($docNo) . '</strong> disimpan sebagai draft.');
        redirect('outbound.php');
    }
}

$doc = null;
$items = [];
if ($id > 0) {
    $doc = db_one('SELECT o.*, u.name AS created_name FROM outbounds o LEFT JOIN users u ON u.id = o.created_by WHERE o.id = ?', [$id]);
    if (!$doc) {
        flash('Dokumen tidak ditemukan.', 'error');
        redirect('outbound.php');
    }
    $items = doc_items('outbound', $id);
}
$isPosted = $doc && (string)$doc['status'] === 'posted';
$canEdit = (bool)$doc
    ? ((string)$doc['status'] === 'draft' ? can('tx.create') : ($isPosted && can('tx.edit_posted')))
    : can('tx.create');
$products = db_all("SELECT p.id, p.sku, p.unit, p.stock_qty, p.sell_price FROM products p WHERE p.active = 1 ORDER BY p.sku");
$brands = db_all('SELECT id, name FROM brands WHERE active = 1 ORDER BY name');
$backUrl = $doc ? ('outbound.php?q=' . urlencode((string)$doc['doc_no'])) : 'outbound.php';

page_start($doc ? ('Barang Keluar ' . $doc['doc_no']) : 'Barang Keluar Baru', 'outbound');
?>
<div class="grid" style="gap:16px">
  <div class="stepline">
    <a class="btn btn-sm" href="<?= e($backUrl) ?>"><?= icon('arrow-left') ?> Kembali ke daftar</a>
    <?php if ($doc): ?>
      <?= status_badge((string)$doc['status']) ?>
      <span class="muted">Dibuat oleh <?= e($doc['created_name'] ?? '-') ?> &middot; <?= e(fmt_dt($doc['created_at'])) ?></span>
      <?php if (!empty($doc['posted_at'])): ?>
        <span class="badge badge-info">Diposting <?= e(fmt_dt($doc['posted_at'])) ?></span>
      <?php endif; ?>
      <?php if (!empty($doc['voided_at'])): ?>
        <span class="badge badge-danger">Di-void <?= e(fmt_dt($doc['voided_at'])) ?></span>
      <?php endif; ?>
      <?php if ($doc['status'] === 'void'): ?><span class="badge badge-danger">Void: <?= e($doc['void_reason']) ?></span><?php endif; ?>
      <button class="btn btn-sm no-print" data-print><?= icon('print') ?> Cetak</button>
    <?php endif; ?>
  </div>
</div>

<?php if ($isPosted && $canEdit): ?>
<div class="alert alert-info">
  <?= icon('edit') ?> <strong>Dokumen ini sudah diposting &mdash; tetap bisa dikoreksi.</strong>
  Saat Anda menyimpan, stok isi lama dikembalikan lalu stok isi baru diterapkan, dan HPP FIFO dihitung ulang.
  <div class="small muted" style="margin-top:6px">
    <strong>Simpan &amp; Posting Ulang</strong> = simpan perubahan sekaligus menerapkan stoknya (status tetap Posted).
    <strong>Simpan sebagai Draft</strong> = stok dikembalikan dulu, dokumen bisa dilanjutkan/diposting nanti.
    Perubahan tercatat di <a href="activity.php">Log Aktivitas</a>.
  </div>
</div>
<?php endif; ?>

<section class="card">
  <?php card_start($doc ? ('Dokumen ' . $doc['doc_no']) : 'Input Barang Keluar', 'Barang keluar mengurangi stok setelah diposting. Sistem akan menolak bila stok tidak cukup.'); ?>
  <form method="post" id="docForm">
    <?= csrf_field() ?>
    <input type="hidden" name="op" value="save"><input type="hidden" name="id" value="<?= (int)($doc['id'] ?? 0) ?>">
    <div class="form-grid">
      <div><label>No. Dokumen</label><input type="text" value="<?= e($doc['doc_no'] ?? 'otomatis saat disimpan') ?>" readonly></div>
      <div><label>Tanggal Keluar</label><input type="date" name="doc_date" value="<?= e($doc['doc_date'] ?? today()) ?>" <?= $canEdit ? '' : 'readonly' ?>></div>
      <div><label>Tujuan / Nama Pembeli</label><input type="text" name="destination" value="<?= e($doc['destination'] ?? '') ?>" <?= $canEdit ? '' : 'readonly' ?> placeholder="nama pembeli / no. pesanan"></div>
      <div><label>Channel Penjualan</label>
        <select name="channel" <?= $canEdit ? '' : 'disabled' ?>>
          <?php foreach (OUT_CHANNELS as $c): ?>
            <option value="<?= e($c) ?>" <?= ($doc['channel'] ?? '') === $c ? 'selected' : '' ?>><?= e($c) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field-full"><label>Catatan</label><input type="text" name="note" value="<?= e($doc['note'] ?? '') ?>" <?= $canEdit ? '' : 'readonly' ?>></div>
    </div>

    <div class="divider"></div>

    <?php if ($canEdit) sku_scan_tools([
        'mode' => 'items',
        'canCreate' => can('master.edit'),
        'brands' => $brands,
        'priceKey' => 'sell_price',
        'priceLabel' => 'Harga Jual',
        'csrf' => csrf_token(),
        'hint' => 'Scan barcode/QR atau ketik SKU lalu Enter — barang langsung masuk daftar dengan qty 1. Stok dicek otomatis saat posting.',
    ]); ?>

    <div class="table-wrap">
      <table id="itemTable" data-items data-money="1" data-total-qty="totQty" data-total-amount="totAmount">
        <thead><tr><th style="min-width:200px">SKU</th><th class="num qty-col">Qty</th><th class="num" style="width:150px">Harga Jual</th><th class="num" style="width:140px">Subtotal</th><th class="num" style="width:150px">HPP FIFO</th><th class="num" style="width:140px">Laba Kotor</th><?php if ($canEdit): ?><th style="width:80px"></th><?php endif; ?></tr></thead>
        <tbody id="itemBody">
        <?php foreach ($items as $it): ?>
          <tr data-sku="<?= e($it['sku']) ?>">
            <td>
              <input class="sku-input" type="text" data-sku-input name="item_sku[]" value="<?= e($it['sku']) ?>" placeholder="scan / ketik SKU" autocomplete="off" spellcheck="false" autocapitalize="characters" <?= $canEdit ? '' : 'readonly' ?>>
              <div class="sku-hint small muted"></div>
            </td>
            <td class="qty-cell"><?= $canEdit ? qty_stepper($it['qty'], true) : qty_stepper($it['qty'], false) ?></td>
            <td><input class="qty-input" style="max-width:140px" type="text" name="item_price[]" value="<?= e((float)$it['unit_price'] > 0 ? fmt_num($it['unit_price']) : '') ?>" placeholder="isi harga" <?= $canEdit ? '' : 'readonly' ?>></td>
            <td class="num row-subtotal"><?= fmt_money($it['subtotal']) ?></td>
            <td class="num">
              <?php if ((float)$doc['total_qty'] > 0 || (float)($it['cogs'] ?? 0) > 0): ?>
                <strong><?= fmt_money($it['cogs'] ?? 0) ?></strong>
                <div class="small muted"><?= (float)$it['qty'] > 0 ? fmt_money(($it['cogs_unit'] ?? 0)) . ' / unit' : '' ?></div>
              <?php else: ?><span class="muted">-</span><?php endif; ?>
            </td>
            <td class="num"><?= (float)($it['cogs'] ?? 0) > 0
              ? '<span style="color:var(--ok)">' . fmt_money((float)$it['subtotal'] - (float)$it['cogs']) . '</span>'
              : '<span class="muted">-</span>' ?></td>
            <?php if ($canEdit): ?><td><button class="btn btn-sm" type="button" onclick="this.closest('tr').remove();rowRecalc()">Hapus</button></td><?php endif; ?>
          </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr class="totals-row"><td class="right">TOTAL</td><td class="num" id="totQty">0</td><td></td><td class="num" id="totAmount">Rp 0</td><td class="num"><?= fmt_money(array_sum(array_map(static fn($x) => (float)($x['cogs'] ?? 0), $items))) ?></td><td class="num"><?= fmt_money(array_sum(array_map(static fn($x) => (float)$x['subtotal'] - (float)($x['cogs'] ?? 0), $items))) ?></td><?php if ($canEdit): ?><td></td><?php endif; ?></tr>
        </tfoot>
      </table>
    </div>

    <?php if ($canEdit): ?>
    <template id="itemTpl">
      <td>
        <input class="sku-input" type="text" data-sku-input name="item_sku[]" placeholder="scan / ketik SKU" autocomplete="off" spellcheck="false" autocapitalize="characters">
        <div class="sku-hint small muted"></div>
      </td>
      <td class="qty-cell"><?= qty_stepper(1) ?></td>
      <td><input class="qty-input" style="max-width:140px" type="text" name="item_price[]" placeholder="isi harga" oninput="rowRecalc()"></td>
      <td class="num row-subtotal">Rp 0</td>
      <td class="num muted">dihitung saat posting</td>
      <td class="num muted">dihitung saat posting</td>
      <td><button class="btn btn-sm" type="button" onclick="this.closest('tr').remove();rowRecalc()">Hapus</button></td>
    </template>
    <?php endif; ?>

    <div class="form-actions">
      <?php if ($canEdit): ?>
        <button class="btn" type="button" onclick="itemRows.add({bodyId:'itemBody',tplId:'itemTpl'})"><?= icon('plus') ?> Baris kosong</button>
        <div style="flex:1"></div>
        <?php if ($isPosted): ?>
          <?php if (can('tx.create')): ?>
            <button class="btn" type="submit">Simpan sebagai Draft (stok dikembalikan)</button>
          <?php endif; ?>
          <button class="btn btn-primary" type="button"
                  onclick="submitPost('Simpan koreksi & posting ulang? Stok isi lama dikembalikan, lalu isi baru diterapkan & HPP dihitung ulang.')">Simpan &amp; Posting Ulang</button>
        <?php else: ?>
          <button class="btn" type="submit">Simpan sebagai Draft</button>
          <button class="btn btn-primary" type="button" onclick="submitPost('Posting dokumen ini? Stok akan berkurang.')">Simpan &amp; Posting</button>
        <?php endif; ?>
      <?php elseif ($doc && $doc['status'] === 'draft' && can('tx.edit')): ?>
        <button class="btn btn-primary" type="submit" name="op" value="post_id">Posting Sekarang</button>
      <?php endif; ?>
    </div>
  </form>
  <?php card_end(); ?>
</section>

<?php if ($doc && $doc['status'] === 'posted'): ?>
<section class="card">
  <?php card_start('Pergerakan Stok dari Dokumen Ini'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal</th><th>Produk</th><th class="num">Perubahan</th><th class="num">Saldo Stok</th><th>Catatan</th></tr></thead>
        <tbody>
        <?php foreach (doc_ledger_rows('outbound', (int)$doc['id']) as $l): ?>
          <tr>
            <td><?= e(fmt_date($l['move_date'])) ?></td>
            <td class="mono"><?= e($l['sku']) ?></td>
            <td class="num" style="color:<?= (float)$l['qty_change'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ((float)$l['qty_change'] >= 0 ? '+' : '') . fmt_qty($l['qty_change']) ?></td>
            <td class="num"><?= fmt_qty($l['qty_after']) ?></td>
            <td class="small"><?= e($l['note'] ?: doc_label((string)$l['ref_type'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<?php if ($doc && $doc['status'] === 'posted' && is_admin()): ?>
<section class="card">
  <?php card_start('Void Dokumen', 'Void membalik pergerakan stok dokumen ini (stok dikembalikan).'); ?>
    <form method="post" data-need-reason data-confirm="<?= e(void_confirm_text('outbound', (int)$doc['id'], (string)$doc['doc_no'])) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="op" value="void"><input type="hidden" name="id" value="<?= (int)$doc['id'] ?>">
      <input type="text" name="void_reason" placeholder="alasan void (wajib)" required>
      <div class="form-actions"><button class="btn btn-danger" type="submit"><?= icon('ban') ?> Void Dokumen</button></div>
    </form>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<script src="<?= e(asset_url('assets/sku.js')) ?>"></script>
<script>
<?= product_js_maps($products, 'sell_price') ?>
function rowRecalc() {
  itemRows.recalc({ tableId: 'itemTable', stockMap: window.PRODUCT_STOCK, totalQtyId: 'totQty', totalAmountId: 'totAmount' });
}
function submitPost(msg) {
  if (!confirm(msg)) return;
  var f = document.getElementById('docForm');
  f.querySelector('input[name=op]').value = 'save_post';
  f.submit();
}
document.addEventListener('DOMContentLoaded', rowRecalc);
</script>
<?php page_end(); ?>
