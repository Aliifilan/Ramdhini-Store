<?php
require_once __DIR__ . '/includes/init.php';
require_perm('tx.view');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $op = (string)post('op');
    $did = (int)post('id');
    if ($op === 'void') {
        if (!is_admin()) {
            flash('Hanya Admin yang boleh melakukan void dokumen.', 'error');
        } else {
            $reason = (string)post('void_reason');
            $res = void_document('return', $did, $reason !== '' ? $reason : 'tanpa alasan');
            if ($res['ok']) flash('Dokumen retur <strong>' . e($res['doc_no']) . '</strong> berhasil di-void; stok dikembalikan.');
            else flash('Gagal void: ' . e(implode(' ', $res['errors'])), 'error');
        }
    }
    if ($op === 'post_id') {
        if (!can('tx.edit')) {
            flash('Role Anda tidak boleh memposting transaksi.', 'error');
        } else {
            $res = post_document('return', $did);
            if ($res['ok']) flash('Dokumen retur <strong>' . e($res['doc_no']) . '</strong> berhasil diposting.');
            if (!empty($res['warning'])) flash($res['warning'], 'warn');
            else flash('Gagal posting: ' . e(implode(' ', $res['errors'])), 'error');
        }
    }
    redirect('returns.php');
}

$from = input_date('from', date('Y-m-d', strtotime('-60 days')));
$to = input_date('to', today());
$typeF = (string)get('type');
$statusF = (string)get('status');
$q = (string)get('q');

$where = ['date(r.doc_date) BETWEEN ? AND ?'];
$params = [$from, $to];
if ($typeF !== '') { $where[] = 'r.type = ?'; $params[] = $typeF; }
if ($statusF !== '') { $where[] = 'r.status = ?'; $params[] = $statusF; }
if ($q !== '') { $where[] = '(r.doc_no LIKE ? OR r.party LIKE ? OR r.ref_doc_no LIKE ? OR r.note LIKE ?)'; array_push($params, "%$q%", "%$q%", "%$q%", "%$q%"); }
$wsql = 'WHERE ' . implode(' AND ', $where);

$total = (int)db_scalar("SELECT COUNT(*) FROM returns r $wsql", $params);
$pg = pager($total, 25);
$rows = db_all(
    "SELECT r.*, u.name AS created_name FROM returns r LEFT JOIN users u ON u.id = r.created_by
     $wsql ORDER BY r.doc_date DESC, r.id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}",
    $params
);

/* Dampak void dihitung sekaligus (satu query per jenis dokumen) supaya tombol Void
   bisa memperingatkan lebih dulu bila stok akan menjadi minus. */
$voidRefs = [];
foreach ($rows as $r) {
    if ((string)$r['status'] === 'posted') $voidRefs[] = ['return', (int)$r['id']];
}
$voidImpact = void_impacts($voidRefs);
$voidConfirm = [];
foreach ($rows as $r) {
    $key = 'return:' . (int)$r['id'];
    $voidConfirm[(int)$r['id']] = void_confirm_text('return', (int)$r['id'], (string)$r['doc_no'], $voidImpact[$key] ?? []);
}
$sumSup = (float)(db_scalar("SELECT COALESCE(SUM(r.total_qty),0) FROM returns r $wsql AND r.type='supplier' AND r.status='posted'", $params) ?? 0);
$sumCus = (float)(db_scalar("SELECT COALESCE(SUM(r.total_qty),0) FROM returns r $wsql AND r.type='customer' AND r.status='posted'", $params) ?? 0);

page_start('Retur', 'returns');
?>
<div class="grid grid-4">
  <div class="card stat"><span class="label">Dokumen Periode</span><span class="value"><?= fmt_num($total) ?></span><span class="hint"><?= e(fmt_date($from)) ?> &ndash; <?= e(fmt_date($to)) ?></span></div>
  <div class="card stat"><span class="label">Retur ke Supplier</span><span class="value" style="color:var(--danger)"><?= fmt_qty($sumSup) ?></span><span class="hint">unit keluar dari stok</span></div>
  <div class="card stat"><span class="label">Retur dari Customer</span><span class="value" style="color:var(--ok)">+<?= fmt_qty($sumCus) ?></span><span class="hint">unit kembali ke stok</span></div>
  <div class="card stat"><span class="label">Draft Belum Posting</span><span class="value"><?= fmt_num((int)db_scalar("SELECT COUNT(*) FROM returns WHERE status='draft'")) ?></span></div>
</div>

<section class="card">
  <?php card_start('Daftar Retur', 'Retur ke supplier mengurangi stok; retur dari customer menambah stok.',
      '<a class="btn btn-sm" href="export.php?type=returns&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Export Excel</a>'
      . '<a class="btn btn-sm" href="export.php?type=return_items&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Detail Item</a>'
      . '<a class="btn btn-sm" href="import.php?ds=returns">' . icon('import') . ' Import</a>'
      . (can('tx.create') ? '<a class="btn btn-sm btn-primary" href="return_form.php">' . icon('plus') . ' Retur Baru</a>' : '')); ?>
    <form class="filters" method="get" style="margin-bottom:18px">
      <div class="f-item"><label>Dari</label><input type="date" name="from" value="<?= e($from) ?>"></div>
      <div class="f-item"><label>Sampai</label><input type="date" name="to" value="<?= e($to) ?>"></div>
      <div class="f-item"><label>Jenis Retur</label>
        <select name="type">
          <option value="">Semua jenis</option>
          <option value="supplier" <?= $typeF === 'supplier' ? 'selected' : '' ?>>Ke Supplier (stok keluar)</option>
          <option value="customer" <?= $typeF === 'customer' ? 'selected' : '' ?>>Dari Customer (stok masuk)</option>
        </select>
      </div>
      <div class="f-item"><label>Status</label>
        <select name="status">
          <?php foreach (['' => 'Semua status', 'draft' => 'Draft', 'posted' => 'Posted', 'void' => 'Void'] as $k => $v): ?>
            <option value="<?= e($k) ?>" <?= $statusF === $k ? 'selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="f-item"><label>Cari</label><input type="text" name="q" value="<?= e($q) ?>" placeholder="no dokumen / pihak / referensi"></div>
      <button class="btn btn-primary" type="submit">Terapkan</button>
      <a class="btn" href="returns.php">Reset</a>
    </form>
    <div class="table-wrap">
      <table>
        <thead><tr><th>No. Dokumen</th><th>Tanggal</th><th>Jenis</th><th>Pihak</th><th>Ref. Dokumen</th><th class="num">Qty</th><th class="num">Nilai</th><th>Status</th><th>Dibuat (tgl &middot; jam)</th><th></th></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="10"><?= empty_state('Belum ada dokumen retur pada periode ini.') ?></td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td class="mono"><a href="return_form.php?id=<?= (int)$r['id'] ?>"><?= e($r['doc_no']) ?></a></td>
            <td class="nowrap"><?= e(fmt_date($r['doc_date'])) ?></td>
            <td><?= $r['type'] === 'supplier' ? '<span class="badge badge-danger">Ke Supplier</span>' : '<span class="badge badge-ok">Dari Customer</span>' ?></td>
            <td><?= e($r['party'] ?: '-') ?></td>
            <td class="mono"><?= e($r['ref_doc_no'] ?: '-') ?></td>
            <td class="num"><?= fmt_qty($r['total_qty']) ?></td>
            <td class="num"><?= fmt_money($r['total_amount']) ?></td>
            <td><?= status_badge((string)$r['status']) ?></td>
            <td class="small nowrap"><?= e($r['created_name'] ?? '-') ?>
                <div class="muted"><?= e(fmt_dt($r['created_at'])) ?></div></td>
            <td class="nowrap">
              <div class="row-actions">
                <a class="btn btn-sm" href="return_form.php?id=<?= (int)$r['id'] ?>"><?= $r['status'] === 'draft' ? 'Lanjutkan' : 'Lihat' ?></a>
                <?php if ($r['status'] === 'draft' && can('tx.edit')): ?>
                  <form class="inline-form" method="post" data-confirm="Posting dokumen retur ini? Stok akan disesuaikan.">
                    <?= csrf_field() ?><input type="hidden" name="op" value="post_id"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-sm btn-primary" type="submit">Posting</button>
                  </form>
                <?php endif; ?>
                <?php if ($r['status'] === 'posted' && is_admin()): ?>
                  <form class="inline-form" method="post" data-need-reason data-confirm="<?= e($voidConfirm[(int)$r['id']] ?? void_confirm_text('return', (int)$r['id'], (string)$r['doc_no'])) ?>">
                    <?= csrf_field() ?><input type="hidden" name="op" value="void"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <input type="hidden" name="void_reason" value="">
                    <button class="btn btn-sm btn-danger" type="submit">Void</button>
                  </form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?= render_pager($pg) ?>
  <?php card_end(); ?>
</section>
<?php page_end(); ?>
