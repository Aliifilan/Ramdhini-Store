<?php
require_once __DIR__ . '/includes/init.php';
require_perm('inv.view');

$to = input_date('to', today());
$from = input_date('from', date('Y-m-d', strtotime($to . ' -13 days')));
if ($from > $to) { $tmp = $from; $from = $to; $to = $tmp; }

$data = daily_stock_matrix($from, $to);
$dates = $data['dates'];
$brands = $data['brands'];
$matrix = $data['matrix'];
$totals = $data['totals'];
$vmatrix = $data['vmatrix'] ?? [];
$vtotals = $data['vtotals'] ?? [];
$view = get('view') === 'rp' ? 'rp' : 'unit';   // tampilan: jumlah unit atau nominal rupiah

/* Barang KELUAR per hari: jumlah pcs + nilai modalnya (HPP FIFO yang benar-benar dipakai
   saat barang keluar). Hanya dokumen berstatus Posted yang dihitung. */
$outgoing = daily_outgoing($from, $to);
$outDates = $outgoing['dates'];
$outPcsTotal = 0.0;
$outCostTotal = 0.0;
$outSellTotal = 0.0;
foreach ($outDates as $d) {
    $outPcsTotal += (float)$outgoing['qty'][$d];
    $outCostTotal += (float)$outgoing['cost'][$d];
    $outSellTotal += (float)$outgoing['sell'][$d];
}
$outMarginTotal = $outSellTotal - $outCostTotal;
$outChartLabels = array_map(static fn($d) => date('d/m', strtotime($d)), $outDates);
$outChartCost = array_map(static fn($d) => (float)$outgoing['cost'][$d], $outDates);
$outChartSell = array_map(static fn($d) => (float)$outgoing['sell'][$d], $outDates);
$outAvgCost = $outDates ? $outCostTotal / count($outDates) : 0.0;
$outAvgPcs = $outDates ? $outPcsTotal / count($outDates) : 0.0;

$chartLabels = array_map(static fn($d) => date('d/m', strtotime($d)), $dates);
$chartValues = array_map(static fn($d) => (float)$totals[$d], $dates);
$chartValuesRp = array_map(static fn($d) => (float)($vtotals[$d] ?? 0), $dates);

$firstDay = $chartValues[0] ?? 0;
$lastDay = end($chartValues) ?: 0;
$delta = $lastDay - $firstDay;
$firstRp = $chartValuesRp[0] ?? 0;
$lastRp = end($chartValuesRp) ?: 0;
$deltaRp = $lastRp - $firstRp;
$maxDate = $dates ? $dates[count($dates) - 1] : $to;

/* brand dengan kontribusi terbesar pada hari terakhir */
$lastDate = $dates ? $dates[count($dates) - 1] : null;
$byBrandLast = [];
$byBrandLastRp = [];
if ($lastDate) {
    foreach ($brands as $bid => $bname) {
        $byBrandLast[] = ['label' => $bname, 'value' => (float)($matrix[$lastDate][$bid] ?? 0), 'brand_id' => $bid];
    }
    usort($byBrandLast, static fn($a, $b) => $b['value'] <=> $a['value']);
    $byBrandLastRp = array_map(static fn($r) => [
        'label' => $r['label'],
        'value' => (float)($vmatrix[$lastDate][$r['brand_id']] ?? 0),
        'display' => fmt_money((float)($vmatrix[$lastDate][$r['brand_id']] ?? 0)),
    ], $byBrandLast);
    usort($byBrandLastRp, static fn($a, $b) => $b['value'] <=> $a['value']);
}

page_start('Daily Stock — Semua Brand', 'daily_stock');
?>
<?php if (!empty($data['truncated'])): ?>
<div class="alert alert-warn">
  Rentang tanggal yang Anda pilih terlalu panjang: yang dihitung adalah <strong><?= fmt_num(count($dates)) ?> hari pertama</strong>
  (<?= e(fmt_date($dates[0] ?? $from)) ?> &ndash; <?= e(fmt_date($lastDate ?? $to)) ?>), sisa <?= fmt_num((int)$data['skipped_days']) ?> hari tidak ditampilkan.
  Persempit periode (misalnya per bulan) untuk hasil lengkap.
</div>
<?php endif; ?>

<div class="grid grid-4">
  <div class="card stat"><span class="label">Stok Awal Periode</span><span class="value"><?= fmt_qty($firstDay) ?></span><span class="hint"><?= e(fmt_date($dates[0] ?? $from)) ?> &middot; <?= fmt_money($firstRp) ?></span></div>
  <div class="card stat"><span class="label">Stok Akhir Periode</span><span class="value"><?= fmt_qty($lastDay) ?></span><span class="hint"><?= e(fmt_date($lastDate ?? $to)) ?> &middot; <?= fmt_money($lastRp) ?></span></div>
  <div class="card stat"><span class="label">Perubahan Periode</span>
    <span class="value" style="font-size:20px"><span style="color:<?= $delta >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ($delta >= 0 ? '+' : '') . fmt_qty($delta) ?></span> <span class="muted">unit</span></span>
    <span class="hint">nilai: <span style="color:<?= $deltaRp >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ($deltaRp >= 0 ? '+' : '-') . fmt_money(abs($deltaRp)) ?></span></span>
  </div>
  <div class="card stat"><span class="label">Nilai Stok Akhir (HPP)</span><span class="value" style="font-size:20px"><?= fmt_money($lastRp) ?></span><span class="hint">rata-rata harian <?= fmt_money($chartValuesRp ? array_sum($chartValuesRp) / count($chartValuesRp) : 0) ?></span></div>
</div>

<section class="card">
  <?php card_start('Tren Total Stok Harian', 'Posisi stok pada setiap akhir hari, dihitung ulang dari kartu stok.',
      '<button class="btn btn-sm" data-print>' . icon('print') . ' Cetak</button>'
      . '<a class="btn btn-sm" href="export.php?type=daily_stock&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Export Excel</a>'); ?>
    <form class="filters no-print" method="get" style="margin-bottom:18px">
      <div class="f-item"><label>Dari tanggal</label><input type="date" name="from" value="<?= e($from) ?>"></div>
      <div class="f-item"><label>Sampai tanggal</label><input type="date" name="to" value="<?= e($to) ?>"></div>
      <div class="f-item"><label>Tampilkan angka</label>
        <select name="view">
          <option value="unit" <?= $view === 'unit' ? 'selected' : '' ?>>Jumlah unit</option>
          <option value="rp" <?= $view === 'rp' ? 'selected' : '' ?>>Nominal rupiah (HPP)</option>
        </select>
      </div>
      <button class="btn btn-primary" type="submit">Tampilkan</button>
      <a class="btn" href="daily_stock.php">14 Hari Terakhir</a>
      <a class="btn" href="?from=<?= e(date('Y-m-01')) ?>&to=<?= e(today()) ?>">Bulan Ini</a>
    </form>
    <div id="chart-daily"></div>
  <?php card_end(); ?>
</section>

<div class="grid grid-2">
  <section class="card">
    <?php card_start('Tren Nilai Stok Harian (Rupiah)', 'Nilai stok akhir hari dihitung dari HPP produk saat ini.'); ?>
      <div id="chart-daily-rp"></div>
    <?php card_end(); ?>
  </section>
  <section class="card">
    <?php card_start('Nilai Stok per Brand pada ' . e(fmt_date($lastDate ?? $to)), 'Nominal rupiah (HPP) yang tersimpan di stok tiap brand.'); ?>
      <div id="chart-last-day-rp"></div>
    <?php card_end(); ?>
  </section>
</div>

<section class="card">
  <?php card_start('Barang Keluar per Hari — Jumlah Pcs dan Nilai Modal',
      'Berapa pcs yang keluar setiap hari dan berapa nilai modal (HPP) barang yang keluar itu. Hanya dokumen berstatus Posted.',
      '<button class="btn btn-sm" data-print>' . icon('print') . ' Cetak</button>'
      . '<a class="btn btn-sm" href="export.php?type=daily_stock&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Export Excel</a>'); ?>
    <div class="grid grid-4" style="margin-bottom:18px">
      <div class="card stat"><span class="label">Total Pcs Keluar</span><span class="value" style="color:var(--danger)"><?= fmt_qty($outPcsTotal) ?></span><span class="hint">rata-rata <?= fmt_qty($outAvgPcs) ?> pcs/hari</span></div>
      <div class="card stat"><span class="label">Nilai Modal Keluar (HPP)</span><span class="value" style="font-size:20px"><?= fmt_money($outCostTotal) ?></span><span class="hint">rata-rata <?= fmt_money($outAvgCost) ?>/hari</span></div>
      <div class="card stat"><span class="label">Nilai Jual</span><span class="value" style="font-size:20px"><?= fmt_money($outSellTotal) ?></span></div>
      <div class="card stat"><span class="label">Laba Kotor</span><span class="value" style="font-size:20px;color:<?= $outMarginTotal >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= fmt_money($outMarginTotal) ?></span><span class="hint">nilai jual &minus; nilai modal</span></div>
    </div>
    <div id="chart-out"></div>
    <p class="help" style="margin-top:10px">Nilai modal diambil dari HPP FIFO yang benar-benar dipakai saat barang keluar
      (bukan HPP rata-rata hari ini), jadi angkanya sesuai dengan HPP pada baris dokumen barang keluar.</p>
    <div class="table-wrap" style="margin-top:14px">
      <table>
        <thead>
          <tr><th>Tanggal</th><th class="num">Dokumen</th><th class="num">Pcs Keluar</th><th class="num">Nilai Modal (HPP)</th><th class="num">Nilai Jual</th><th class="num">Laba Kotor</th></tr>
        </thead>
        <tbody>
        <?php if (!$outDates): ?>
          <tr><td colspan="6"><?= empty_state('Tidak ada data pada periode ini.') ?></td></tr>
        <?php endif; ?>
        <?php foreach (array_reverse($outDates) as $d): $pcs = (float)$outgoing['qty'][$d]; ?>
          <tr<?= $pcs <= 0 ? ' style="opacity:.55"' : '' ?>>
            <td class="nowrap"><strong><?= e(fmt_date($d)) ?></strong> <span class="muted"><?= e(date('D', strtotime($d))) ?></span></td>
            <td class="num"><?= (int)$outgoing['docs'][$d] > 0 ? fmt_num($outgoing['docs'][$d]) : '<span class="muted">-</span>' ?></td>
            <td class="num"><strong><?= fmt_qty($pcs) ?></strong></td>
            <td class="num"><?= $pcs > 0 ? '<strong>' . fmt_money((float)$outgoing['cost'][$d]) . '</strong>' : '<span class="muted">-</span>' ?></td>
            <td class="num"><?= $pcs > 0 ? fmt_money((float)$outgoing['sell'][$d]) : '<span class="muted">-</span>' ?></td>
            <td class="num"><?php $m = (float)$outgoing['margin'][$d]; ?><?= $pcs > 0
                ? '<span style="color:' . ($m >= 0 ? 'var(--ok)' : 'var(--danger)') . '">' . fmt_money($m) . '</span>'
                : '<span class="muted">-</span>' ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if ($outDates): ?>
        <tr class="totals-row">
          <td>TOTAL PERIODE</td>
          <td class="num"><?= fmt_num(array_sum($outgoing['docs'])) ?></td>
          <td class="num"><?= fmt_qty($outPcsTotal) ?></td>
          <td class="num"><?= fmt_money($outCostTotal) ?></td>
          <td class="num"><?= fmt_money($outSellTotal) ?></td>
          <td class="num"><?= fmt_money($outMarginTotal) ?></td>
        </tr>
        <tr class="totals-row">
          <td>RATA-RATA HARIAN</td>
          <td class="num">-</td>
          <td class="num"><?= fmt_qty($outAvgPcs) ?></td>
          <td class="num"><?= fmt_money($outAvgCost) ?></td>
          <td class="num"><?= fmt_money($outDates ? $outSellTotal / count($outDates) : 0) ?></td>
          <td class="num"><?= fmt_money($outDates ? $outMarginTotal / count($outDates) : 0) ?></td>
        </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
    <p class="help">Yang dihitung hanya <strong>barang keluar</strong> (penjualan/pengiriman). Retur ke supplier dan
      penyesuaian stok turun tidak termasuk di tabel ini &mdash; angkanya bisa dilihat di menu Retur dan Kartu Stok.</p>
  <?php card_end(); ?>
</section>

<?php if (!empty($outgoing['sku_rows'])): ?>
<section class="card">
  <?php card_start('Barang Keluar per SKU (periode ' . fmt_date($from) . ' - ' . fmt_date($to) . ')',
      'Rincian pcs dan nilai modal tiap SKU yang keluar pada periode ini.'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>SKU</th><th>Brand</th><th class="num">Pcs Keluar</th><th class="num">Nilai Modal (HPP)</th><th class="num">Nilai Jual</th><th class="num">Laba Kotor</th><th class="num">HPP / pcs</th></tr></thead>
        <tbody>
        <?php foreach ($outgoing['sku_rows'] as $r): $mg = (float)$r['sell'] - (float)$r['cost']; $per = (float)$r['qty'] > 0 ? (float)$r['cost'] / (float)$r['qty'] : 0; ?>
          <tr>
            <td class="mono"><a href="sku_detail.php?id=<?= (int)(db_scalar('SELECT id FROM products WHERE sku = ?', [$r['sku']]) ?? 0) ?>&from=<?= e($from) ?>&to=<?= e($to) ?>"><?= e($r['sku']) ?></a></td>
            <td><?= e($r['brand']) ?></td>
            <td class="num"><strong><?= fmt_qty($r['qty']) ?></strong></td>
            <td class="num"><?= fmt_money($r['cost']) ?></td>
            <td class="num"><?= fmt_money($r['sell']) ?></td>
            <td class="num"><span style="color:<?= $mg >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= fmt_money($mg) ?></span></td>
            <td class="num"><?= fmt_money($per) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<div class="grid grid-2">
  <section class="card">
    <?php card_start('Stok per Brand pada ' . e(fmt_date($lastDate ?? $to)), 'Posisi terakhir pada periode terpilih.'); ?>
      <div id="chart-last-day"></div>
    <?php card_end(); ?>
  </section>
  <section class="card">
    <?php card_start('Catatan Perhitungan'); ?>
      <p class="doc-note">Posisi stok tiap hari diambil dari seluruh pergerakan yang tercatat di kartu stok (barang masuk, barang keluar, penyesuaian, opname, dan retur) sampai dengan akhir hari tersebut. Transaksi yang baru diinput belakangan akan mengubah angka pada tanggal transaksinya, bukan tanggal input.</p>
      <ul class="small muted" style="margin-top:12px">
        <li>Periode: <?= e(fmt_date($dates[0] ?? $from)) ?> &ndash; <?= e(fmt_date($lastDate ?? $to)) ?> (<?= fmt_num(count($dates)) ?> hari)</li>
        <li>Jumlah brand terpantau: <?= fmt_num(count($brands)) ?></li>
        <li>Produk aktif: <?= fmt_num((int)db_scalar('SELECT COUNT(*) FROM products WHERE active = 1')) ?></li>
      </ul>
    <?php card_end(); ?>
  </section>
</div>

<section class="card">
  <?php card_start('Tabel Daily Stock per Brand', 'Setiap baris adalah satu tanggal; kolom adalah brand.'); ?>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Tanggal</th>
            <?php foreach ($brands as $bid => $bname): ?><th class="num"><?= e($bname) ?></th><?php endforeach; ?>
            <th class="num">Total Unit</th>
            <th class="num">Total Nilai (Rp)</th>
          </tr>
        </thead>
        <tbody>
        <?php if (!$dates): ?>
          <tr><td colspan="<?= count($brands) + 3 ?>"><?= empty_state('Tidak ada data pada periode ini.') ?></td></tr>
        <?php endif; ?>
        <?php foreach (array_reverse($dates) as $d): ?>
          <tr>
            <td class="nowrap"><strong><?= e(fmt_date($d)) ?></strong> <span class="muted"><?= e(date('D', strtotime($d))) ?></span></td>
            <?php foreach ($brands as $bid => $bname): ?>
              <td class="num"><?= $view === 'rp'
                  ? fmt_money((float)($vmatrix[$d][$bid] ?? 0))
                  : fmt_qty((float)($matrix[$d][$bid] ?? 0)) ?></td>
            <?php endforeach; ?>
            <td class="num"><strong><?= fmt_qty((float)$totals[$d]) ?></strong></td>
            <td class="num"><strong><?= fmt_money((float)($vtotals[$d] ?? 0)) ?></strong></td>
          </tr>
        <?php endforeach; ?>
        <?php if ($dates): ?>
        <tr class="totals-row">
          <td>RATA-RATA HARIAN</td>
          <?php foreach ($brands as $bid => $bname):
            $avgU = 0.0; $avgV = 0.0;
            foreach ($dates as $d) { $avgU += (float)($matrix[$d][$bid] ?? 0); $avgV += (float)($vmatrix[$d][$bid] ?? 0); }
            $n = max(1, count($dates));
            ?>
            <td class="num"><?= $view === 'rp' ? fmt_money($avgV / $n) : fmt_qty($avgU / $n) ?></td>
          <?php endforeach; ?>
          <td class="num"><?= fmt_qty(array_sum($chartValues) / max(1, count($chartValues))) ?></td>
          <td class="num"><?= fmt_money(array_sum($chartValuesRp) / max(1, count($chartValuesRp))) ?></td>
        </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Stok Harian per SKU (unit dan nilai)', 'Rincian sampai level SKU. Kolom unit = jumlah stok, kolom Rp = nilai HPP pada tanggal itu.'); ?>
    <div class="table-wrap">
      <table>
        <thead>
          <tr><th>SKU</th><th>Brand</th>
          <?php foreach ($dates as $d): ?><th class="num"><?= e(date('d/m', strtotime($d))) ?></th><?php endforeach; ?>
          <th class="num">Total Rp akhir</th></tr>
        </thead>
        <tbody>
        <?php $skuRows = $data['sku_rows'] ?? []; ?>
        <?php if (!$skuRows): ?><tr><td colspan="<?= count($dates) + 3 ?>"><?= empty_state('Belum ada data SKU pada periode ini.') ?></td></tr><?php endif; ?>
        <?php foreach ($skuRows as $r): ?>
          <tr>
            <td class="mono"><a href="sku_detail.php?id=<?= (int)(db_scalar('SELECT id FROM products WHERE sku = ?', [$r['sku']]) ?? 0) ?>&from=<?= e($from) ?>&to=<?= e($to) ?>"><?= e($r['sku']) ?></a></td>
            <td><?= e($r['brand']) ?></td>
            <?php foreach ($dates as $d): ?>
              <td class="num"><?= $view === 'rp'
                  ? fmt_money((float)($r['totals'][$d] ?? 0))
                  : fmt_qty((float)($r['matrix'][$d] ?? 0)) ?></td>
            <?php endforeach; ?>
            <td class="num"><?= fmt_money((float)($r['totals'][end($dates)] ?? 0)) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<script src="<?= e(asset_url('assets/charts.js')) ?>"></script>
<script>
renderLineChart('chart-daily-rp', {
  labels: <?= json_encode($chartLabels) ?>,
  series: [{ name: 'Nilai stok (Rp)', color: '#10B981', values: <?= json_encode($chartValuesRp) ?> }]
});
renderLineChart('chart-out', {
  labels: <?= json_encode($outChartLabels) ?>,
  format: 'money',
  series: [
    { name: 'Nilai modal keluar (HPP)', color: '#F472B6', values: <?= json_encode($outChartCost) ?> },
    { name: 'Nilai jual', color: '#10B981', values: <?= json_encode($outChartSell) ?> }
  ]
});
renderLineChart('chart-daily', {
  labels: <?= json_encode($chartLabels) ?>,
  series: [{ name: 'Total stok (unit)', color: '#4F46E5', values: <?= json_encode($chartValues) ?> }]
});
renderBarChart('chart-last-day', { rows: <?= json_encode(array_map(static fn($r) => [
  'label' => $r['label'],
  'value' => $r['value'],
  'display' => fmt_qty($r['value']),
], array_slice($byBrandLast, 0, 12))) ?> });
renderBarChart('chart-last-day-rp', { rows: <?= json_encode(array_slice($byBrandLastRp, 0, 12)) ?> });
</script>
<?php page_end(); ?>
