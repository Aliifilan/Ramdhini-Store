<?php
require_once __DIR__ . '/includes/init.php';
require_perm('tx.view');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $op = (string)post('op');
    $did = (int)post('id');
    if ($op === 'void') {
        if (!is_admin()) {
            flash('Hanya Admin yang boleh melakukan void dokumen.', 'error');
        } else {
            $reason = (string)post('void_reason');
            $res = void_document('outbound', $did, $reason !== '' ? $reason : 'tanpa alasan');
            if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil di-void; stok dikembalikan.');
            if (!empty($res['warning'])) flash($res['warning'], 'warn');
            else flash('Gagal void: ' . e(implode(' ', $res['errors'])), 'error');
        }
    }
    if ($op === 'post_id') {
        if (!can('tx.edit')) {
            flash('Role Anda tidak boleh memposting transaksi.', 'error');
        } else {
            $res = post_document('outbound', $did);
            if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil diposting; stok berkurang.');
            else flash('Gagal posting: ' . e(implode(' ', $res['errors'])), 'error');
        }
    }
    redirect('outbound.php');
}

$from = input_date('from', date('Y-m-d', strtotime('-30 days')));
$to = input_date('to', today());
$statusF = (string)get('status');
$q = (string)get('q');

$where = ['date(o.doc_date) BETWEEN ? AND ?'];
$params = [$from, $to];
if ($statusF !== '') { $where[] = 'o.status = ?'; $params[] = $statusF; }
if ($q !== '') {
    /* Pencarian bebas: nomor dokumen, tujuan, catatan, channel, ATAU SKU barang di dalam dokumen.
       Mencari SKU menampilkan semua dokumen yang memuat SKU itu (dokumen mana, untuk siapa, tanggal berapa). */
    $where[] = '(o.doc_no LIKE ? OR o.destination LIKE ? OR o.note LIKE ? OR o.channel LIKE ? OR EXISTS (
                    SELECT 1 FROM outbound_items oi JOIN products p ON p.id = oi.product_id
                     WHERE oi.outbound_id = o.id AND p.sku LIKE ?))';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%");
}
$wsql = 'WHERE ' . implode(' AND ', $where);

$total = (int)db_scalar("SELECT COUNT(*) FROM outbounds o $wsql", $params);
$pg = pager($total, 25);
$rows = db_all(
    "SELECT o.*, u.name AS created_name FROM outbounds o LEFT JOIN users u ON u.id = o.created_by
     $wsql ORDER BY o.doc_date DESC, o.id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}",
    $params
);

/* Dampak void dihitung sekaligus (satu query per jenis dokumen) supaya tombol Void
   bisa memperingatkan lebih dulu bila stok akan menjadi minus. */
$voidRefs = [];
foreach ($rows as $r) {
    if ((string)$r['status'] === 'posted') $voidRefs[] = ['outbound', (int)$r['id']];
}
$voidImpact = void_impacts($voidRefs);
$voidConfirm = [];
foreach ($rows as $r) {
    $key = 'outbound:' . (int)$r['id'];
    $voidConfirm[(int)$r['id']] = void_confirm_text('outbound', (int)$r['id'], (string)$r['doc_no'], $voidImpact[$key] ?? []);
}
$sumQty = (float)(db_scalar("SELECT COALESCE(SUM(o.total_qty),0) FROM outbounds o $wsql AND o.status='posted'", $params) ?? 0);
$sumAmt = (float)(db_scalar("SELECT COALESCE(SUM(o.total_amount),0) FROM outbounds o $wsql AND o.status='posted'", $params) ?? 0);
$sumCogs = (float)(db_scalar("SELECT COALESCE(SUM(i.cogs),0) FROM outbound_items i JOIN outbounds o ON o.id=i.outbound_id $wsql AND o.status='posted'", $params) ?? 0);
$skuMap = doc_sku_map('outbound', array_column($rows, 'id'));

page_start('Barang Keluar (Outbound)', 'outbound');
?>
<div class="grid grid-4">
  <div class="card stat"><span class="label">Dokumen Periode</span><span class="value"><?= fmt_num($total) ?></span><span class="hint"><?= e(fmt_date($from)) ?> &ndash; <?= e(fmt_date($to)) ?></span></div>
  <div class="card stat"><span class="label">Unit Keluar (Posted)</span><span class="value" style="color:var(--danger)"><?= fmt_qty($sumQty) ?></span></div>
  <div class="card stat"><span class="label">Nilai Jual (Posted)</span><span class="value" style="font-size:20px"><?= fmt_money($sumAmt) ?></span>
    <span class="hint">HPP FIFO <?= fmt_money($sumCogs) ?> &middot; laba kotor <?= fmt_money($sumAmt - $sumCogs) ?></span></div>
  <div class="card stat"><span class="label">Draft Belum Posting</span><span class="value"><?= fmt_num((int)db_scalar("SELECT COUNT(*) FROM outbounds WHERE status='draft'")) ?></span></div>
</div>

<section class="card">
  <?php card_start('Daftar Barang Keluar', 'Posting hanya bisa dilakukan bila stok mencukupi.',
      '<a class="btn btn-sm" href="export.php?type=outbound&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Export Excel</a>'
      . '<a class="btn btn-sm" href="export.php?type=outbound_items&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Detail Item</a>'
      . '<a class="btn btn-sm" href="import.php?ds=outbound">' . icon('import') . ' Import</a>'
      . (can('tx.create') ? '<a class="btn btn-sm btn-primary" href="outbound_form.php">' . icon('plus') . ' Barang Keluar Baru</a>' : '')); ?>
    <form class="filters" method="get" style="margin-bottom:18px">
      <div class="f-item"><label>Dari</label><input type="date" name="from" value="<?= e($from) ?>"></div>
      <div class="f-item"><label>Sampai</label><input type="date" name="to" value="<?= e($to) ?>"></div>
      <div class="f-item"><label>Status</label>
        <select name="status">
          <?php foreach (['' => 'Semua status', 'draft' => 'Draft', 'posted' => 'Posted', 'void' => 'Void'] as $k => $v): ?>
            <option value="<?= e($k) ?>" <?= $statusF === $k ? 'selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="f-item"><label>No. dokumen / Tujuan / SKU</label><input type="text" name="q" value="<?= e($q) ?>" placeholder="no dokumen, tujuan, channel, atau SKU"></div>
      <button class="btn btn-primary" type="submit">Terapkan</button>
      <a class="btn" href="outbound.php">Reset</a>
    </form>
    <div class="table-wrap">
      <table>
        <thead><tr><th>No. Dokumen</th><th>Tanggal</th><th>Tujuan / Pembeli</th><th>Channel</th><th>SKU</th><th class="num">Total Qty</th><th class="num">Nilai Jual</th><th class="num">HPP FIFO</th><th class="num">Laba Kotor</th><th>Status</th><th>Dibuat (tgl &middot; jam)</th><th></th></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="12"><?= empty_state($q !== ''
            ? 'Tidak ada dokumen barang keluar yang cocok dengan pencarian "' . e($q) . '" pada periode ini.'
            : 'Belum ada dokumen barang keluar pada periode ini.') ?></td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td class="mono"><a href="outbound_form.php?id=<?= (int)$r['id'] ?>"><?= e($r['doc_no']) ?></a></td>
            <td class="nowrap"><?= e(fmt_date($r['doc_date'])) ?></td>
            <td><?= e($r['destination'] ?: '-') ?></td>
            <td><?= e($r['channel'] ?: '-') ?></td>
            <?php $sum = doc_sku_summary($skuMap[(int)$r['id']] ?? []); ?>
            <td class="small mono sku-cell"><?= $sum['count'] === 0 ? '<span class="muted">-</span>'
                : '<span title="' . e($sum['full']) . '">' . e($sum['short']) . '</span>' ?></td>
            <td class="num"><strong><?= fmt_qty($r['total_qty']) ?></strong></td>
            <td class="num"><?= fmt_money($r['total_amount']) ?></td>
            <td class="num"><?php $cg = (float)(db_scalar('SELECT COALESCE(SUM(cogs),0) FROM outbound_items WHERE outbound_id = ?', [(int)$r['id']]) ?? 0); ?>
              <?= $cg > 0 ? fmt_money($cg) : '<span class="muted">-</span>' ?></td>
            <td class="num"><?= $cg > 0 ? '<span style="color:var(--ok)"><strong>' . fmt_money((float)$r['total_amount'] - $cg) . '</strong></span>' : '<span class="muted">-</span>' ?></td>
            <td><?= status_badge((string)$r['status']) ?></td>
            <td class="small nowrap"><?= e($r['created_name'] ?? '-') ?>
                <div class="muted"><?= e(fmt_dt($r['created_at'])) ?></div></td>
            <td class="nowrap">
              <div class="row-actions">
                <a class="btn btn-sm<?= $r['status'] === 'posted' && can('tx.edit_posted') ? ' btn-primary' : '' ?>" href="outbound_form.php?id=<?= (int)$r['id'] ?>"><?= $r['status'] === 'draft' ? 'Lanjutkan' : ($r['status'] === 'posted' && can('tx.edit_posted') ? 'Edit' : 'Lihat') ?></a>
                <?php if ($r['status'] === 'draft' && can('tx.edit')): ?>
                  <form class="inline-form" method="post" data-confirm="Posting dokumen ini? Stok akan berkurang.">
                    <?= csrf_field() ?><input type="hidden" name="op" value="post_id"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-sm btn-primary" type="submit">Posting</button>
                  </form>
                <?php endif; ?>
                <?php if ($r['status'] === 'posted' && is_admin()): ?>
                  <form class="inline-form" method="post" data-need-reason data-confirm="<?= e($voidConfirm[(int)$r['id']] ?? void_confirm_text('outbound', (int)$r['id'], (string)$r['doc_no'])) ?>">
                    <?= csrf_field() ?><input type="hidden" name="op" value="void"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <input type="hidden" name="void_reason" value="">
                    <button class="btn btn-sm btn-danger" type="submit">Void</button>
                  </form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?= render_pager($pg) ?>
  <?php card_end(); ?>
</section>
<?php page_end(); ?>
