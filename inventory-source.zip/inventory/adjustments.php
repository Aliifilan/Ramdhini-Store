<?php
require_once __DIR__ . '/includes/init.php';
require_perm('inv.view');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $op = (string)post('op');
    $did = (int)post('id');
    if ($op === 'void') {
        if (!is_admin()) {
            flash('Hanya Admin yang boleh melakukan void dokumen.', 'error');
        } else {
            $reason = (string)post('void_reason');
            $res = void_document('adjustment', $did, $reason !== '' ? $reason : 'tanpa alasan');
            if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil di-void dan stok dikembalikan.');
            if (!empty($res['warning'])) flash($res['warning'], 'warn');
            else flash('Gagal void: ' . e(implode(' ', $res['errors'])), 'error');
        }
    }
    if ($op === 'post_id') {
        if (!can('inv.adjust')) {
            flash('Role Anda tidak boleh memposting penyesuaian stok.', 'error');
        } else {
            $res = post_document('adjustment', $did);
            if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil diposting dan stok sudah diperbarui.');
            else flash('Gagal posting: ' . e(implode(' ', $res['errors'])), 'error');
        }
    }
    redirect('adjustments.php?' . qs(['page' => null, 'id' => null]));
}

$from = input_date('from', date('Y-m-d', strtotime('-60 days')));
$to = input_date('to', today());
$statusF = (string)get('status');
$q = (string)get('q');

$where = ['date(a.doc_date) BETWEEN ? AND ?'];
$params = [$from, $to];
if ($statusF !== '') { $where[] = 'a.status = ?'; $params[] = $statusF; }
if ($q !== '') { $where[] = '(a.doc_no LIKE ? OR a.reason LIKE ? OR a.note LIKE ?)'; array_push($params, "%$q%", "%$q%", "%$q%"); }
$wsql = 'WHERE ' . implode(' AND ', $where);

$total = (int)db_scalar("SELECT COUNT(*) FROM adjustments a $wsql", $params);
$pg = pager($total, 25);
$rows = db_all(
    "SELECT a.*, u.name AS created_name, v.name AS voided_name
       FROM adjustments a
       LEFT JOIN users u ON u.id = a.created_by
       LEFT JOIN users v ON v.id = a.voided_by
       $wsql ORDER BY a.doc_date DESC, a.id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}",
    $params
);

/* Dampak void dihitung sekaligus (satu query per jenis dokumen) supaya tombol Void
   bisa memperingatkan lebih dulu bila stok akan menjadi minus. */
$voidRefs = [];
foreach ($rows as $r) {
    if ((string)$r['status'] === 'posted') $voidRefs[] = ['adjustment', (int)$r['id']];
}
$voidImpact = void_impacts($voidRefs);
$voidConfirm = [];
foreach ($rows as $r) {
    $key = 'adjustment:' . (int)$r['id'];
    $voidConfirm[(int)$r['id']] = void_confirm_text('adjustment', (int)$r['id'], (string)$r['doc_no'], $voidImpact[$key] ?? []);
}

page_start('Stok Adjustment', 'adjustments');
?>
<div class="grid grid-4">
  <div class="card stat"><span class="label">Dokumen Periode Ini</span><span class="value"><?= fmt_num($total) ?></span><span class="hint"><?= e(fmt_date($from)) ?> &ndash; <?= e(fmt_date($to)) ?></span></div>
  <div class="card stat"><span class="label">Draft</span><span class="value"><?= fmt_num((int)db_scalar("SELECT COUNT(*) FROM adjustments WHERE status='draft'")) ?></span><span class="hint">belum mempengaruhi stok</span></div>
  <div class="card stat"><span class="label">Posted</span><span class="value"><?= fmt_num((int)db_scalar("SELECT COUNT(*) FROM adjustments WHERE status='posted'")) ?></span></div>
  <div class="card stat"><span class="label">Void</span><span class="value"><?= fmt_num((int)db_scalar("SELECT COUNT(*) FROM adjustments WHERE status='void'")) ?></span></div>
</div>

<section class="card">
  <?php card_start('Daftar Penyesuaian Stok', 'Dipakai untuk mengoreksi stok: stok awal, barang rusak, hilang, atau salah input.',
      '<a class="btn btn-sm" href="export.php?type=adjustments&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Export Excel</a>'
      . '<a class="btn btn-sm" href="export.php?type=adjustment_items&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Detail Item</a>'
      . (can('inv.adjust') ? '<a class="btn btn-sm btn-primary" href="adjustment_form.php">' . icon('plus') . ' Adjustment Baru</a>' : '')); ?>
    <form class="filters" method="get" style="margin-bottom:18px">
      <div class="f-item"><label>Dari</label><input type="date" name="from" value="<?= e($from) ?>"></div>
      <div class="f-item"><label>Sampai</label><input type="date" name="to" value="<?= e($to) ?>"></div>
      <div class="f-item"><label>Status</label>
        <select name="status">
          <?php foreach (['' => 'Semua status', 'draft' => 'Draft', 'posted' => 'Posted', 'void' => 'Void'] as $k => $v): ?>
            <option value="<?= e($k) ?>" <?= $statusF === $k ? 'selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="f-item"><label>Cari</label><input type="text" name="q" value="<?= e($q) ?>" placeholder="no dokumen / alasan"></div>
      <button class="btn btn-primary" type="submit">Terapkan</button>
      <a class="btn" href="adjustments.php">Reset</a>
    </form>

    <div class="table-wrap">
      <table>
        <thead><tr><th>No. Dokumen</th><th>Tanggal</th><th>Alasan</th><th class="num">Item</th><th class="num">Total Selisih</th><th>Status</th><th>Dibuat Oleh &amp; Waktu</th><th>Catatan</th><th></th></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="9"><?= empty_state('Belum ada dokumen penyesuaian stok.') ?></td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td class="mono"><a href="adjustment_form.php?id=<?= (int)$r['id'] ?>"><?= e($r['doc_no']) ?></a></td>
            <td class="nowrap"><?= e(fmt_date($r['doc_date'])) ?></td>
            <td><?= e($r['reason'] ?: '-') ?></td>
            <td class="num"><?= fmt_num($r['total_items']) ?></td>
            <td class="num" style="color:<?= (float)$r['total_delta'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ((float)$r['total_delta'] >= 0 ? '+' : '') . fmt_qty($r['total_delta']) ?></td>
            <td><?= status_badge((string)$r['status']) ?></td>
            <td class="nowrap"><?= e($r['created_name'] ?? '-') ?><div class="muted small"><?= e(fmt_dt($r['created_at'])) ?></div></td>
            <td class="small"><?= e($r['note'] ?: ($r['status'] === 'void' ? ('Void: ' . $r['void_reason']) : '-')) ?></td>
            <td class="nowrap">
              <div class="row-actions">
                <a class="btn btn-sm" href="adjustment_form.php?id=<?= (int)$r['id'] ?>"><?= $r['status'] === 'draft' ? 'Lanjutkan' : 'Lihat' ?></a>
                <?php if ($r['status'] === 'draft' && can('inv.adjust')): ?>
                  <form class="inline-form" method="post" data-confirm="Posting penyesuaian ini? Stok akan langsung berubah.">
                    <?= csrf_field() ?><input type="hidden" name="op" value="post_id"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-sm btn-primary" type="submit">Posting</button>
                  </form>
                <?php endif; ?>
                <?php if ($r['status'] === 'posted' && is_admin()): ?>
                  <form class="inline-form" method="post" data-need-reason data-confirm="<?= e($voidConfirm[(int)$r['id']] ?? void_confirm_text('adjustment', (int)$r['id'], (string)$r['doc_no'])) ?>">
                    <?= csrf_field() ?><input type="hidden" name="op" value="void"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <input type="hidden" name="void_reason" value="">
                    <button class="btn btn-sm btn-danger" type="submit">Void</button>
                  </form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?= render_pager($pg) ?>
  <?php card_end(); ?>
</section>
<?php page_end(); ?>
