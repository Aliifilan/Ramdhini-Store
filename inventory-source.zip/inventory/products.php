<?php
require_once __DIR__ . '/includes/init.php';
require_perm('master.view');

$id = (int)get('id');
$edit = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (!can('master.edit')) {
        flash('Role Anda hanya bisa melihat data master.', 'error');
        redirect('products.php');
    }
    $op = (string)post('op');
    $pid = (int)post('id');

    if ($op === 'save') {
        $sku = strtoupper((string)post('sku'));
        $brandId = (int)post('brand_id') ?: null;
        $data = [
            'brand_id' => $brandId,
            'category' => (string)post('category'),
            'size' => normalize_size(post('size')),
            'unit' => (string)post('unit', 'pcs'),
            'cost_price' => parse_num(post('cost_price')),
            'sell_price' => parse_num(post('sell_price')),
            'min_stock' => parse_qty(post('min_stock')),
            'active' => (int)post('active') === 1 ? 1 : 0,
        ];
        if ($sku === '') {
            flash('SKU wajib diisi — SKU dipakai sebagai identitas produk.', 'error');
            redirect('products.php?id=' . $pid);
        }
        $dupe = db_one('SELECT id FROM products WHERE sku = ? AND id <> ?', [$sku, $pid]);
        if ($dupe) {
            flash('SKU <strong>' . e($sku) . '</strong> sudah dipakai produk lain.', 'error');
            redirect('products.php?id=' . $pid);
        }
        if ($pid > 0) {
            if (products_has_name_column()) {
                db_run('UPDATE products SET name = sku WHERE id = ?', [$pid]);
            }
            db_run(
                'UPDATE products SET sku=?, brand_id=?, category=?, size=?, unit=?, cost_price=?, sell_price=?, min_stock=?, active=?, updated_at=? WHERE id=?',
                [$sku, $data['brand_id'], $data['category'], $data['size'], $data['unit'],
                 $data['cost_price'], $data['sell_price'], $data['min_stock'], $data['active'], now(), $pid]
            );
            /* Produk yang belum punya pergerakan stok: HPP awal mengikuti harga yang diketik.
               Kalau sudah ada pergerakan, HPP awal dihitung FIFO dari penerimaan pertama. */
            $punyaGerakan = (int)db_scalar('SELECT COUNT(*) FROM ledger WHERE product_id = ?', [$pid]) > 0;
            $initSekarang = (float)(db_scalar('SELECT cost_price_initial FROM products WHERE id = ?', [$pid]) ?? 0);
            if (!$punyaGerakan && $data['cost_price'] > 0 && (float)$data['cost_price'] !== $initSekarang) {
                db_run('UPDATE products SET cost_price_initial = ? WHERE id = ?', [$data['cost_price'], $pid]);
            } elseif ($initSekarang <= 0 && (float)$data['cost_price'] > 0) {
                db_run('UPDATE products SET cost_price_initial = ? WHERE id = ?', [$data['cost_price'], $pid]);
            }
            log_activity('update', 'Ubah produk ' . $sku, 'product', $sku);
            flash('Produk <strong>' . e($sku) . '</strong> berhasil diperbarui.');
        } else {
            product_create($sku, $data['brand_id'], null, $data['category'], $data['unit'],
                $data['cost_price'], $data['sell_price'], $data['min_stock'], $data['active'], $data['size']);
            log_activity('create', 'Tambah produk ' . $sku, 'product', $sku);
            flash('Produk <strong>' . e($sku) . '</strong> berhasil ditambahkan. Stok awal dapat diisi lewat Import (Stok Awal) atau menu Stok Adjustment.');
        }
        redirect('products.php');
    }

    if ($op === 'toggle') {
        db_run('UPDATE products SET active = CASE active WHEN 1 THEN 0 ELSE 1 END, updated_at = ? WHERE id = ?', [now(), $pid]);
        log_activity('toggle', 'Ubah status aktif produk #' . $pid, 'product', (string)$pid);
        flash('Status produk berhasil diubah.');
        redirect('products.php?' . qs());
    }
}

if ($id > 0) {
    $edit = db_one('SELECT * FROM products WHERE id = ?', [$id]);
}

$q = (string)get('q');
$brandF = (int)get('brand_id');
$statusF = (string)get('status');
$sizeF = normalize_size(get('size'));

$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(p.sku LIKE ? OR p.category LIKE ? OR p.size LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like);
}
if ($brandF > 0) { $where[] = 'p.brand_id = ?'; $params[] = $brandF; }
if ($sizeF !== '') { $where[] = 'p.size = ?'; $params[] = $sizeF; }
if ($statusF === 'aktif') $where[] = 'p.active = 1';
if ($statusF === 'nonaktif') $where[] = 'p.active = 0';
if ($statusF === 'menipis') $where[] = 'p.stock_qty <= p.min_stock';
$wsql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$total = (int)db_scalar("SELECT COUNT(*) FROM products p $wsql", $params);
$pg = pager($total, 25);
$rows = db_all(
    "SELECT p.*, b.name AS brand_name,
            (p.stock_qty * p.cost_price) AS stock_value,
            MAX(0, CAST(julianday('now') - julianday(p.created_at) AS INTEGER)) AS umur_hari
       FROM products p
       LEFT JOIN brands b ON b.id = p.brand_id
       $wsql ORDER BY p.sku LIMIT {$pg['per']} OFFSET {$pg['offset']}",
    $params
);
$brands = db_all('SELECT id, name FROM brands WHERE active = 1 ORDER BY name');

$sumQty = (float)(db_scalar("SELECT COALESCE(SUM(p.stock_qty),0) FROM products p $wsql", $params) ?? 0);
$sumVal = (float)(db_scalar("SELECT COALESCE(SUM(p.stock_qty * p.cost_price),0) FROM products p $wsql", $params) ?? 0);

page_start('Produk Master', 'products');
?>
<div class="grid grid-4">
  <div class="card stat"><span class="label">Total Produk</span><span class="value"><?= fmt_num($total) ?></span><span class="hint">sesuai filter aktif</span></div>
  <div class="card stat"><span class="label">Total Stok</span><span class="value"><?= fmt_qty($sumQty) ?></span><span class="hint">unit</span></div>
  <div class="card stat"><span class="label">Nilai Stok (HPP)</span><span class="value" style="font-size:20px"><?= fmt_money($sumVal) ?></span><span class="hint">modal tersimpan</span></div>
  <div class="card stat"><span class="label">Stok Menipis</span><span class="value"><?= fmt_num((int)db_scalar('SELECT COUNT(*) FROM products WHERE active=1 AND stock_qty <= min_stock')) ?></span><span class="hint">perlu restock</span></div>
</div>

<?php
$oldest = db_one("SELECT sku, created_at, MAX(0, CAST(julianday('now') - julianday(created_at) AS INTEGER)) AS umur
                    FROM products WHERE active = 1 ORDER BY umur DESC LIMIT 1");
?>
<?php if ($oldest && (int)$oldest['umur'] >= 1): ?>
<div class="alert alert-info">
  SKU tertua: <strong><?= e($oldest['sku']) ?></strong> — sudah <strong><?= fmt_num($oldest['umur']) ?> hari</strong> terdaftar
  (sejak <?= e(fmt_date($oldest['created_at'])) ?>). Lihat kolom <strong>Umur</strong> di tabel untuk tiap produk,
  atau klik <strong>Riwayat</strong> guna melihat arus masuk/keluar SKU tersebut.
</div>
<?php endif; ?>

<div class="grid grid-2">
  <section class="card span-2">
    <?php card_start('Daftar Produk', 'Produk diidentifikasi lewat SKU. Klik SKU untuk mengubah data.',
        '<a class="btn btn-sm" href="export.php?type=products">' . icon('export') . ' Export Excel</a>'
        . '<a class="btn btn-sm" href="import.php">' . icon('import') . ' Import</a>'
        . (can('master.edit') ? '<a class="btn btn-sm btn-primary" href="products.php?reset=1#form-produk">' . icon('plus') . ' Produk Baru</a>' : '')); ?>
      <form class="filters" method="get" style="margin-bottom:18px">
        <div class="f-item"><label>Cari</label><input type="text" name="q" value="<?= e($q) ?>" placeholder="SKU / kategori / ukuran"></div>
        <div class="f-item"><label>Brand</label>
          <select name="brand_id"><option value="0">Semua brand</option>
            <?php foreach ($brands as $b): ?><option value="<?= (int)$b['id'] ?>" <?= $brandF === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="f-item"><label>Ukuran</label>
          <select name="size">
            <option value="">Semua ukuran</option>
            <?php foreach (product_sizes() as $sz): ?>
              <option value="<?= e($sz) ?>" <?= $sizeF === $sz ? 'selected' : '' ?>><?= e($sz) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="f-item"><label>Status</label>
          <select name="status">
            <?php foreach (['' => 'Semua', 'aktif' => 'Aktif', 'nonaktif' => 'Nonaktif', 'menipis' => 'Stok menipis'] as $k => $v): ?>
              <option value="<?= e($k) ?>" <?= $statusF === $k ? 'selected' : '' ?>><?= e($v) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <button class="btn btn-primary" type="submit">Terapkan</button>
        <a class="btn" href="products.php">Reset</a>
      </form>

      <div class="table-wrap">
        <table>
          <thead><tr>
            <th>SKU</th><th>Brand</th><th>Kategori</th><th>Ukuran</th>
            <th class="num">HPP Awal</th><th class="num">HPP Rata-rata</th><th class="num">Harga Jual</th><th class="num">Min</th><th class="num">Stok</th>
            <th class="num">Nilai Stok</th><th class="num">Umur</th><th>Status</th><th></th><?php if (can('master.edit')): ?><th></th><?php endif; ?>
          </tr></thead>
          <tbody>
          <?php if (!$rows): ?>
            <tr><td colspan="<?= can('master.edit') ? 14 : 13 ?>"><?= empty_state('Belum ada produk yang cocok dengan filter ini.') ?></td></tr>
          <?php endif; ?>
          <?php foreach ($rows as $r): $low = (float)$r['stock_qty'] <= (float)$r['min_stock']; ?>
            <tr>
              <td class="mono"><a href="products.php?id=<?= (int)$r['id'] ?>"><strong><?= e($r['sku']) ?></strong></a></td>
              <td><?= e($r['brand_name'] ?? '-') ?></td>
              <td><?= e($r['category'] ?: '-') ?></td>
              <td><?= (string)($r['size'] ?? '') !== '' ? '<span class="badge badge-info">' . e($r['size']) . '</span>' : '<span class="muted">-</span>' ?></td>
              <td class="num"><?= fmt_money($r['cost_price_initial'] ?: $r['cost_price']) ?></td>
              <td class="num"><strong><?= fmt_money($r['cost_price']) ?></strong></td>
              <td class="num"><?= fmt_money($r['sell_price']) ?></td>
              <td class="num"><?= fmt_qty($r['min_stock']) ?></td>
              <td class="num"><?= fmt_qty($r['stock_qty']) ?> <span class="muted"><?= e($r['unit']) ?></span></td>
              <td class="num"><?= fmt_money($r['stock_value']) ?></td>
              <td class="num"><?= fmt_num($r['umur_hari']) ?> <span class="muted">hari</span></td>
              <td><?= (int)$r['active'] === 1 ? ($low ? '<span class="badge badge-warn">Menipis</span>' : '<span class="badge badge-ok">Aktif</span>') : '<span class="badge badge-muted">Nonaktif</span>' ?></td>
              <td class="nowrap"><a class="btn btn-sm" href="sku_detail.php?id=<?= (int)$r['id'] ?>">Riwayat</a></td>
              <?php if (can('master.edit')): ?>
              <td class="nowrap">
                <form class="inline-form" method="post" data-confirm="Ubah status aktif produk ini?">
                  <?= csrf_field() ?>
                  <input type="hidden" name="op" value="toggle"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <button class="btn btn-sm" type="submit"><?= (int)$r['active'] === 1 ? 'Nonaktifkan' : 'Aktifkan' ?></button>
                </form>
              </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?= render_pager($pg) ?>
    <?php card_end(); ?>
  </section>
</div>

<?php if (can('master.edit')): ?>
<div class="grid">
  <section class="card" id="form-produk">
    <?php card_start($edit ? ('Ubah Produk: ' . $edit['sku']) : 'Tambah Produk Baru', 'SKU adalah identitas produk (dipakai di semua transaksi). Scan QR/barcode agar SKU tidak salah ketik. Stok awal diisi lewat menu <strong>Stok Adjustment</strong> atau import <strong>Stok Awal</strong> supaya tercatat di kartu stok.'); ?>
      <?php
      /* alat scan di form produk: mengisi kolom SKU + memperingatkan SKU yang sudah terdaftar */
      sku_scan_tools([
          'mode' => 'field',
          'target' => '#sku-input',
          'context' => $edit ? 'edit' : 'new',
          'currentId' => (int)($edit['id'] ?? 0),
          'csrf' => csrf_token(),
          'hint' => 'Tempel/scan label QR produk: kalau SKU-nya sudah terdaftar, sistem memberi peringatan dan tautan ke produk yang ada supaya tidak dobel. Tekan Enter di kolom SKU untuk memeriksa SKU yang diketik manual.',
      ]);
      ?>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="op" value="save">
        <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
        <div class="form-grid">
          <div><label>SKU / Kode *</label><input class="sku-input" id="sku-input" type="text" name="sku" value="<?= e($edit['sku'] ?? '') ?>" required placeholder="scan QR / ketik SKU"></div>
          <div><label>Brand</label>
            <select name="brand_id"><option value="0">- belum dipilih -</option>
              <?php foreach (db_all('SELECT id, name, active FROM brands ORDER BY name') as $b): ?>
                <option value="<?= (int)$b['id'] ?>" <?= (int)($edit['brand_id'] ?? 0) === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?><?= (int)$b['active'] === 0 ? ' (nonaktif)' : '' ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div><label>Kategori</label><input type="text" name="category" value="<?= e($edit['category'] ?? '') ?>" placeholder="cth: Jeans"></div>
          <div><label>Ukuran (Size)</label>
            <select name="size">
              <option value="">- tanpa ukuran -</option>
              <?php foreach (product_sizes() as $sz): ?>
                <option value="<?= e($sz) ?>" <?= (string)($edit['size'] ?? '') === $sz ? 'selected' : '' ?>><?= e($sz) ?></option>
              <?php endforeach; ?>
            </select>
            <p class="help">Pilih ukuran barang. Satu SKU untuk satu ukuran.</p>
          </div>
          <div><label>Satuan</label><input type="text" name="unit" value="<?= e($edit['unit'] ?? 'pcs') ?>"></div>
          <div><label>Harga Beli Awal / HPP</label><input type="text" name="cost_price" value="<?= e($edit ? fmt_num($edit['cost_price']) : '') ?>" placeholder="isi harga">
            <p class="help">Dipakai sebagai HPP Awal untuk produk baru. Setelah ada barang masuk, HPP dihitung otomatis (FIFO).</p></div>
          <div><label>Harga Jual</label><input type="text" name="sell_price" value="<?= e($edit ? fmt_num($edit['sell_price']) : '') ?>" placeholder="isi harga"></div>
          <div><label>Stok Minimum</label><input type="text" name="min_stock" value="<?= e($edit ? fmt_qty($edit['min_stock']) : '0') ?>"></div>
          <div><label>Status</label>
            <select name="active">
              <option value="1" <?= (int)($edit['active'] ?? 1) === 1 ? 'selected' : '' ?>>Aktif</option>
              <option value="0" <?= isset($edit['active']) && (int)$edit['active'] === 0 ? 'selected' : '' ?>>Nonaktif</option>
            </select>
          </div>
          <?php if ($edit): ?>
          <div><label>Stok Saat Ini</label><input type="text" value="<?= e(fmt_qty($edit['stock_qty'])) ?>" readonly></div>
          <div><label>HPP Awal (dari penerimaan pertama)</label>
            <input type="text" value="<?= e(fmt_money($edit['cost_price_initial'] ?: $edit['cost_price'])) ?>" readonly>
            <p class="help">HPP rata-rata <?= e(fmt_money($edit['cost_price'])) ?> &mdash; dihitung otomatis dari lapisan stok FIFO, bukan diisi manual.</p>
          </div>
          <?php endif; ?>
        </div>
        <div class="form-actions">
          <button class="btn btn-primary" type="submit"><?= $edit ? 'Simpan Perubahan' : 'Simpan Produk' ?></button>
          <?php if ($edit): ?><a class="btn" href="products.php">Batal</a><?php endif; ?>
        </div>
      </form>
    <?php card_end(); ?>
  </section>
</div>
<script src="<?= e(asset_url('assets/sku.js')) ?>"></script>
<?php endif; ?>
<?php page_end(); ?>
