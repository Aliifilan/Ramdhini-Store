<?php
require_once __DIR__ . '/includes/init.php';
require_perm('tx.view');

$id = (int)get('id');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $op = (string)post('op');
    $did = (int)post('id');

    if ($op === 'void') {
        if (!is_admin()) {
            flash('Hanya Admin yang boleh melakukan void dokumen.', 'error');
        } else {
            $reason = (string)post('void_reason');
            $res = void_document('inbound', $did, $reason !== '' ? $reason : 'tanpa alasan');
            if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil di-void; stok dikurangi kembali.');
            if (!empty($res['warning'])) flash($res['warning'], 'warn');
            else flash('Gagal void: ' . e(implode(' ', $res['errors'])), 'error');
        }
        redirect('inbound_form.php?id=' . $did);
    }

    if ($op === 'post_id') {
        $res = post_document('inbound', $did);
        if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil diposting; stok bertambah.');
        else flash('Gagal posting: ' . e(implode(' ', $res['errors'])), 'error');
        redirect('inbound_form.php?id=' . $did);
    }

    if ($op === 'save' || $op === 'save_post') {
        /* Dokumen yang SUDAH DIPOSTING boleh dikoreksi oleh semua user (permintaan pemilik toko).
           Membuat dokumen baru tetap butuh hak membuat transaksi. */
        $existing = $did > 0 ? db_one('SELECT id, status FROM inbounds WHERE id = ?', [$did]) : null;
        if ($existing && (string)$existing['status'] === 'void') {
            flash('Dokumen yang sudah di-void tidak bisa diubah.', 'error');
            redirect('inbound_form.php?id=' . $did);
        }
        $editingPosted = $existing && (string)$existing['status'] === 'posted';
        if ($editingPosted ? !can('tx.edit_posted') : !can('tx.create')) {
            flash($editingPosted
                ? 'Role Anda tidak boleh mengoreksi dokumen yang sudah diposting.'
                : 'Role Anda tidak boleh membuat transaksi.', 'error');
            redirect($did ? 'inbound_form.php?id=' . $did : 'inbound.php');
        }
        $docDate = (string)post('doc_date');
        $supplierId = (int)post('supplier_id') ?: null;
        $note = (string)post('note');

        /* Baca SELURUH input lebih dulu. Kalau ada yang belum lengkap, datanya dikembalikan
           ke halaman (tidak di-redirect) supaya barang yang sudah dipindai tidak hilang. */
        $skus = (array)post('item_sku', []);
        $qtys = (array)post('item_qty', []);
        $costs = (array)post('item_price', []);
        $discType = post('discount_type') === 'percent' ? 'percent' : 'amount';
        $discValue = parse_num(post('discount_value'));
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $docDate)) $docDate = today();
        if ($discValue < 0) $discValue = 0;
        if ($discType === 'percent' && $discValue > 100) $discValue = 100;

        $resolved = resolve_skus($skus);
        $pids = $resolved['ids'];
        $rowsOk = 0;
        foreach ($skus as $i => $sku) {
            if (!empty($pids[$i]) && parse_qty($qtys[$i] ?? 0) > 0) $rowsOk++;
        }

        /* ---- validasi yang tidak boleh menghilangkan data ---- */
        $blocker = '';
        $blockerField = '';
        if (!$supplierId) {
            $blocker = 'Supplier belum dipilih. Isi kolom <strong>Supplier</strong> di bawah, lalu klik simpan lagi &mdash; '
                . 'barang yang sudah Anda pindai tetap ada di halaman ini, tidak perlu diulang.';
            $blockerField = 'supplier_id';
        } else {
            $sup = db_one('SELECT id, active FROM suppliers WHERE id = ?', [$supplierId]);
            if (!$sup) {
                $blocker = 'Supplier yang dipilih tidak ditemukan. Pilih supplier lain di kolom <strong>Supplier</strong> &mdash; data barang Anda tetap tersimpan di halaman ini.';
                $blockerField = 'supplier_id';
            } elseif ((int)$sup['active'] !== 1) {
                $blocker = 'Supplier yang dipilih berstatus <strong>nonaktif</strong>. Pilih supplier aktif &mdash; data barang Anda tetap tersimpan di halaman ini.';
                $blockerField = 'supplier_id';
            }
        }
        if ($blocker === '' && $rowsOk === 0) {
            $blocker = 'Belum ada barang yang diisi. Scan atau ketik minimal satu SKU dengan jumlah lebih dari 0.';
            $blockerField = 'item_sku';
        }

        if ($blocker !== '') {
            if ($resolved['unknown']) {
                flash(unknown_sku_message($resolved['unknown']), 'warn');
            }
            $formError = $blocker;
            $formErrorField = $blockerField;
            $keep = [
                'doc_date' => $docDate,
                'supplier_id' => (int)($supplierId ?? 0),
                'note' => $note,
                'discount_type' => $discType,
                'discount_value' => $discValue,
                'items' => draft_inbound_items($skus, $qtys, $costs, $discType, $discValue),
            ];
        } else {
        $me = current_user();
        $wasPosted = (bool)$editingPosted;
        /* Menyimpan dokumen posted sebagai draft berarti mengembalikan stoknya. Hanya role yang
           boleh membuat transaksi yang boleh melakukannya, supaya dokumen tidak tertinggal sebagai
           draft yang tidak bisa dilanjutkan oleh user tersebut. */
        if ($wasPosted && $op === 'save' && !can('tx.create')) {
            flash('Role Anda hanya boleh menyimpan koreksi dengan tombol <strong>Simpan &amp; Posting Ulang</strong>.', 'error');
            redirect('inbound_form.php?id=' . $did);
        }
        try {
            $did = db_tx(function () use ($did, $docDate, $supplierId, $note, $pids, $qtys, $costs, $discType, $discValue, $me, $op, $wasPosted) {
                if ($did > 0) {
                    $doc = db_one('SELECT * FROM inbounds WHERE id = ?', [$did]);
                    if (!$doc) throw new RuntimeException('Dokumen tidak ditemukan.');
                    if ((string)$doc['status'] === 'void') throw new RuntimeException('Dokumen yang sudah di-void tidak bisa diubah.');
                    if ((string)$doc['status'] === 'posted') {
                        if (!can('tx.edit_posted')) throw new RuntimeException('Role Anda tidak boleh mengoreksi dokumen yang sudah diposting.');
                        /* Stok lama dibalik, kartu stok versi lama dihapus, lalu HPP FIFO disusun ulang
                           dari isi yang baru. Kalau posting ulang gagal, seluruh koreksi dibatalkan. */
                        reopen_posted_document('inbound', $did, 'isi dokumen dikoreksi', doc_items('inbound', $did));
                    }
                    db_run('UPDATE inbounds SET doc_date=?, supplier_id=?, note=?, discount_type=?, discount_value=? WHERE id=?',
                        [$docDate, $supplierId, $note, $discType, $discValue, $did]);
                } else {
                    $docNo = next_doc_no('inbound', 'IN', $docDate);
                    db_run('INSERT INTO inbounds (doc_no, doc_date, supplier_id, note, status, discount_type, discount_value, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
                        [$docNo, $docDate, $supplierId, $note, 'draft', $discType, $discValue, (int)$me['id'], now()]);
                    $did = (int)db()->lastInsertId();
                }
                save_inbound_items($did, $pids, $qtys, $costs);
                /* diskon dibagi proporsional ke setiap baris, lalu total dokumen dihitung ulang.
                   recalc_doc_totals() wajib dipanggil di sini: tanpa itu dokumen yang disimpan
                   sebagai DRAFT akan tampil bernilai 0 di daftar (total hanya terhitung saat posting). */
                apply_inbound_discount($did);
                recalc_doc_totals('inbound', $did);
                /* posting dijalankan DI DALAM transaksi yang sama supaya koreksi dokumen posted
                   tidak pernah meninggalkan stok setengah jadi (mis. stok sudah dibalik tapi gagal posting). */
                if ($op === 'save_post') {
                    $res = post_document('inbound', $did);
                    if (!$res['ok']) throw new RuntimeException(implode(' ', $res['errors']));
                }
                return $did;
            });
        } catch (Throwable $ex) {
            flash('Gagal menyimpan: ' . e($ex->getMessage()), 'error');
            redirect('inbound_form.php' . ($did ? '?id=' . $did : ''));
        }

        $docNo = (string)db_scalar('SELECT doc_no FROM inbounds WHERE id = ?', [$did]);
        log_activity('save', ($wasPosted ? 'Koreksi' : 'Simpan') . ' barang masuk ' . $docNo, 'inbound', $docNo);
        $warn = stock_negative_warning(array_values(array_filter(array_map('intval', $pids))));
        if ($warn !== '') flash($warn, 'warn');

        if ($op === 'save_post') {
            flash('Dokumen <strong>' . e($docNo) . '</strong> berhasil diposting; stok sudah bertambah.'
                . ($wasPosted ? ' Isi lama sudah dibalik dan diganti isi yang baru (HPP dihitung ulang).' : ''));
            redirect('inbound_form.php?id=' . $did);
        }
        if ($wasPosted) {
            flash('Perubahan pada dokumen <strong>' . e($docNo) . '</strong> disimpan sebagai <strong>draft</strong>. '
                . 'Stok dari dokumen ini sudah dikembalikan sementara &mdash; klik <strong>Simpan &amp; Posting</strong> '
                . 'kalau perbaikannya sudah selesai.', 'warn');
            redirect('inbound_form.php?id=' . $did);
        }
        flash('Dokumen <strong>' . e($docNo) . '</strong> disimpan sebagai draft.');
        redirect('inbound.php');
        }   // akhir blok simpan (dilewati bila ada kolom yang belum lengkap)
    }
}

$formError = $formError ?? '';
$formErrorField = $formErrorField ?? '';
$keep = $keep ?? null;

$doc = null;
$items = [];
if ($keep !== null) {
    /* input yang belum bisa disimpan: tampilkan kembali persis seperti yang diisi pengguna */
    $items = $keep['items'];
} elseif ($id > 0) {
    $doc = db_one('SELECT i.*, u.name AS created_name FROM inbounds i LEFT JOIN users u ON u.id = i.created_by WHERE i.id = ?', [$id]);
    if (!$doc) {
        flash('Dokumen tidak ditemukan.', 'error');
        redirect('inbound.php');
    }
    $items = doc_items('inbound', $id);
}
/* Dokumen posted boleh dikoreksi semua user (tx.edit_posted); dokumen baru/ganti draft butuh tx.create.
   Dokumen void selalu hanya-baca. */
$isPosted = $doc && (string)$doc['status'] === 'posted';
$canEdit = (bool)$doc
    ? ((string)$doc['status'] === 'draft' ? can('tx.create') : ($isPosted && can('tx.edit_posted')))
    : can('tx.create');
/* nilai kolom header: pakai input yang dipertahankan bila ada */
$vDate = $keep['doc_date'] ?? ($doc['doc_date'] ?? today());
$vSupplier = (int)($keep['supplier_id'] ?? ($doc['supplier_id'] ?? 0));
$vNote = $keep['note'] ?? ($doc['note'] ?? '');
$vDiscType = $keep['discount_type'] ?? ($doc['discount_type'] ?? 'percent');
$vDiscValue = $keep['discount_value'] ?? ($doc['discount_value'] ?? '');
$suppliers = db_all('SELECT id, name, active FROM suppliers ORDER BY name');
$products = db_all("SELECT p.id, p.sku, p.unit, p.stock_qty, p.cost_price, p.cost_price_initial FROM products p WHERE p.active = 1 ORDER BY p.sku");
$brands = db_all('SELECT id, name FROM brands WHERE active = 1 ORDER BY name');
$backUrl = $doc ? ('inbound.php?q=' . urlencode((string)$doc['doc_no'])) : 'inbound.php';

page_start($doc ? ('Barang Masuk ' . $doc['doc_no']) : 'Barang Masuk Baru', 'inbound');
?>
<div class="grid" style="gap:16px">
  <div class="stepline">
    <a class="btn btn-sm" href="<?= e($backUrl) ?>"><?= icon('arrow-left') ?> Kembali ke daftar</a>
    <?php if ($doc): ?>
      <?= status_badge((string)$doc['status']) ?>
      <span class="muted">Dibuat oleh <?= e($doc['created_name'] ?? '-') ?> &middot; <?= e(fmt_dt($doc['created_at'])) ?></span>
      <?php if (!empty($doc['posted_at'])): ?>
        <span class="badge badge-info">Diposting <?= e(fmt_dt($doc['posted_at'])) ?></span>
      <?php endif; ?>
      <?php if (!empty($doc['voided_at'])): ?>
        <span class="badge badge-danger">Di-void <?= e(fmt_dt($doc['voided_at'])) ?></span>
      <?php endif; ?>
      <?php if ($doc['status'] === 'void'): ?><span class="badge badge-danger">Void: <?= e($doc['void_reason']) ?></span><?php endif; ?>
      <button class="btn btn-sm no-print" data-print><?= icon('print') ?> Cetak</button>
    <?php endif; ?>
  </div>
</div>

<?php if ($isPosted && $canEdit): ?>
<div class="alert alert-info">
  <?= icon('edit') ?> <strong>Dokumen ini sudah diposting &mdash; tetap bisa dikoreksi.</strong>
  Saat Anda menyimpan, stok dari isi lama dibalik lalu stok dari isi baru diterapkan, dan HPP FIFO dihitung ulang.
  <div class="small muted" style="margin-top:6px">
    <strong>Simpan &amp; Posting</strong> = simpan perubahan sekaligus menerapkan stoknya (status tetap Posted).
    <strong>Simpan sebagai Draft</strong> = stok dikembalikan dulu, dokumen bisa dilanjutkan/diposting nanti.
    Perubahan tercatat di <a href="activity.php">Log Aktivitas</a>.
  </div>
</div>
<?php endif; ?>

<?php if ($formError !== ''): ?>
<div class="alert alert-warn" id="form-error">
  <?= icon('ban') ?> <strong>Belum bisa disimpan.</strong> <?= $formError ?>
  <div class="small muted" style="margin-top:6px">
    Data yang sudah Anda isi (barang, jumlah, harga, diskon) masih ada di halaman ini &mdash; tidak ada yang hilang.
  </div>
</div>
<?php endif; ?>

<section class="card">
  <?php card_start($doc ? ('Dokumen ' . $doc['doc_no']) : 'Input Barang Masuk', 'Barang masuk menambah stok setelah diposting.'); ?>
  <form method="post" id="docForm">
    <?= csrf_field() ?>
    <input type="hidden" name="op" value="save"><input type="hidden" name="id" value="<?= (int)($doc['id'] ?? 0) ?>">
    <div class="form-grid">
      <div><label>No. Dokumen</label><input type="text" value="<?= e($doc['doc_no'] ?? 'otomatis saat disimpan') ?>" readonly></div>
      <div><label>Tanggal Terima</label><input type="date" name="doc_date" value="<?= e($vDate) ?>" <?= $canEdit ? '' : 'readonly' ?>></div>
      <div>
        <label>Supplier *</label>
        <select name="supplier_id" id="supplierSelect" <?= $canEdit ? '' : 'disabled' ?>
                class="<?= $formErrorField === 'supplier_id' ? 'field-error' : '' ?>">
          <option value="">- pilih supplier -</option>
          <?php foreach ($suppliers as $s): ?>
            <option value="<?= (int)$s['id'] ?>" <?= $vSupplier === (int)$s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?><?= (int)$s['active'] === 0 ? ' (nonaktif)' : '' ?></option>
          <?php endforeach; ?>
        </select>
        <p class="help">Wajib diisi: dari supplier mana barang ini diterima.</p>
      </div>
      <div><label>Catatan</label><input type="text" name="note" value="<?= e($vNote) ?>" <?= $canEdit ? '' : 'readonly' ?> placeholder="no. surat jalan / keterangan"></div>
    </div>

    <div class="divider"></div>

    <?php if ($canEdit) sku_scan_tools([
        'mode' => 'items',
        'canCreate' => can('master.edit'),
        'brands' => $brands,
        /* Harga beli diisi otomatis dari HPP AWAL (harga penerimaan pertama), bukan HPP rata-rata. */
        'priceKey' => 'cost_price_initial',
        'priceLabel' => 'Harga Beli',
        'csrf' => csrf_token(),
        'hint' => 'Scan barcode/QR (USB atau Bluetooth mode keyboard) atau ketik SKU lalu Enter — barang langsung masuk daftar dengan qty 1. Kolom harga terisi otomatis dari HPP Awal; ubah bila harga belinya berbeda.',
    ]); ?>

    <div class="disc-panel">
      <div class="disc-head"><?= icon('tag') ?> <strong>Diskon Total Dokumen</strong>
        <span class="muted">Diskon dibagi rata ke setiap SKU sesuai nilainya, jadi harga satuan tiap barang langsung memakai harga setelah diskon.</span>
      </div>
      <div class="disc-grid">
        <div>
          <label>Jenis Diskon</label>
          <select name="discount_type" id="discountType" data-discount-input <?= $canEdit ? '' : 'disabled' ?>>
            <option value="percent" <?= $vDiscType === 'percent' ? 'selected' : '' ?>>Persen (%)</option>
            <option value="amount" <?= $vDiscType === 'amount' ? 'selected' : '' ?>>Rupiah (Rp)</option>
          </select>
        </div>
        <div>
          <label>Nilai Diskon</label>
          <input type="text" name="discount_value" id="discountValue" data-discount-input
                 value="<?= e((float)$vDiscValue > 0 ? fmt_qty($vDiscValue) : '') ?>"
                 placeholder="contoh: 10" <?= $canEdit ? '' : 'readonly' ?>>
          <p class="help">Isi <strong>10</strong> berarti diskon 10%. Kalau memilih Rupiah, isi nilainya (contoh 15000).</p>
        </div>
        <div class="disc-ringkas">
          <div><span>Subtotal</span><strong id="ringkasSubtotal"><?= fmt_money($doc['subtotal_amount'] ?? 0) ?></strong></div>
          <div><span>Diskon</span><strong id="ringkasDiscount"><?= fmt_money($doc['discount_amount'] ?? 0) ?></strong></div>
          <div class="disc-total"><span>Total Dibayar</span><strong id="ringkasTotal"><?= fmt_money($doc['total_amount'] ?? 0) ?></strong></div>
        </div>
      </div>
    </div>

    <div class="table-wrap">
      <table id="itemTable" data-items data-money="1"
             data-total-qty="totQty" data-total-amount="totAmount"
             data-subtotal-id="calcSubtotal" data-discount-amount-id="calcDiscount" data-final-id="calcFinal"
             data-discount-type="discountType" data-discount-value="discountValue">
        <thead><tr>
          <th style="min-width:200px">SKU</th>
          <th class="num qty-col">Qty</th>
          <th class="num" style="width:160px">Harga Beli (HPP Awal)</th>
          <th class="num" style="width:140px">Subtotal</th>
          <th class="num" style="width:140px">Diskon Baris</th>
          <th class="num" style="width:160px">Harga Setelah Diskon</th>
          <th class="num" style="width:150px">Subtotal Net</th>
          <?php if ($canEdit): ?><th style="width:80px"></th><?php endif; ?>
        </tr></thead>
        <tbody id="itemBody">
        <?php foreach ($items as $it): ?>
          <tr data-sku="<?= e($it['sku']) ?>">
            <td>
              <input class="sku-input" type="text" data-sku-input name="item_sku[]" value="<?= e($it['sku']) ?>" placeholder="scan / ketik SKU" autocomplete="off" spellcheck="false" autocapitalize="characters" <?= $canEdit ? '' : 'readonly' ?>>
              <div class="sku-hint small muted"></div>
            </td>
            <td class="qty-cell"><?= $canEdit ? qty_stepper($it['qty'], true) : qty_stepper($it['qty'], false) ?></td>
            <td><input class="qty-input" style="max-width:140px" type="text" name="item_price[]" value="<?= e((float)$it['unit_cost'] > 0 ? fmt_num($it['unit_cost']) : '') ?>" placeholder="isi harga" <?= $canEdit ? '' : 'readonly' ?>></td>
            <td class="num row-subtotal"><?= fmt_money($it['subtotal']) ?></td>
            <td class="num row-disc-share"><?= (float)$it['discount_share'] > 0 ? fmt_money($it['discount_share']) : '-' ?></td>
            <td class="num"><strong class="row-unit-net"><?= fmt_money($it['unit_cost_net'] ?: $it['unit_cost']) ?></strong><div class="small muted row-unit-disc"><?php
              $sharePerUnit = (float)$it['qty'] > 0 ? (float)$it['discount_share'] / (float)$it['qty'] : 0;
              echo $sharePerUnit > 0 ? 'diskon ' . fmt_money($sharePerUnit) . ' / satuan' : '';
            ?></div></td>
            <td class="num row-net"><?= fmt_money($it['subtotal_net'] ?: $it['subtotal']) ?></td>
            <?php if ($canEdit): ?><td><button class="btn btn-sm" type="button" onclick="this.closest('tr').remove();rowRecalc()">Hapus</button></td><?php endif; ?>
          </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr class="totals-row">
            <td class="right">TOTAL</td>
            <td class="num" id="totQty">0</td>
            <td></td>
            <td class="num" id="calcSubtotal"><?= fmt_money($doc['subtotal_amount'] ?? 0) ?></td>
            <td class="num" id="calcDiscount"><?= fmt_money($doc['discount_amount'] ?? 0) ?></td>
            <td></td>
            <td class="num" id="totAmount"><?= fmt_money($doc['total_amount'] ?? 0) ?></td>
            <?php if ($canEdit): ?><td></td><?php endif; ?>
          </tr>
        </tfoot>
      </table>
    </div>

    <?php if ($canEdit): ?>
    <template id="itemTpl">
      <td>
        <input class="sku-input" type="text" data-sku-input name="item_sku[]" placeholder="scan / ketik SKU" autocomplete="off" spellcheck="false" autocapitalize="characters">
        <div class="sku-hint small muted"></div>
      </td>
      <td class="qty-cell"><?= qty_stepper(1) ?></td>
      <td><input class="qty-input" style="max-width:140px" type="text" name="item_price[]" placeholder="isi harga" oninput="rowRecalc()"></td>
      <td class="num row-subtotal">Rp 0</td>
      <td class="num row-disc-share">-</td>
      <td class="num"><strong class="row-unit-net">Rp 0</strong><div class="small muted row-unit-disc"></div></td>
      <td class="num row-net">Rp 0</td>
      <td><button class="btn btn-sm" type="button" onclick="this.closest('tr').remove();rowRecalc()">Hapus</button></td>
    </template>
    <?php endif; ?>

    <div class="form-actions">
      <?php if ($canEdit): ?>
        <button class="btn" type="button" onclick="itemRows.add({bodyId:'itemBody',tplId:'itemTpl'})"><?= icon('plus') ?> Baris kosong</button>
        <div style="flex:1"></div>
        <?php if ($isPosted): ?>
          <?php if (can('tx.create')): ?>
            <button class="btn" type="submit">Simpan sebagai Draft (stok dikembalikan)</button>
          <?php endif; ?>
          <button class="btn btn-primary" type="button"
                  onclick="submitPost('Simpan koreksi & posting ulang? Stok dari isi lama dibalik, lalu isi baru diterapkan & HPP dihitung ulang.')">Simpan &amp; Posting Ulang</button>
        <?php else: ?>
          <button class="btn" type="submit">Simpan sebagai Draft</button>
          <button class="btn btn-primary" type="button" onclick="submitPost('Posting dokumen ini? Stok akan bertambah.')">Simpan &amp; Posting</button>
        <?php endif; ?>
      <?php elseif ($doc && $doc['status'] === 'draft' && can('tx.edit')): ?>
        <button class="btn btn-primary" type="submit" name="op" value="post_id">Posting Sekarang</button>
      <?php endif; ?>
    </div>
  </form>
  <?php card_end(); ?>
</section>

<?php if ($doc && $doc['status'] === 'posted'): ?>
<section class="card">
  <?php card_start('Pergerakan Stok dari Dokumen Ini', 'Baris pembatalan muncul bila dokumen di-void.'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal</th><th>Produk</th><th class="num">Perubahan</th><th class="num">Saldo Stok</th><th>Catatan</th></tr></thead>
        <tbody>
        <?php foreach (doc_ledger_rows('inbound', (int)$doc['id']) as $l): ?>
          <tr>
            <td><?= e(fmt_date($l['move_date'])) ?></td>
            <td class="mono"><?= e($l['sku']) ?></td>
            <td class="num" style="color:<?= (float)$l['qty_change'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ((float)$l['qty_change'] >= 0 ? '+' : '') . fmt_qty($l['qty_change']) ?></td>
            <td class="num"><?= fmt_qty($l['qty_after']) ?></td>
            <td class="small"><?= e($l['note'] ?: doc_label((string)$l['ref_type'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<?php if ($doc && $doc['status'] === 'posted' && is_admin()): ?>
<section class="card">
  <?php card_start('Void Dokumen', 'Void membalik pergerakan stok dokumen ini (stok dikurangi kembali).'); ?>
    <form method="post" data-need-reason data-confirm="<?= e(void_confirm_text('inbound', (int)$doc['id'], (string)$doc['doc_no'])) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="op" value="void"><input type="hidden" name="id" value="<?= (int)$doc['id'] ?>">
      <input type="text" name="void_reason" placeholder="alasan void (wajib)" required>
      <div class="form-actions"><button class="btn btn-danger" type="submit"><?= icon('ban') ?> Void Dokumen</button></div>
    </form>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<script src="<?= e(asset_url('assets/sku.js')) ?>"></script>
<script>
<?= product_js_maps($products, 'cost_price_initial') ?>
function rowRecalc() {
  itemRows.recalc({ tableId: 'itemTable', stockMap: window.PRODUCT_STOCK, totalQtyId: 'totQty', totalAmountId: 'totAmount' });
  syncDiscountSummary();
}

/* ringkasan di panel diskon selalu mengikuti angka tabel,
   termasuk saat nilainya diubah dari kolom mana pun di halaman ini */
document.addEventListener('items:recalc', function (ev) {
  if (!ev.detail || ev.detail.tableId !== 'itemTable') return;
  var s = document.getElementById('ringkasSubtotal');
  var d = document.getElementById('ringkasDiscount');
  var t = document.getElementById('ringkasTotal');
  if (s) s.textContent = fmtMoney(ev.detail.gross);
  if (d) d.textContent = fmtMoney(ev.detail.discount);
  if (t) t.textContent = fmtMoney(ev.detail.total);
});

/* mengubah kolom diskon langsung menghitung ulang tabel + ringkasan */
['discountType', 'discountValue'].forEach(function (id) {
  var el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('input', function () { if (el.id === 'discountValue') rowRecalc(); });
  el.addEventListener('change', rowRecalc);
});
/* ringkasan diskon di panel atas memakai angka yang sama dengan tabel */
function syncDiscountSummary() {
  var map = { ringkasSubtotal: 'calcSubtotal', ringkasDiscount: 'calcDiscount', ringkasTotal: 'totAmount' };
  Object.keys(map).forEach(function (dst) {
    var a = document.getElementById(map[dst]), b = document.getElementById(dst);
    if (a && b) b.textContent = a.textContent;
  });
}
function submitPost(msg) {
  if (!confirm(msg)) return;
  var f = document.getElementById('docForm');
  f.querySelector('input[name=op]').value = 'save_post';
  f.submit();
}
document.addEventListener('DOMContentLoaded', rowRecalc);

/* Saat ada kolom yang belum lengkap: arahkan perhatian ke kolom itu tanpa mengubah isian lain. */
document.addEventListener('DOMContentLoaded', function () {
  var err = document.getElementById('form-error');
  if (!err) return;
  var field = document.getElementById('supplierSelect');
  if (field && !field.disabled) {
    try { field.focus({ preventScroll: true }); } catch (e) { field.focus(); }
  }
  try { err.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { }
});
</script>
<?php page_end(); ?>
