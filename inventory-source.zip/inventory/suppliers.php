<?php
require_once __DIR__ . '/includes/init.php';
require_perm('master.view');

$id = (int)get('id');
$edit = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (!can('master.edit')) {
        flash('Role Anda hanya bisa melihat data master.', 'error');
        redirect('suppliers.php');
    }
    $op = (string)post('op');
    $sid = (int)post('id');
    if ($op === 'save') {
        $code = strtoupper((string)post('code'));
        $name = (string)post('name');
        $data = [
            'contact_person' => (string)post('contact_person'),
            'phone' => (string)post('phone'),
            'email' => (string)post('email'),
            'address' => (string)post('address'),
            'active' => (int)post('active') === 1 ? 1 : 0,
        ];
        if ($code === '' || $name === '') {
            flash('Kode dan Nama Supplier wajib diisi.', 'error');
            redirect('suppliers.php?id=' . $sid);
        }
        $dupe = db_one('SELECT id FROM suppliers WHERE (code = ? OR name = ?) AND id <> ?', [$code, $name, $sid]);
        if ($dupe) {
            flash('Kode atau nama supplier sudah dipakai.', 'error');
            redirect('suppliers.php?id=' . $sid);
        }
        if ($sid > 0) {
            db_run('UPDATE suppliers SET code=?, name=?, contact_person=?, phone=?, email=?, address=?, active=? WHERE id=?',
                [$code, $name, $data['contact_person'], $data['phone'], $data['email'], $data['address'], $data['active'], $sid]);
            log_activity('update', 'Ubah supplier ' . $code . ' - ' . $name, 'supplier', $code);
            flash('Supplier <strong>' . e($name) . '</strong> berhasil diperbarui.');
        } else {
            db_run('INSERT INTO suppliers (code, name, contact_person, phone, email, address, active, created_at) VALUES (?,?,?,?,?,?,?,?)',
                [$code, $name, $data['contact_person'], $data['phone'], $data['email'], $data['address'], $data['active'], now()]);
            log_activity('create', 'Tambah supplier ' . $code . ' - ' . $name, 'supplier', $code);
            flash('Supplier <strong>' . e($name) . '</strong> berhasil ditambahkan.');
        }
        redirect('suppliers.php');
    }
    if ($op === 'toggle') {
        db_run('UPDATE suppliers SET active = CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id = ?', [$sid]);
        log_activity('toggle', 'Ubah status aktif supplier #' . $sid, 'supplier', (string)$sid);
        flash('Status supplier berhasil diubah.');
        redirect('suppliers.php');
    }
}

if ($id > 0) $edit = db_one('SELECT * FROM suppliers WHERE id = ?', [$id]);

$q = (string)get('q');
$wsql = '';
$params = [];
if ($q !== '') {
    $wsql = 'WHERE (s.code LIKE ? OR s.name LIKE ? OR s.phone LIKE ?)';
    $params = ['%' . $q . '%', '%' . $q . '%', '%' . $q . '%'];
}
$rows = db_all(
    "SELECT s.*,
            (SELECT COUNT(*) FROM inbounds i WHERE i.supplier_id = s.id) AS inbound_count,
            (SELECT COALESCE(SUM(total_amount),0) FROM inbounds i WHERE i.supplier_id = s.id AND i.status='posted') AS purchase_total
       FROM suppliers s $wsql ORDER BY s.name",
    $params
);

page_start('Supplier', 'suppliers');
?>
<div class="grid grid-3">
  <div class="card stat"><span class="label">Total Supplier</span><span class="value"><?= fmt_num(count($rows)) ?></span></div>
  <div class="card stat"><span class="label">Supplier Aktif</span><span class="value"><?= fmt_num((int)db_scalar('SELECT COUNT(*) FROM suppliers WHERE active = 1')) ?></span></div>
  <div class="card stat"><span class="label">Total Pembelian (Posted)</span><span class="value" style="font-size:20px"><?= fmt_money((float)(db_scalar("SELECT COALESCE(SUM(total_amount),0) FROM inbounds WHERE status='posted'") ?? 0)) ?></span></div>
</div>

<section class="card">
  <?php card_start('Daftar Supplier', 'Dipakai pada transaksi Barang Masuk (inbound) dan retur ke supplier.',
      '<a class="btn btn-sm" href="export.php?type=suppliers">' . icon('export') . ' Export Excel</a>'
      . '<a class="btn btn-sm" href="import.php?ds=suppliers">' . icon('import') . ' Import</a>'); ?>
    <form class="filters" method="get" style="margin-bottom:18px">
      <div class="f-item" style="min-width:240px"><label>Cari</label><input type="text" name="q" value="<?= e($q) ?>" placeholder="kode / nama / telepon"></div>
      <button class="btn btn-primary" type="submit">Cari</button>
      <a class="btn" href="suppliers.php">Reset</a>
    </form>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Kode</th><th>Nama Supplier</th><th>Kontak</th><th>Telepon</th><th>Email</th><th class="num">Dokumen Masuk</th><th class="num">Total Pembelian</th><th>Status</th><?php if (can('master.edit')): ?><th></th><?php endif; ?></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="9"><?= empty_state('Belum ada supplier.') ?></td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td class="mono"><?= e($r['code']) ?></td>
            <td><a href="suppliers.php?id=<?= (int)$r['id'] ?>"><?= e($r['name']) ?></a></td>
            <td><?= e($r['contact_person'] ?: '-') ?></td>
            <td><?= e($r['phone'] ?: '-') ?></td>
            <td><?= e($r['email'] ?: '-') ?></td>
            <td class="num"><?= fmt_num($r['inbound_count']) ?></td>
            <td class="num"><?= fmt_money($r['purchase_total']) ?></td>
            <td><?= (int)$r['active'] === 1 ? '<span class="badge badge-ok">Aktif</span>' : '<span class="badge badge-muted">Nonaktif</span>' ?></td>
            <?php if (can('master.edit')): ?>
            <td><form class="inline-form" method="post" data-confirm="Ubah status aktif supplier ini?">
              <?= csrf_field() ?><input type="hidden" name="op" value="toggle"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="btn btn-sm" type="submit"><?= (int)$r['active'] === 1 ? 'Nonaktifkan' : 'Aktifkan' ?></button>
            </form></td>
            <?php endif; ?>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<?php if (can('master.edit')): ?>
<section class="card">
  <?php card_start($edit ? ('Ubah Supplier: ' . $edit['name']) : 'Tambah Supplier'); ?>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="op" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
      <div class="form-grid">
        <div><label>Kode Supplier *</label><input type="text" name="code" value="<?= e($edit['code'] ?? '') ?>" required></div>
        <div><label>Nama Supplier *</label><input type="text" name="name" value="<?= e($edit['name'] ?? '') ?>" required></div>
        <div><label>Nama Kontak</label><input type="text" name="contact_person" value="<?= e($edit['contact_person'] ?? '') ?>"></div>
        <div><label>Telepon / WA</label><input type="text" name="phone" value="<?= e($edit['phone'] ?? '') ?>"></div>
        <div><label>Email</label><input type="email" name="email" value="<?= e($edit['email'] ?? '') ?>"></div>
        <div class="field-full"><label>Alamat</label><textarea name="address"><?= e($edit['address'] ?? '') ?></textarea></div>
        <div><label>Status</label>
          <select name="active">
            <option value="1" <?= (int)($edit['active'] ?? 1) === 1 ? 'selected' : '' ?>>Aktif</option>
            <option value="0" <?= isset($edit['active']) && (int)$edit['active'] === 0 ? 'selected' : '' ?>>Nonaktif</option>
          </select>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-primary" type="submit"><?= $edit ? 'Simpan Perubahan' : 'Simpan Supplier' ?></button>
        <?php if ($edit): ?><a class="btn" href="suppliers.php">Batal</a><?php endif; ?>
      </div>
    </form>
  <?php card_end(); ?>
</section>
<?php endif; ?>
<?php page_end(); ?>
