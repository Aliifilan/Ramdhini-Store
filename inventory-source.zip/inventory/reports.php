<?php
require_once __DIR__ . '/includes/init.php';
require_perm('report.view');

$to = input_date('to', today());
$from = input_date('from', date('Y-m-d', strtotime($to . ' -29 days')));
if ($from > $to) { $tmp = $from; $from = $to; $to = $tmp; }
$prevDay = date('Y-m-d', strtotime($from . ' -1 day'));

$mat = daily_stock_matrix($prevDay, $to);
$openQty = isset($mat['totals'][$prevDay]) ? (float)$mat['totals'][$prevDay] : 0.0;
$endQty = $mat['dates'] ? (float)$mat['totals'][$mat['dates'][count($mat['dates']) - 1]] : 0.0;

$base = "REPLACE(l.ref_type,'_void','')";
$totals = db_one(
    "SELECT
        COALESCE(SUM(CASE WHEN $base IN ('inbound','return_customer','opening') THEN l.qty_change ELSE 0 END),0) AS masuk,
        COALESCE(SUM(CASE WHEN $base IN ('outbound','return_supplier') THEN l.qty_change ELSE 0 END),0) AS keluar,
        COALESCE(SUM(CASE WHEN $base IN ('adjustment','opname') THEN l.qty_change ELSE 0 END),0) AS penyesuaian,
        COALESCE(SUM(l.qty_change),0) AS total
       FROM ledger l WHERE l.move_date BETWEEN ? AND ?",
    [$from, $to]
);

$byBrand = db_all(
    "SELECT COALESCE(b.name,'Tanpa brand') AS brand,
            COALESCE(SUM(CASE WHEN $base IN ('inbound','return_customer','opening') THEN l.qty_change ELSE 0 END),0) AS masuk,
            COALESCE(SUM(CASE WHEN $base IN ('outbound','return_supplier') THEN l.qty_change ELSE 0 END),0) AS keluar,
            COALESCE(SUM(CASE WHEN $base IN ('adjustment','opname') THEN l.qty_change ELSE 0 END),0) AS penyesuaian,
            COALESCE(SUM(l.qty_change),0) AS netto,
            COALESCE(SUM(p.stock_qty * p.cost_price),0) AS nilai_akhir
       FROM ledger l JOIN products p ON p.id = l.product_id LEFT JOIN brands b ON b.id = p.brand_id
      WHERE l.move_date BETWEEN ? AND ?
      GROUP BY COALESCE(b.name,'Tanpa brand') ORDER BY brand",
    [$from, $to]
);

$moveF = (string)get('move', 'all');
$having = '';
if ($moveF === 'in') $having = 'HAVING masuk > 0';
if ($moveF === 'out') $having = 'HAVING keluar > 0';
if ($moveF === 'adjust') $having = 'HAVING penyesuaian <> 0';
if ($moveF === 'idle') $having = 'HAVING masuk = 0 AND keluar = 0 AND penyesuaian = 0';

$prodSql = "SELECT p.sku, COALESCE(b.name,'-') AS brand, p.unit, p.stock_qty,
        COALESCE(SUM(CASE WHEN $base IN ('inbound','return_customer','opening') THEN l.qty_change ELSE 0 END),0) AS masuk,
        COALESCE(SUM(CASE WHEN $base IN ('outbound','return_supplier') THEN l.qty_change ELSE 0 END),0) AS keluar,
        COALESCE(SUM(CASE WHEN $base IN ('adjustment','opname') THEN l.qty_change ELSE 0 END),0) AS penyesuaian,
        COALESCE(SUM(l.qty_change),0) AS netto,
        (SELECT COALESCE(SUM(oi.subtotal),0) FROM outbound_items oi JOIN outbounds o2 ON o2.id = oi.outbound_id
          WHERE oi.product_id = p.id AND o2.status='posted' AND o2.doc_date BETWEEN ? AND ?) AS jual_periode,
        (SELECT COALESCE(SUM(oi.cogs),0) FROM outbound_items oi JOIN outbounds o2 ON o2.id = oi.outbound_id
          WHERE oi.product_id = p.id AND o2.status='posted' AND o2.doc_date BETWEEN ? AND ?) AS hpp_periode
      FROM products p LEFT JOIN brands b ON b.id = p.brand_id
      LEFT JOIN ledger l ON l.product_id = p.id AND l.move_date BETWEEN ? AND ?
      WHERE p.active = 1 GROUP BY p.id $having";
$prodRows = db_all($prodSql, [$from, $to, $from, $to, $from, $to]);
usort($prodRows, static fn($a, $b) => abs((float)$b['masuk'] + (float)$b['keluar']) <=> abs((float)$a['masuk'] + (float)$a['keluar']));

/* HPP FIFO & laba kotor (hanya dokumen barang keluar yang posted) */
$cogsTotal = db_one(
    "SELECT COALESCE(SUM(i.subtotal),0) AS jual, COALESCE(SUM(i.cogs),0) AS hpp
       FROM outbound_items i JOIN outbounds o ON o.id = i.outbound_id
      WHERE o.status = 'posted' AND o.doc_date BETWEEN ? AND ?",
    [$from, $to]
);

$docCounts = [
    'Barang masuk' => (int)db_scalar("SELECT COUNT(*) FROM inbounds WHERE status='posted' AND doc_date BETWEEN ? AND ?", [$from, $to]),
    'Barang keluar' => (int)db_scalar("SELECT COUNT(*) FROM outbounds WHERE status='posted' AND doc_date BETWEEN ? AND ?", [$from, $to]),
    'Adjustment' => (int)db_scalar("SELECT COUNT(*) FROM adjustments WHERE status='posted' AND doc_date BETWEEN ? AND ?", [$from, $to]),
    'Opname' => (int)db_scalar("SELECT COUNT(*) FROM opnames WHERE status='posted' AND doc_date BETWEEN ? AND ?", [$from, $to]),
    'Retur' => (int)db_scalar("SELECT COUNT(*) FROM returns WHERE status='posted' AND doc_date BETWEEN ? AND ?", [$from, $to]),
];

page_start('Laporan Ringkas', 'reports');
?>
<div class="grid" style="gap:16px">
  <section class="card">
    <?php card_start('Periode Laporan', 'Semua angka di bawah dihitung dari pergerakan kartu stok pada periode ini.',
        '<button class="btn btn-sm" data-print>' . icon('print') . ' Cetak</button>'
        . '<a class="btn btn-sm" href="export.php?type=rekap_ringkas&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Export Ringkasan</a>'
        . '<a class="btn btn-sm" href="export.php?type=ledger&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Export Kartu Stok</a>'); ?>
      <form class="filters no-print" method="get">
        <div class="f-item"><label>Dari</label><input type="date" name="from" value="<?= e($from) ?>"></div>
        <div class="f-item"><label>Sampai</label><input type="date" name="to" value="<?= e($to) ?>"></div>
        <button class="btn btn-primary" type="submit">Tampilkan</button>
        <a class="btn" href="?from=<?= e(date('Y-m-01')) ?>&to=<?= e(today()) ?>">Bulan ini</a>
        <a class="btn" href="?from=<?= e(date('Y-m-01', strtotime('-1 month'))) ?>&to=<?= e(date('Y-m-t', strtotime('-1 month'))) ?>">Bulan lalu</a>
      </form>
    <?php card_end(); ?>
  </section>
</div>

<div class="grid grid-4">
  <div class="card stat"><span class="label">Stok Awal Periode</span><span class="value"><?= fmt_qty($openQty) ?></span><span class="hint">per <?= e(fmt_date($prevDay)) ?></span></div>
  <div class="card stat"><span class="label">Total Masuk</span><span class="value" style="color:var(--ok)">+<?= fmt_qty($totals['masuk']) ?></span></div>
  <div class="card stat"><span class="label">Total Keluar</span><span class="value" style="color:var(--danger)"><?= fmt_qty($totals['keluar']) ?></span></div>
  <div class="card stat"><span class="label">Stok Akhir Periode</span><span class="value"><?= fmt_qty($endQty) ?></span><span class="hint">per <?= e(fmt_date($to)) ?></span></div>
</div>

<div class="grid grid-3">
  <div class="card stat"><span class="label">Penyesuaian (Adjustment + Opname)</span><span class="value" style="font-size:20px;color:<?= (float)$totals['penyesuaian'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ((float)$totals['penyesuaian'] >= 0 ? '+' : '') . fmt_qty($totals['penyesuaian']) ?></span><span class="hint">unit koreksi stok</span></div>
  <div class="card stat"><span class="label">Penjualan &amp; Laba Kotor (FIFO)</span>
    <span class="value" style="font-size:20px"><?= fmt_money($cogsTotal['jual']) ?></span>
    <span class="hint">HPP FIFO <?= fmt_money($cogsTotal['hpp']) ?> &middot;
      laba kotor <span style="color:var(--ok)"><strong><?= fmt_money((float)$cogsTotal['jual'] - (float)$cogsTotal['hpp']) ?></strong></span></span></div>
  <div class="card stat"><span class="label">Nilai Stok Akhir (HPP)</span><span class="value" style="font-size:20px"><?= fmt_money((float)(db_scalar('SELECT COALESCE(SUM(stock_qty*cost_price),0) FROM products') ?? 0)) ?></span></div>
  <div class="card stat"><span class="label">Dokumen Posted di Periode</span><span class="value" style="font-size:20px"><?= fmt_num(array_sum($docCounts)) ?></span><span class="hint"><?= e(implode(' · ', array_map(static fn($k, $v) => $k . ': ' . $v, array_keys($docCounts), $docCounts))) ?></span></div>
</div>

<section class="card">
  <?php card_start('Mutasi per Brand', 'Ringkasan arus barang tiap brand pada periode terpilih.',
      '<a class="btn btn-sm" href="export.php?type=stock_brand">' . icon('export') . ' Export Stok Brand</a>'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Brand</th><th class="num">Masuk</th><th class="num">Keluar</th><th class="num">Penyesuaian</th><th class="num">Netto</th><th class="num">Nilai Stok Akhir (HPP)</th></tr></thead>
        <tbody>
        <?php if (!$byBrand): ?><tr><td colspan="6"><?= empty_state('Belum ada mutasi pada periode ini.') ?></td></tr><?php endif; ?>
        <?php foreach ($byBrand as $b): ?>
          <tr>
            <td><?= e($b['brand']) ?></td>
            <td class="num" style="color:var(--ok)">+<?= fmt_qty($b['masuk']) ?></td>
            <td class="num" style="color:var(--danger)"><?= fmt_qty($b['keluar']) ?></td>
            <td class="num"><?= ((float)$b['penyesuaian'] >= 0 ? '+' : '') . fmt_qty($b['penyesuaian']) ?></td>
            <td class="num"><strong><?= ((float)$b['netto'] >= 0 ? '+' : '') . fmt_qty($b['netto']) ?></strong></td>
            <td class="num"><?= fmt_money($b['nilai_akhir']) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if ($byBrand): ?>
        <tr class="totals-row">
          <td>TOTAL</td>
          <td class="num">+<?= fmt_qty($totals['masuk']) ?></td>
          <td class="num"><?= fmt_qty($totals['keluar']) ?></td>
          <td class="num"><?= fmt_qty($totals['penyesuaian']) ?></td>
          <td class="num"><?= fmt_qty($totals['total']) ?></td>
          <td class="num"><?= fmt_money((float)(db_scalar('SELECT COALESCE(SUM(stock_qty*cost_price),0) FROM products') ?? 0)) ?></td>
        </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>

<section class="card">
  <?php card_start('Pergerakan per Produk', 'Produk diurutkan dari yang paling banyak bergerak.',
      '<a class="btn btn-sm" href="export.php?type=ledger&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Export Kartu Stok</a>'); ?>
    <form class="filters no-print" method="get" style="margin-bottom:16px">
      <input type="hidden" name="from" value="<?= e($from) ?>">
      <input type="hidden" name="to" value="<?= e($to) ?>">
      <div class="f-item"><label>Tampilkan</label>
        <select name="move">
          <?php foreach (['all' => 'Semua produk aktif', 'in' => 'Yang ada barang masuk', 'out' => 'Yang ada barang keluar', 'adjust' => 'Yang ada penyesuaian', 'idle' => 'Tanpa pergerakan'] as $k => $v): ?>
            <option value="<?= e($k) ?>" <?= $moveF === $k ? 'selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <button class="btn btn-primary" type="submit">Terapkan</button>
    </form>
    <div class="table-wrap">
      <table>
        <thead><tr><th>SKU</th><th>Brand</th><th class="num">Masuk</th><th class="num">Keluar</th><th class="num">Penyesuaian</th><th class="num">Netto</th><th class="num">Nilai Jual</th><th class="num">HPP FIFO</th><th class="num">Laba Kotor</th><th class="num">Stok Sekarang</th></tr></thead>
        <tbody>
        <?php if (!$prodRows): ?><tr><td colspan="10"><?= empty_state('Tidak ada data produk sesuai filter.') ?></td></tr><?php endif; ?>
        <?php foreach (array_slice($prodRows, 0, 200) as $r): ?>
          <tr>
            <td class="mono"><?= e($r['sku']) ?></td>
            <td><?= e($r['brand']) ?></td>
            <td class="num"><?= (float)$r['masuk'] != 0 ? '+' . fmt_qty($r['masuk']) : '-' ?></td>
            <td class="num"><?= (float)$r['keluar'] != 0 ? fmt_qty($r['keluar']) : '-' ?></td>
            <td class="num"><?= (float)$r['penyesuaian'] != 0 ? fmt_qty($r['penyesuaian']) : '-' ?></td>
            <td class="num"><?= ((float)$r['netto'] >= 0 ? '+' : '') . fmt_qty($r['netto']) ?></td>
            <td class="num"><?= (float)$r['jual_periode'] > 0 ? fmt_money($r['jual_periode']) : '<span class="muted">-</span>' ?></td>
            <td class="num"><?= (float)$r['hpp_periode'] > 0 ? fmt_money($r['hpp_periode']) : '<span class="muted">-</span>' ?></td>
            <td class="num"><?= (float)$r['jual_periode'] > 0
                ? '<span style="color:var(--ok)">' . fmt_money((float)$r['jual_periode'] - (float)$r['hpp_periode']) . '</span>'
                : '<span class="muted">-</span>' ?></td>
            <td class="num"><strong><?= fmt_qty($r['stock_qty']) ?></strong> <span class="muted"><?= e($r['unit']) ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php if (count($prodRows) > 200): ?><p class="help">Ditampilkan 200 produk dengan pergerakan terbesar dari total <?= fmt_num(count($prodRows)) ?> produk.</p><?php endif; ?>
  <?php card_end(); ?>
</section>
<?php page_end(); ?>
