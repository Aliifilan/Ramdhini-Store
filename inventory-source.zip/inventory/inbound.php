<?php
require_once __DIR__ . '/includes/init.php';
require_perm('tx.view');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $op = (string)post('op');
    $did = (int)post('id');
    if ($op === 'void') {
        if (!is_admin()) {
            flash('Hanya Admin yang boleh melakukan void dokumen.', 'error');
        } else {
            $reason = (string)post('void_reason');
            $res = void_document('inbound', $did, $reason !== '' ? $reason : 'tanpa alasan');
            if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil di-void; stok dikurangi kembali.');
            if (!empty($res['warning'])) flash($res['warning'], 'warn');
            else flash('Gagal void: ' . e(implode(' ', $res['errors'])), 'error');
        }
    }
    if ($op === 'post_id') {
        if (!can('tx.edit')) {
            flash('Role Anda tidak boleh memposting transaksi.', 'error');
        } else {
            $res = post_document('inbound', $did);
            if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil diposting; stok bertambah.');
            else flash('Gagal posting: ' . e(implode(' ', $res['errors'])), 'error');
        }
    }
    redirect('inbound.php');
}

$from = input_date('from', date('Y-m-d', strtotime('-30 days')));
$to = input_date('to', today());
$statusF = (string)get('status');
$supplierF = (int)get('supplier_id');
$q = (string)get('q');

$where = ['date(i.doc_date) BETWEEN ? AND ?'];
$params = [$from, $to];
if ($statusF !== '') { $where[] = 'i.status = ?'; $params[] = $statusF; }
if ($supplierF > 0) { $where[] = 'i.supplier_id = ?'; $params[] = $supplierF; }
if ($q !== '') {
    /* Pencarian bebas: nomor dokumen, catatan, nama supplier, ATAU SKU barang di dalam dokumen.
       Dengan mencari SKU, yang muncul adalah SEMUA dokumen yang memuat SKU itu — lengkap dengan
       supplier dan tanggalnya (pertanyaan yang paling sering: "barang ini masuk dari supplier
       mana, tanggal berapa?"). */
    $where[] = '(i.doc_no LIKE ? OR i.note LIKE ? OR s.name LIKE ? OR EXISTS (
                    SELECT 1 FROM inbound_items ii JOIN products p ON p.id = ii.product_id
                     WHERE ii.inbound_id = i.id AND p.sku LIKE ?))';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%");
}
$wsql = 'WHERE ' . implode(' AND ', $where);

$total = (int)db_scalar("SELECT COUNT(*) FROM inbounds i LEFT JOIN suppliers s ON s.id=i.supplier_id $wsql", $params);
$pg = pager($total, 25);
$rows = db_all(
    "SELECT i.*, s.name AS supplier_name, u.name AS created_name
       FROM inbounds i LEFT JOIN suppliers s ON s.id = i.supplier_id LEFT JOIN users u ON u.id = i.created_by
       $wsql ORDER BY i.doc_date DESC, i.id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}",
    $params
);

/* Dampak void dihitung sekaligus (satu query per jenis dokumen) supaya tombol Void
   bisa memperingatkan lebih dulu bila stok akan menjadi minus. */
$voidRefs = [];
foreach ($rows as $r) {
    if ((string)$r['status'] === 'posted') $voidRefs[] = ['inbound', (int)$r['id']];
}
$voidImpact = void_impacts($voidRefs);
$voidConfirm = [];
foreach ($rows as $r) {
    $key = 'inbound:' . (int)$r['id'];
    $voidConfirm[(int)$r['id']] = void_confirm_text('inbound', (int)$r['id'], (string)$r['doc_no'], $voidImpact[$key] ?? []);
}
$sumQty = (float)(db_scalar("SELECT COALESCE(SUM(i.total_qty),0) FROM inbounds i LEFT JOIN suppliers s ON s.id=i.supplier_id $wsql AND i.status='posted'", $params) ?? 0);
$sumAmt = (float)(db_scalar("SELECT COALESCE(SUM(i.total_amount),0) FROM inbounds i LEFT JOIN suppliers s ON s.id=i.supplier_id $wsql AND i.status='posted'", $params) ?? 0);
$sumDisc = (float)(db_scalar("SELECT COALESCE(SUM(i.discount_amount),0) FROM inbounds i LEFT JOIN suppliers s ON s.id=i.supplier_id $wsql AND i.status='posted'", $params) ?? 0);
$suppliers = db_all('SELECT id, name FROM suppliers ORDER BY name');
$skuMap = doc_sku_map('inbound', array_column($rows, 'id'));

page_start('Barang Masuk (Inbound)', 'inbound');
?>
<div class="grid grid-4">
  <div class="card stat"><span class="label">Dokumen Periode</span><span class="value"><?= fmt_num($total) ?></span><span class="hint"><?= e(fmt_date($from)) ?> &ndash; <?= e(fmt_date($to)) ?></span></div>
  <div class="card stat"><span class="label">Unit Masuk (Posted)</span><span class="value" style="color:var(--ok)">+<?= fmt_qty($sumQty) ?></span></div>
  <div class="card stat"><span class="label">Total Dibayar (Posted)</span><span class="value" style="font-size:20px"><?= fmt_money($sumAmt) ?></span>
    <span class="hint">setelah diskon &minus;<?= fmt_money($sumDisc) ?></span></div>
  <div class="card stat"><span class="label">Draft Belum Posting</span><span class="value"><?= fmt_num((int)db_scalar("SELECT COUNT(*) FROM inbounds WHERE status='draft'")) ?></span><span class="hint">belum menambah stok</span></div>
</div>

<section class="card">
  <?php card_start('Daftar Barang Masuk', 'Dokumen berstatus <strong>Draft</strong> belum mengubah stok. Posting untuk menambah stok.',
      '<a class="btn btn-sm" href="export.php?type=inbound&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Export Excel</a>'
      . '<a class="btn btn-sm" href="export.php?type=inbound_items&from=' . e($from) . '&to=' . e($to) . '">' . icon('export') . ' Detail Item</a>'
      . '<a class="btn btn-sm" href="import.php?ds=inbound">' . icon('import') . ' Import</a>'
      . (can('tx.create') ? '<a class="btn btn-sm btn-primary" href="inbound_form.php">' . icon('plus') . ' Barang Masuk Baru</a>' : '')); ?>
    <form class="filters" method="get" style="margin-bottom:18px">
      <div class="f-item"><label>Dari</label><input type="date" name="from" value="<?= e($from) ?>"></div>
      <div class="f-item"><label>Sampai</label><input type="date" name="to" value="<?= e($to) ?>"></div>
      <div class="f-item"><label>Supplier</label>
        <select name="supplier_id"><option value="0">Semua supplier</option>
          <?php foreach ($suppliers as $s): ?><option value="<?= (int)$s['id'] ?>" <?= $supplierF === (int)$s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="f-item"><label>Status</label>
        <select name="status">
          <?php foreach (['' => 'Semua status', 'draft' => 'Draft', 'posted' => 'Posted', 'void' => 'Void'] as $k => $v): ?>
            <option value="<?= e($k) ?>" <?= $statusF === $k ? 'selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="f-item"><label>No. dokumen / Supplier / SKU</label><input type="text" name="q" value="<?= e($q) ?>" placeholder="no dokumen, supplier, atau SKU barang"></div>
      <button class="btn btn-primary" type="submit">Terapkan</button>
      <a class="btn" href="inbound.php">Reset</a>
    </form>
    <div class="table-wrap">
      <table>
        <thead><tr><th>No. Dokumen</th><th>Tanggal</th><th>Supplier</th><th>SKU</th><th class="num">Total Qty</th><th class="num">Subtotal</th><th class="num">Diskon</th><th class="num">Total Dibayar</th><th>Status</th><th>Dibuat (tgl &middot; jam)</th><th>Catatan</th><th></th></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="12"><?= empty_state($q !== ''
            ? 'Tidak ada dokumen barang masuk yang cocok dengan pencarian "' . e($q) . '" pada periode ini.'
            : 'Belum ada dokumen barang masuk pada periode ini.') ?></td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td class="mono"><a href="inbound_form.php?id=<?= (int)$r['id'] ?>"><?= e($r['doc_no']) ?></a></td>
            <td class="nowrap"><?= e(fmt_date($r['doc_date'])) ?></td>
            <td><?= e($r['supplier_name'] ?? '-') ?></td>
            <?php $sum = doc_sku_summary($skuMap[(int)$r['id']] ?? []); ?>
            <td class="small mono sku-cell"><?= $sum['count'] === 0 ? '<span class="muted">-</span>'
                : '<span title="' . e($sum['full']) . '">' . e($sum['short']) . '</span>' ?></td>
            <td class="num"><?= fmt_qty($r['total_qty']) ?></td>
            <td class="num"><?= fmt_money($r['subtotal_amount'] ?? $r['total_amount']) ?></td>
            <td class="num"><?= (float)($r['discount_amount'] ?? 0) > 0
                ? '<span class="badge badge-info">' . ((string)($r['discount_type'] ?? 'percent') === 'percent'
                    ? fmt_num($r['discount_value'], 2) . '%'
                    : 'Rp') . ' &minus;' . fmt_money($r['discount_amount']) . '</span>'
                : '-' ?></td>
            <td class="num"><strong><?= fmt_money($r['total_amount']) ?></strong></td>
            <td><?= status_badge((string)$r['status']) ?></td>
            <td class="small nowrap"><?= e($r['created_name'] ?? '-') ?>
                <div class="muted"><?= e(fmt_dt($r['created_at'])) ?></div></td>
            <td class="small"><?= e($r['note'] ?: ($r['status'] === 'void' ? ('Void: ' . $r['void_reason']) : '-')) ?></td>
            <td class="nowrap">
              <div class="row-actions">
                <a class="btn btn-sm<?= $r['status'] === 'posted' && can('tx.edit_posted') ? ' btn-primary' : '' ?>" href="inbound_form.php?id=<?= (int)$r['id'] ?>"><?= $r['status'] === 'draft' ? 'Lanjutkan' : ($r['status'] === 'posted' && can('tx.edit_posted') ? 'Edit' : 'Lihat') ?></a>
                <?php if ($r['status'] === 'draft' && can('tx.edit')): ?>
                  <form class="inline-form" method="post" data-confirm="Posting dokumen ini? Stok akan bertambah.">
                    <?= csrf_field() ?><input type="hidden" name="op" value="post_id"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-sm btn-primary" type="submit">Posting</button>
                  </form>
                <?php endif; ?>
                <?php if ($r['status'] === 'posted' && is_admin()): ?>
                  <form class="inline-form" method="post" data-need-reason data-confirm="<?= e($voidConfirm[(int)$r['id']] ?? void_confirm_text('inbound', (int)$r['id'], (string)$r['doc_no'])) ?>">
                    <?= csrf_field() ?><input type="hidden" name="op" value="void"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <input type="hidden" name="void_reason" value="">
                    <button class="btn btn-sm btn-danger" type="submit">Void</button>
                  </form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?= render_pager($pg) ?>
  <?php card_end(); ?>
</section>
<?php page_end(); ?>
