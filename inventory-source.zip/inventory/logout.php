<?php
require_once __DIR__ . '/includes/init.php';
if (current_user()) log_activity('logout', 'Logout');
do_logout();
session_boot();
flash('Anda sudah keluar dari aplikasi.', 'info');
redirect('login.php');
