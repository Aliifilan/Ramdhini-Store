<?php
require_once __DIR__ . '/includes/init.php';
require_perm('inv.view');

$id = (int)get('id');
$brandId = (int)get('brand_id');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $op = (string)post('op');
    $did = (int)post('id');

    if ($op === 'void') {
        if (!is_admin()) {
            flash('Hanya Admin yang boleh melakukan void dokumen.', 'error');
        } else {
            $reason = (string)post('void_reason');
            $res = void_document('opname', $did, $reason !== '' ? $reason : 'tanpa alasan');
            if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil di-void dan stok dikembalikan.');
            if (!empty($res['warning'])) flash($res['warning'], 'warn');
            else flash('Gagal void: ' . e(implode(' ', $res['errors'])), 'error');
        }
        redirect('opname_form.php?id=' . $did);
    }

    if ($op === 'save' || $op === 'save_post') {
        if (!can('inv.opname')) {
            flash('Role Anda tidak boleh membuat stok opname.', 'error');
            redirect('opnames.php');
        }
        $docDate = (string)post('doc_date');
        $note = (string)post('note');
        $bid = (int)post('brand_id');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $docDate)) $docDate = today();

        $skus = (array)post('counted_sku', []);
        $qtys = (array)post('counted_qty', []);
        $resolved = resolve_skus($skus);
        $pids = $resolved['ids'];
        $vals = [];
        $filled = 0;
        foreach ($skus as $i => $sku) {
            $vals[$i] = $qtys[$i] ?? '';
            if (!empty($pids[$i]) && trim((string)$vals[$i]) !== '') $filled++;
        }
        if ($resolved['unknown']) {
            flash(unknown_sku_message($resolved['unknown']), 'warn');
        }
        if ($filled === 0) {
            flash('Scan atau ketik SKU yang terdaftar, lalu isi jumlah hasil hitung fisik.', 'error');
            redirect('opname_form.php' . ($did ? '?id=' . $did : ''));
        }

        $me = current_user();
        try {
            $did = db_tx(function () use ($did, $docDate, $note, $pids, $vals, $me) {
                if ($did > 0) {
                    $doc = db_one('SELECT * FROM opnames WHERE id = ?', [$did]);
                    if (!$doc) throw new RuntimeException('Dokumen tidak ditemukan.');
                    if ($doc['status'] !== 'draft') throw new RuntimeException('Dokumen yang sudah diposting/void tidak bisa diubah.');
                    db_run('UPDATE opnames SET doc_date=?, note=? WHERE id=?', [$docDate, $note, $did]);
                } else {
                    $docNo = next_doc_no('opname', 'OPN', $docDate);
                    db_run('INSERT INTO opnames (doc_no, doc_date, note, status, created_by, created_at) VALUES (?,?,?,?,?,?)',
                        [$docNo, $docDate, $note, 'draft', (int)$me['id'], now()]);
                    $did = (int)db()->lastInsertId();
                }
                save_opname_items($did, $pids, $vals);
                recalc_doc_totals('opname', $did);
                return $did;
            });
        } catch (Throwable $ex) {
            flash('Gagal menyimpan: ' . e($ex->getMessage()), 'error');
            redirect('opname_form.php' . ($did ? '?id=' . $did : ''));
        }

        $docNo = (string)db_scalar('SELECT doc_no FROM opnames WHERE id = ?', [$did]);
        log_activity('save', 'Simpan stok opname ' . $docNo, 'opname', $docNo);
        if ($op === 'save_post') {
            $res = post_document('opname', $did);
            if ($res['ok']) {
                flash('Opname <strong>' . e($docNo) . '</strong> berhasil diposting. Stok sudah disesuaikan.');
                redirect('opname_form.php?id=' . $did);
            }
            flash('Tersimpan sebagai draft, gagal posting: ' . e(implode(' ', $res['errors'])), 'warn');
            redirect('opname_form.php?id=' . $did);
        }
        flash('Opname <strong>' . e($docNo) . '</strong> disimpan sebagai draft.');
        redirect('opnames.php');
    }

    if ($op === 'post_id') {
        $res = post_document('opname', $did);
        if ($res['ok']) flash('Dokumen <strong>' . e($res['doc_no']) . '</strong> berhasil diposting.');
        else flash('Gagal posting: ' . e(implode(' ', $res['errors'])), 'error');
        redirect('opname_form.php?id=' . $did);
    }
}

$doc = null;
$saved = [];
if ($id > 0) {
    $doc = db_one('SELECT o.*, u.name AS created_name FROM opnames o LEFT JOIN users u ON u.id = o.created_by WHERE o.id = ?', [$id]);
    if (!$doc) {
        flash('Dokumen tidak ditemukan.', 'error');
        redirect('opnames.php');
    }
    foreach (doc_items('opname', $id) as $it) {
        $saved[(int)$it['product_id']] = $it;
    }
}
$canEdit = can('inv.opname') && (!$doc || $doc['status'] === 'draft');
$brands = db_all('SELECT id, name FROM brands ORDER BY name');
$activeBrands = db_all('SELECT id, name FROM brands WHERE active = 1 ORDER BY name');

$products = db_all(
    "SELECT p.id, p.sku, p.unit, p.stock_qty, p.min_stock, b.name AS brand_name
       FROM products p LEFT JOIN brands b ON b.id = p.brand_id
      WHERE p.active = 1 " . ($canEdit && $brandId > 0 ? 'AND p.brand_id = ' . $brandId : '') . "
      ORDER BY b.name, p.sku"
);
/* saat dokumen sudah tersimpan, tampilkan hanya produk yang ikut dihitung */
if ($doc && !$canEdit) {
    $pidList = array_keys($saved);
    $products = array_values(array_filter($products, static fn($p) => in_array((int)$p['id'], $pidList, true)));
}

$backUrl = $doc ? ('opnames.php?q=' . urlencode((string)$doc['doc_no'])) : 'opnames.php';

page_start($doc ? ('Stok Opname ' . $doc['doc_no']) : 'Stok Opname Baru', 'opnames');
?>
<div class="grid" style="gap:16px">
  <div class="stepline">
    <a class="btn btn-sm" href="<?= e($backUrl) ?>"><?= icon('arrow-left') ?> Kembali ke daftar</a>
    <?php if ($doc): ?>
      <?= status_badge((string)$doc['status']) ?>
      <span class="muted">Petugas: <?= e($doc['created_name'] ?? '-') ?> &middot; <?= e(fmt_dt($doc['created_at'])) ?></span>
      <?php if (!empty($doc['posted_at'])): ?>
        <span class="badge badge-info">Diposting <?= e(fmt_dt($doc['posted_at'])) ?></span>
      <?php endif; ?>
      <?php if ($doc['status'] === 'void'): ?>
        <span class="badge badge-danger">Void: <?= e($doc['void_reason']) ?><?= !empty($doc['voided_at']) ? ' — ' . e(fmt_dt($doc['voided_at'])) : '' ?></span>
      <?php endif; ?>
      <button class="btn btn-sm no-print" data-print><?= icon('print') ?> Cetak</button>
    <?php endif; ?>
  </div>
</div>

<section class="card">
  <?php card_start(
      $doc ? ('Lembar Opname ' . $doc['doc_no']) : 'Lembar Hitung Fisik',
      $canEdit ? 'Isi kolom <strong>Jumlah Fisik</strong> hanya untuk produk yang dihitung. Kolom kosong dianggap belum dihitung dan tidak mempengaruhi stok.' : 'Dokumen final, hanya bisa dibaca.'
  ); ?>
  <form method="post" id="opForm">
    <?= csrf_field() ?>
    <input type="hidden" name="op" value="save">
    <input type="hidden" name="id" value="<?= (int)($doc['id'] ?? 0) ?>">
    <div class="form-grid">
      <div><label>No. Dokumen</label><input type="text" value="<?= e($doc['doc_no'] ?? 'otomatis saat disimpan') ?>" readonly></div>
      <div><label>Tanggal Opname</label><input type="date" name="doc_date" value="<?= e($doc['doc_date'] ?? today()) ?>" <?= $canEdit ? '' : 'readonly' ?>></div>
      <div><label>Catatan</label><input type="text" name="note" value="<?= e($doc['note'] ?? '') ?>" <?= $canEdit ? '' : 'readonly' ?> placeholder="contoh: opname akhir bulan rak A-B"></div>
      <?php if ($canEdit && !$doc): ?>
      <div><label>Filter Brand</label>
        <select name="brand_id" onchange="this.form.method='get';this.form.action='opname_form.php';this.form.submit()">
          <option value="0">Semua brand</option>
          <?php foreach ($brands as $b): ?>
            <option value="<?= (int)$b['id'] ?>" <?= $brandId === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <?php endif; ?>
    </div>

    <?php if ($canEdit): ?>
      <?php sku_scan_tools([
          'mode' => 'count',
          'canCreate' => can('master.edit'),
          'brands' => $activeBrands,
          'focusField' => '.op-count',
          'list' => 'opList',
          'csrf' => csrf_token(),
          'hint' => 'Scan barcode/QR atau ketik SKU lalu Enter — baris produknya langsung difokuskan ke kolom Jumlah Fisik. Setelah mengetik jumlah, tekan Enter untuk kembali ke kolom scan.',
      ]); ?>

      <div class="filters no-print" style="margin:16px 0 10px">
        <div class="f-item" style="min-width:220px"><label>Cari cepat produk</label><input type="text" id="opSearch" placeholder="ketik SKU / brand" oninput="opFilter()"></div>
        <div class="f-item"><label>Filter baris</label>
          <label style="font-weight:500;display:flex;gap:8px;align-items:center;padding-top:6px">
            <input type="checkbox" id="opOnlyFilled" style="width:auto" onchange="opFilter()"> Hanya yang sudah diisi
          </label>
        </div>
        <div class="f-item"><label>&nbsp;</label><button class="btn" type="button" onclick="opFillSystem()">Isi dengan stok sistem</button></div>
        <div class="f-item"><label>&nbsp;</label><button class="btn" type="button" onclick="opClear()">Kosongkan semua</button></div>
      </div>

      <div class="table-wrap" id="opList">
        <table id="opTable">
          <thead><tr><th>SKU</th><th>Brand</th><th>Satuan</th><th class="num">Stok Sistem</th><th class="num">Jumlah Fisik</th><th class="num">Selisih</th></tr></thead>
          <tbody>
          <?php if (!$products): ?><tr><td colspan="6"><?= empty_state('Belum ada produk aktif. Tambahkan produk dulu di menu Produk Master.') ?></td></tr><?php endif; ?>
          <?php foreach ($products as $p): ?>
            <tr data-sku="<?= e($p['sku']) ?>" data-name="<?= e(strtolower($p['sku'] . ' ' . ($p['brand_name'] ?? ''))) ?>">
              <td class="mono"><?= e($p['sku']) ?></td>
              <td><?= e($p['brand_name'] ?? '-') ?></td>
              <td><?= e($p['unit']) ?></td>
              <td class="num sys"><?= fmt_qty($p['stock_qty']) ?></td>
              <td>
                <input type="hidden" name="counted_sku[]" value="<?= e($p['sku']) ?>">
                <input class="qty-input op-count count-field" type="text" name="counted_qty[]"
                       value="<?= isset($saved[(int)$p['id']]) ? e(fmt_qty($saved[(int)$p['id']]['qty_counted'])) : '' ?>"
                       data-stock="<?= (float)$p['stock_qty'] ?>" oninput="opRecalc()">
              </td>
              <td class="num diff">-</td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div class="form-actions">
        <button class="btn" type="submit">Simpan sebagai Draft</button>
        <button class="btn btn-primary" type="button" onclick="submitOpPost()">Simpan &amp; Posting (stok disesuaikan)</button>
        <div style="flex:1"></div>
        <span class="small muted">Terhitung: <strong id="opCounted">0</strong> produk &middot; Total selisih: <strong id="opTotal">0</strong></span>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead><tr><th>SKU</th><th>Satuan</th><th class="num">Stok Sistem</th><th class="num">Jumlah Fisik</th><th class="num">Selisih</th><th>Catatan</th></tr></thead>
          <tbody>
          <?php if (!$products): ?><tr><td colspan="6"><?= empty_state('Tidak ada item pada dokumen ini.') ?></td></tr><?php endif; ?>
          <?php $totDiff = 0; $cntOk = 0; ?>
          <?php foreach ($products as $p): $it = $saved[(int)$p['id']] ?? null; if (!$it) continue; $totDiff += (float)$it['diff']; if ((float)$it['diff'] == 0.0) $cntOk++; ?>
            <tr>
              <td class="mono"><?= e($p['sku']) ?></td>
              <td><?= e($p['unit']) ?></td>
              <td class="num"><?= fmt_qty($it['qty_system']) ?></td>
              <td class="num"><?= fmt_qty($it['qty_counted']) ?></td>
              <td class="num" style="color:<?= (float)$it['diff'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ((float)$it['diff'] >= 0 ? '+' : '') . fmt_qty($it['diff']) ?></td>
              <td class="small"><?= e($it['note'] ?: '-') ?></td>
            </tr>
          <?php endforeach; ?>
          <tr class="totals-row"><td colspan="4" class="right">Total selisih</td><td class="num"><?= fmt_qty($totDiff) ?></td><td></td></tr>
          </tbody>
        </table>
      </div>
      <p class="help"><?= fmt_num($cntOk) ?> dari <?= fmt_num(count($saved)) ?> item tercatat sesuai (selisih 0).</p>
    <?php endif; ?>
  </form>
  <?php card_end(); ?>
</section>

<?php if ($doc && $doc['status'] === 'posted'): ?>
<section class="card">
  <?php card_start('Pergerakan Stok Hasil Opname'); ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Tanggal</th><th>SKU</th><th class="num">Penyesuaian</th><th class="num">Saldo Stok</th><th>Catatan</th></tr></thead>
        <tbody>
        <?php foreach (doc_ledger_rows('opname', (int)$doc['id']) as $l): ?>
          <tr>
            <td><?= e(fmt_date($l['move_date'])) ?></td>
            <td class="mono"><?= e($l['sku']) ?></td>
            <td class="num" style="color:<?= (float)$l['qty_change'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= ((float)$l['qty_change'] >= 0 ? '+' : '') . fmt_qty($l['qty_change']) ?></td>
            <td class="num"><?= fmt_qty($l['qty_after']) ?></td>
            <td class="small"><?= e($l['note'] ?: doc_label((string)$l['ref_type'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<?php if ($doc && $doc['status'] === 'posted' && is_admin()): ?>
<section class="card">
  <?php card_start('Void Dokumen', 'Void membalik seluruh penyesuaian stok hasil opname ini.'); ?>
    <form method="post" data-need-reason data-confirm="<?= e(void_confirm_text('opname', (int)$doc['id'], (string)$doc['doc_no'])) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="op" value="void"><input type="hidden" name="id" value="<?= (int)$doc['id'] ?>">
      <input type="text" name="void_reason" placeholder="alasan void (wajib)" required>
      <div class="form-actions"><button class="btn btn-danger" type="submit"><?= icon('ban') ?> Void Dokumen</button></div>
    </form>
  <?php card_end(); ?>
</section>
<?php endif; ?>

<?php if ($canEdit): ?>
<script src="<?= e(asset_url('assets/sku.js')) ?>"></script>
<script>
function opRecalc() {
  var rows = document.querySelectorAll('#opTable tbody tr');
  var counted = 0, total = 0;
  Array.prototype.forEach.call(rows, function (tr) {
    var inp = tr.querySelector('.op-count');
    var cell = tr.querySelector('.diff');
    if (!inp || !cell) return;
    var raw = inp.value.trim();
    var stock = parseFloat(inp.getAttribute('data-stock') || '0');
    if (raw === '') { cell.textContent = '-'; cell.style.color = 'inherit'; return; }
    var v = parseFloat(raw.replace(/\./g, '').replace(',', '.'));
    if (isNaN(v)) { cell.textContent = '-'; return; }
    var d = v - stock;
    counted++; total += d;
    cell.textContent = (d > 0 ? '+' : '') + fmtNum(d);
    cell.style.color = d > 0 ? 'var(--ok)' : (d < 0 ? 'var(--danger)' : 'inherit');
  });
  document.getElementById('opCounted').textContent = fmtNum(counted);
  document.getElementById('opTotal').textContent = (total > 0 ? '+' : '') + fmtNum(total);
}
function opFilter() {
  var q = (document.getElementById('opSearch').value || '').toLowerCase();
  var onlyFilled = document.getElementById('opOnlyFilled').checked;
  Array.prototype.forEach.call(document.querySelectorAll('#opTable tbody tr'), function (tr) {
    var name = tr.getAttribute('data-name') || '';
    var inp = tr.querySelector('.op-count');
    var filled = inp && inp.value.trim() !== '';
    var show = (q === '' || name.indexOf(q) !== -1) && (!onlyFilled || filled);
    tr.style.display = show ? '' : 'none';
  });
}
function opFillSystem() {
  Array.prototype.forEach.call(document.querySelectorAll('#opTable tbody tr'), function (tr) {
    if (tr.style.display === 'none') return;
    var inp = tr.querySelector('.op-count');
    if (inp && inp.value.trim() === '') inp.value = fmtNum(parseFloat(inp.getAttribute('data-stock') || '0'));
  });
  opRecalc();
}
function opClear() {
  if (!confirm('Kosongkan semua kolom jumlah fisik?')) return;
  Array.prototype.forEach.call(document.querySelectorAll('#opTable tbody tr .op-count'), function (inp) { inp.value = ''; });
  opRecalc();
}
function submitOpPost() {
  var f = document.getElementById('opForm');
  if (!confirm('Posting hasil opname? Stok sistem akan langsung disesuaikan dengan hasil hitung fisik.')) return;
  f.querySelector('input[name=op]').value = 'save_post';
  f.submit();
}
document.addEventListener('DOMContentLoaded', opRecalc);
</script>
<?php endif; ?>
<?php page_end(); ?>
