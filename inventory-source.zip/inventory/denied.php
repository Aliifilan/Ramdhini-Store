<?php
require_once __DIR__ . '/includes/init.php';
?><!DOCTYPE html>
<html lang="id">
<head><meta charset="utf-8"><title>Akses ditolak</title><link rel="stylesheet" href="<?= e(asset_url('assets/app.css')) ?>"></head>
<body>
<div class="login-wrap" style="min-height:100vh;display:grid;place-items:center;padding:24px">
  <div class="card" style="max-width:440px;padding:28px;text-align:center">
    <div class="brand-mark" style="margin:0 auto 14px"><?= icon('ban') ?></div>
    <h2 style="margin-bottom:8px">Akses ditolak</h2>
    <p class="muted">Role akun Anda tidak memiliki izin untuk membuka halaman ini. Hubungi Admin bila menurut Anda ini keliru.</p>
    <div style="margin-top:20px"><a class="btn btn-primary" href="index.php">Kembali ke Dashboard</a></div>
  </div>
</div>
</body>
</html>
